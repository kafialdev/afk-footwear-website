<?php
require_once __DIR__ . '/db.php';
session_start();
$categoryPage = 'Discount';
$products = mysqli_query($conn, "SELECT * FROM products WHERE category='$categoryPage' ORDER BY created_at DESC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>A.F.K FOOTWEAR</title>
    <link rel="stylesheet" href="css/discount.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
</head>

<body>
    <div class="top-nav">
        <a href="index.php" class="home-icon">
            <i class='bx bx-home'></i>
        </a>
    </div>

    <div class="container">
        <h1>🔥 Epic Discounts: 50% Off Premium Shoes! 🔥</h1>
        <div class="products">
        <?php if($products && mysqli_num_rows($products) > 0): ?>
          <?php while($p = mysqli_fetch_assoc($products)): ?>
            <?php
              $pid = (int)$p['id'];
              $sizesRes = mysqli_query($conn, "SELECT size_label, stock FROM product_sizes WHERE product_id=$pid AND stock > 0 ORDER BY size_label");
              $sizes = [];
            if ($sizesRes) {
              while ($row = mysqli_fetch_assoc($sizesRes)) {
                $sizes[] = $row; // size_label & stock
              }
            }
$nowPrice = (int)$p['price'];
              $originalPrice = $nowPrice * 2; // asumsi 50% OFF
            ?>
            <div class="product product-card"
                 data-id="<?php echo $p['id']; ?>"
                 data-name="<?php echo htmlspecialchars($p['name']); ?>"
                 data-price="<?php echo $nowPrice; ?>"
                 data-image="<?php echo htmlspecialchars($p['image_url']); ?>">

              <div class="discount-badge">50% OFF</div>
              <img src="<?php echo htmlspecialchars($p['image_url']); ?>"
                   alt="<?php echo htmlspecialchars($p['name']); ?>">
              <div class="product-content">
                <h2><?php echo htmlspecialchars($p['name']); ?></h2>
                <p class="original-price">
                  Original: Rp <?php echo number_format($originalPrice, 0, ',', '.'); ?>
                </p>
                <p class="discount-price">
                  Now: Rp <?php echo number_format($nowPrice, 0, ',', '.'); ?>
                </p>

                <select class="product-size" required>
                  <option value="">Choose size</option>
                  <?php if (!empty($sizes)): ?>
                    <?php foreach($sizes as $sz): ?>
                      <option value="<?php echo htmlspecialchars($sz['size_label']); ?>">
                        <?php echo htmlspecialchars($sz['size_label']); ?> (Stok: <?php echo (int)$sz['stock']; ?>)
                      </option>
                    <?php endforeach; ?>
                  <?php else: ?>
                    <?php for($i=27;$i<=45;$i++): ?>
                      <option value="<?php echo $i; ?>"><?php echo $i; ?></option>
                    <?php endfor; ?>
                  <?php endif; ?>
                </select>

                <button class="buy-btn add-to-cart">Add to Cart</button>
              </div>
            </div>
          <?php endwhile; ?>
        <?php else: ?>
          <p style="color:#fff;text-align:center;width:100%;margin-top:20px;">
            Belum ada produk diskon. Tambahkan produk dengan kategori <strong>Discount</strong> di halaman Admin &gt; Produk.
          </p>
        <?php endif; ?>
      </div></div>
    </div>

    <script src="js/discount.js"></script> 
</body>
</html>