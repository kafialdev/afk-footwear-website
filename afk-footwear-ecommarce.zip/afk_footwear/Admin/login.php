<?php
session_start();

$err = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user = trim($_POST['user'] ?? '');
    $pass = $_POST['pass'] ?? '';

    if ($user === '' || $pass === '') {
        $err = 'Username dan password wajib diisi.';
    } else {
        if ($user === 'admin' && $pass === 'admin123') {
            $_SESSION['admin_id']    = 1;
            $_SESSION['admin_name']  = 'Admin';
            $_SESSION['admin_email'] = 'admin@afkfootwear.com';
            header('Location: index.php');
            exit;
        } else {
            $err = 'Incorrect username or password. Try: admin / admin123';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Admin Login - AFK Footwear</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
  <link href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet">

  <style>
    * { box-sizing:border-box; }

    body {
      font-family: 'Poppins', system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
      background: #f3f4f6;
      margin:0;
      padding:20px;
    }

    .login-box {
      max-width: 460px;
      margin: 20px auto;
      background: #ffffff;
      border-radius: 26px;
      padding: 26px 30px 32px;
      box-shadow: 0 20px 55px rgba(15, 23, 42, 0.18);
      border-top: 4px solid #B91C1C;
    }

    .login-header {
      display:flex;
      align-items:center;
      gap:10px;
      margin-bottom:6px;
    }

    .login-header-icon {
      width:36px;
      height:36px;
      border-radius:999px;
      background:rgba(185,28,28,0.08);
      display:flex;
      align-items:center;
      justify-content:center;
    }
    .login-header-icon i{
      color:#B91C1C;
      font-size:20px;
    }

    .login-header h1 {
      font-size:22px;
      margin:0;
      color:#111827;
    }

    .subtitle {
      margin:0 0 18px;
      font-size:13px;
      color:#6b7280;
    }

    .err {
      background:#FEE2E2;
      border:1px solid #FCA5A5;
      color:#B91C1C;
      border-radius:16px;
      padding:9px 12px;
      font-size:13px;
      margin-bottom:16px;
    }

    .form-group {
      margin-bottom:18px;
    }

    .form-group label {
      display:block;
      font-size:13px;
      font-weight:600;
      color:#374151;
      margin-bottom:6px;
    }

    .form-group input {
      width:100%;
      padding:11px 14px;
      border-radius:14px;
      border:1px solid #e5e7eb;
      font-size:14px;
      outline:none;
      transition:border-color .2s, box-shadow .2s;
      background:#ffffff;
    }

    .form-group input:focus {
      border-color:#B91C1C;
      box-shadow:0 0 0 2px rgba(185,28,28,0.20);
    }

    /* WRAPPER UNTUK PASSWORD + ICON MATA */
    .password-field{
      position:relative;
    }
    .password-field input{
      padding-right:46px; /* ruang untuk icon mata */
    }
    .password-field i{
      position:absolute;
      right:14px;
      top:50%;
      transform:translateY(-50%);
      font-size:20px;
      color:#6b7280;
      cursor:pointer;
      transition:color .2s;
    }
    .password-field i:hover{
      color:#B91C1C;
    }

    .btn {
      width:100%;
      border:none;
      border-radius:999px;
      padding:11px 14px;
      font-size:15px;
      font-weight:600;
      cursor:pointer;
      margin-top:6px;
      background:linear-gradient(135deg,#B91C1C,#7F1D1D);
      color:#ffffff;
      display:inline-flex;
      align-items:center;
      justify-content:center;
      gap:8px;
      box-shadow:0 14px 32px rgba(185,28,28,0.32);
      transition:transform .15s, box-shadow .15s, filter .15s;
    }
    .btn i{
      font-size:18px;
    }
    .btn:hover{
      filter:brightness(1.05);
      transform:translateY(-1px);
    }
    .btn:active{
      transform:translateY(0);
      box-shadow:0 8px 18px rgba(127,29,29,0.5);
    }

    .helper{
      margin-top:16px;
      font-size:12px;
      display:flex;
      justify-content:space-between;
      gap:8px;
      flex-wrap:wrap;
      color:#6b7280;
    }
    .helper a{
      color:#B91C1C;
      font-weight:600;
      text-decoration:none;
    }
    .helper a:hover{
      text-decoration:underline;
    }
  </style>
</head>
<body>

  <div class="login-box">
    <div class="login-header">
      <div class="login-header-icon">
        <i class='bx bxs-lock-alt'></i>
      </div>
      <div>
        <h1>Admin Login</h1>
        <p class="subtitle">Sign in to manage products &amp; orders.</p>
      </div>
    </div>

    <?php if ($err): ?>
      <div class="err"><?= htmlspecialchars($err) ?></div>
    <?php endif; ?>

    <form method="post" autocomplete="off">
      <div class="form-group">
        <label>Username / Email</label>
        <input type="text" name="user" required>
      </div>

      <div class="form-group">
        <label>Password</label>
        <div class="password-field">
          <input type="password" name="pass" id="adminPass" required>
          <i class="bx bx-hide" id="togglePass"></i>
        </div>
      </div>

      <button type="submit" class="btn">
        <i class='bx bx-log-in-circle'></i>
        <span>Login to Dashboard</span>
      </button>
    </form>

    <div class="helper">
      <span>&larr; <a href="../index.php">Back to Home</a></span>
      <span>User Login → <a href="../signin.php">User Page</a></span>
    </div>
  </div>

  <script>
    const passInput = document.getElementById('adminPass');
    const toggle = document.getElementById('togglePass');

    toggle.addEventListener('click', () => {
      if (passInput.type === 'password') {
        passInput.type = 'text';
        toggle.classList.remove('bx-hide');
        toggle.classList.add('bx-show');
      } else {
        passInput.type = 'password';
        toggle.classList.remove('bx-show');
        toggle.classList.add('bx-hide');
      }
    });
  </script>

</body>
</html>
