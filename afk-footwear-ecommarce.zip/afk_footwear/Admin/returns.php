<?php
require_once __DIR__ . '/../db.php';
session_start();

// proteksi: hanya admin
if (empty($_SESSION['admin_id'])) {
  header('Location: login.php');
  exit;
}

$rows = [];
$sql = "
  SELECT r.id, r.order_id, r.user_id, r.product_id, r.item_code, r.return_address,
         r.reason, r.note, r.photo, r.status, r.created_at,
         u.name AS customer_name, u.email AS customer_email,
         o.total_amount, o.created_at AS order_created_at,
         p.name AS product_name
  FROM returns r
  JOIN users u ON u.id = r.user_id
  JOIN orders o ON o.id = r.order_id
  LEFT JOIN products p ON p.id = r.product_id
  ORDER BY r.created_at DESC
";

$res = @$conn->query($sql);
if ($res) {
  while ($row = $res->fetch_assoc()) {
    $rows[] = $row;
  }
}

function badge($s){
  $s = strtolower(trim((string)$s));
  if ($s === 'approved' || $s === 'disetujui') return ['Disetujui','ok'];
  if ($s === 'rejected' || $s === 'ditolak') return ['Ditolak','bad'];
  return ['Menunggu','wait'];
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Return - AFK Footwear Admin</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
  <link href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet">
  <link rel="stylesheet" href="assets/admin.css">
  <style>
    .badge{ display:inline-flex; align-items:center; gap:8px; padding:6px 10px; border-radius:999px; font-weight:800; font-size:.85rem; border:1px solid rgba(13,32,68,.12); }
    .badge.ok{ background:#f0fdf4; color:#166534; border-color:#bbf7d0; }
    .badge.bad{ background:#fef2f2; color:#991b1b; border-color:#fecaca; }
    .badge.wait{ background:#fffbeb; color:#92400e; border-color:#fde68a; }
    .btn-mini{ display:inline-flex; align-items:center; gap:8px; padding:8px 10px; border-radius:10px; font-weight:800; text-decoration:none; border:1px solid rgba(13,32,68,.12); background:#fff; color:#111827; }
    .btn-mini.approve{ background:#111827; color:#fff; border-color:transparent; }
    .btn-mini.reject{ background:#fff; color:#991b1b; border-color:#fecaca; }
    .table-wrap{ overflow:auto; border-radius:16px; border:1px solid rgba(13,32,68,.08); }
    table{ width:100%; border-collapse:collapse; min-width:980px; }
    th,td{ padding:12px 12px; border-bottom:1px solid rgba(13,32,68,.06); text-align:left; vertical-align:top; }
    th{ background:rgba(13,32,68,.04); font-weight:900; }
    .muted{ color:#64748b; font-weight:600; font-size:.9rem; }
  </style>
</head>
<body>
<div class="admin-layout">
  <aside class="sidebar">
    <div class="sidebar-logo">
      <img src="../IMG/LOGO.jpg" alt="AFK FOOTWEAR">
      <div>
        <div class="logo-text-title">AFK FOOTWEAR</div>
        <div class="logo-text-sub">Admin Panel</div>
      </div>
    </div>

    <div class="sidebar-section-title">Menu utama</div>
    <ul class="nav-list">
      <li class="nav-item"><a href="index.php"><i class='bx bxs-dashboard'></i><span>Dashboard</span></a></li>
      <li class="nav-item"><a href="products.php"><i class='bx bx-box'></i><span>Produk</span></a></li>
      <li class="nav-item"><a href="orders.php"><i class='bx bx-cart'></i><span>Order</span></a></li>
      <li class="nav-item"><a href="customers.php"><i class='bx bx-user'></i><span>Customer</span></a></li>
      <li class="nav-item active"><a href="returns.php"><i class='bx bx-undo'></i><span>Return</span></a></li>
      <li class="nav-item"><a href="reports.php"><i class='bx bx-bar-chart-alt-2'></i><span>Laporan</span></a></li>
    </ul>

    <div class="sidebar-section-title">Session</div>
    <ul class="nav-list">
      <li class="nav-item"><a href="logout.php"><i class='bx bx-log-out-circle'></i><span>Logout</span></a></li>
    </ul>

    <div class="sidebar-footer">
      Login sebagai <span><?php echo htmlspecialchars($_SESSION['admin_name'] ?? 'Admin'); ?></span><br>
      A.F.K Footwear &copy; 2025
    </div>
  </aside>

  <main class="main">
    <div class="page-header" style="margin-bottom:16px;">
      <div>
        <h1 style="margin:0;">Return Requests</h1>
        <div class="muted" style="margin-top:6px;">Kelola pengajuan return dari customer (approve / reject).</div>
      </div>
    </div>

    <?php if (!$res): ?>
      <div class="panel" style="padding:16px; border-radius:16px;">
        Tabel <b>returns</b> belum ada / belum terimport. Jalankan file SQL yang sudah disertakan.
      </div>
    <?php elseif (empty($rows)): ?>
      <div class="panel" style="padding:16px; border-radius:16px;">Belum ada pengajuan return.</div>
    <?php else: ?>
      <div class="table-wrap">
        <table>
          <thead>
            <tr>
              <th>Order</th>
              <th>Customer</th>
              <th>Barang</th>
              <th>Alasan</th>
              <th>Lokasi Return</th>
              <th>Status</th>
              <th>Foto</th>
              <th>Aksi</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($rows as $r): ?>
              <?php
                $code = sprintf('#AFK%04d', (int)$r['order_id']);
                [$lbl,$cls] = badge($r['status'] ?? '');
                $dt = !empty($r['created_at']) ? date('d M Y, H:i', strtotime($r['created_at'])) : '-';
              ?>
              <tr>
                <td>
                  <div style="font-weight:900;"><?php echo htmlspecialchars($code); ?></div>
                  <div class="muted">Return: <?php echo htmlspecialchars($dt); ?></div>
                  <div class="muted">Total: Rp <?php echo number_format((int)$r['total_amount'],0,',','.'); ?></div>
                </td>
                <td>
                  <div style="font-weight:900;"><?php echo htmlspecialchars($r['customer_name'] ?? '-'); ?></div>
                  <div class="muted"><?php echo htmlspecialchars($r['customer_email'] ?? '-'); ?></div>
                </td>
                <td>
                  <?php
                    $pname = $r['product_name'] ?? '-';
                    $pcode = $r['item_code'] ?? (isset($r['product_id']) ? sprintf('PRD%04d', (int)$r['product_id']) : '-');
                  ?>
                  <div style="font-weight:900;"><?php echo htmlspecialchars($pname); ?></div>
                  <div class="muted">Kode: <?php echo htmlspecialchars($pcode); ?></div>
                </td>
                <td>
                  <div style="font-weight:900;"><?php echo htmlspecialchars($r['reason'] ?? '-'); ?></div>
                  <?php if (!empty($r['note'])): ?>
                    <div class="muted" style="margin-top:6px;"><?php echo nl2br(htmlspecialchars($r['note'])); ?></div>
                  <?php endif; ?>
                </td>
                <td>
                  <?php if (!empty($r['return_address'])): ?>
                    <div style="white-space:pre-line; font-weight:700;" class="muted"><?php echo htmlspecialchars($r['return_address']); ?></div>
                  <?php else: ?>
                    <span class="muted">-</span>
                  <?php endif; ?>
                </td>
                <td>
                  <span class="badge <?php echo $cls; ?>"><?php echo htmlspecialchars($lbl); ?></span>
                </td>
                <td>
                  <?php if (!empty($r['photo'])): ?>
                    <a class="btn-mini" href="../<?php echo htmlspecialchars($r['photo']); ?>" target="_blank" rel="noopener"><i class='bx bx-image'></i> Lihat</a>
                  <?php else: ?>
                    <span class="muted">-</span>
                  <?php endif; ?>
                </td>
                <td>
                  <?php $id = (int)$r['id']; ?>
                  <div style="display:flex; gap:8px; flex-wrap:wrap;">
                    <a class="btn-mini approve" href="returns_action.php?id=<?php echo $id; ?>&action=approve"><i class='bx bx-check'></i> Approve</a>
                    <a class="btn-mini reject" href="returns_action.php?id=<?php echo $id; ?>&action=reject" onclick="return confirm('Tolak pengajuan return ini?');"><i class='bx bx-x'></i> Reject</a>
                  </div>
                </td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    <?php endif; ?>
  </main>
</div>
</body>
</html>
