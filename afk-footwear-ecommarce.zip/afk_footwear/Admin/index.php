<?php
require_once __DIR__ . '/../db.php';
session_start();

// proteksi: hanya admin
if (empty($_SESSION['admin_id'])) {
  header('Location: login.php');
  exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Dashboard - AFK Footwear Admin</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
  <link href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet">
  <link rel="stylesheet" href="assets/admin.css">
</head>
<body>
<div class="admin-layout">
  <aside class="sidebar">
    <div class="sidebar-logo">
      <img src="../IMG/LOGO.jpg" alt="AFK FOOTWEAR">
      <div>
        <div class="logo-text-title">AFK FOOTWEAR</div>
        <div class="logo-text-sub">Admin Panel</div>
      </div>
    </div>

    <div class="sidebar-section-title">Menu utama</div>
    <ul class="nav-list">
      <li class="nav-item active">
        <a href="index.php"><i class='bx bxs-dashboard'></i><span>Dashboard</span></a>
      </li>
      <li class="nav-item ">
        <a href="products.php"><i class='bx bx-box'></i><span>Produk</span></a>
      </li>
      <li class="nav-item ">
        <a href="orders.php"><i class='bx bx-cart'></i><span>Order</span></a>
      </li>
      <li class="nav-item ">
        <a href="customers.php"><i class='bx bx-user'></i><span>Customer</span></a>
      </li>
      <li class="nav-item ">
        <a href="returns.php"><i class='bx bx-undo'></i><span>Return</span></a>
      </li>
      <li class="nav-item ">
        <a href="reports.php"><i class='bx bx-bar-chart-alt-2'></i><span>Laporan</span></a>
      </li>
    </ul>

    <div class="sidebar-section-title">Session</div>
    <ul class="nav-list">
      <li class="nav-item">
        <a href="logout.php"><i class='bx bx-log-out-circle'></i><span>Logout</span></a>
      </li>
    </ul>

    <div class="sidebar-footer">
      Login sebagai <span><?php echo htmlspecialchars($_SESSION['admin_name'] ?? 'Admin'); ?></span><br>
      A.F.K Footwear &copy; 2025
    </div>
  </aside>

  <main class="main">
<?php
// Hitung statistik utama
$now   = new DateTime();
$year  = $now->format('Y');
$month = $now->format('m');
$today = $now->format('Y-m-d');

// Pendapatan HARI INI
$q_income_today = "
  SELECT COALESCE(SUM(total_amount),0) AS total
  FROM orders
  WHERE status IN ('Diproses','Dikirim','Selesai')
    AND DATE(created_at) = '$today'
";
$r_income_today   = mysqli_query($conn, $q_income_today);
$row_income_today = $r_income_today ? mysqli_fetch_assoc($r_income_today) : ['total'=>0];
$income_today     = (int)$row_income_today['total'];

// Pendapatan BULAN INI
$q_income_month = "
  SELECT COALESCE(SUM(total_amount),0) AS total
  FROM orders
  WHERE status IN ('Diproses','Dikirim','Selesai')
    AND YEAR(created_at) = $year
    AND MONTH(created_at) = $month
";
$r_income_month   = mysqli_query($conn, $q_income_month);
$row_income_month = $r_income_month ? mysqli_fetch_assoc($r_income_month) : ['total'=>0];
$income_month     = (int)$row_income_month['total'];

// Jumlah ORDER HARI INI (hanya status aktif/selesai, sama dengan laporan)
$q_ord_today = "
  SELECT COUNT(*) AS jml
  FROM orders
  WHERE status IN ('Diproses','Dikirim','Selesai')
    AND DATE(created_at) = '$today'
";
$r_ord_today   = mysqli_query($conn, $q_ord_today);
$row_ord_today = $r_ord_today ? mysqli_fetch_assoc($r_ord_today) : ['jml'=>0];
$orders_today  = (int)$row_ord_today['jml'];

// Jumlah ORDER BULAN INI (pakai filter status yang sama)
$q_ord_month = "
  SELECT COUNT(*) AS jml
  FROM orders
  WHERE status IN ('Diproses','Dikirim','Selesai')
    AND YEAR(created_at) = $year
    AND MONTH(created_at) = $month
";
$r_ord_month   = mysqli_query($conn, $q_ord_month);
$row_ord_month = $r_ord_month ? mysqli_fetch_assoc($r_ord_month) : ['jml'=>0];
$orders_month  = (int)$row_ord_month['jml'];

// Total produk
$r_prod = mysqli_query($conn, "SELECT COUNT(*) AS jml FROM products");
$row_prod = $r_prod ? mysqli_fetch_assoc($r_prod) : ['jml'=>0];
$total_products = (int)$row_prod['jml'];

// Total customer
$r_cust = mysqli_query($conn, "SELECT COUNT(*) AS jml FROM users WHERE role='customer'");
$row_cust = $r_cust ? mysqli_fetch_assoc($r_cust) : ['jml'=>0];
$total_customers = (int)$row_cust['jml'];

// Order terbaru
$r_recent = mysqli_query($conn, "
  SELECT o.id, u.name AS customer, o.total_amount, o.status, o.payment_method, o.created_at
  FROM orders o
  JOIN users u ON u.id = o.user_id
  ORDER BY o.created_at DESC
  LIMIT 6
");

// Data penjualan per bulan untuk grafik dan tabel
$r_monthly = mysqli_query($conn, "
  SELECT DATE_FORMAT(created_at,'%Y-%m') AS ym,
         COUNT(*) AS total_order,
         SUM(total_amount) AS total_amount
  FROM orders
  WHERE status IN ('Diproses','Dikirim','Selesai')
  GROUP BY ym
  ORDER BY ym ASC
");
$monthly = [];
$max_amount = 0;
if ($r_monthly) {
  while($m = mysqli_fetch_assoc($r_monthly)) {
    $monthly[] = $m;
    if ($m['total_amount'] > $max_amount) {
      $max_amount = $m['total_amount'];
    }
  }
}
?>

    <div class="topbar">
      <div class="topbar-left">
        <h1>Dashboard</h1>
        <div class="breadcrumb">
          Admin / <span>Dashboard</span>
        </div>
      </div>
      <div class="topbar-right"></div>
    </div>

    <div class="grid-summary">
      <!-- Pendapatan bulan + hari ini -->
      <div class="card">
        <div class="card-label">Pendapatan bulan ini</div>
        <div class="card-value">Rp <?php echo number_format($income_month,0,',','.'); ?></div>
        <div class="card-meta">
          Hari ini: <strong>Rp <?php echo number_format($income_today,0,',','.'); ?></strong>
        </div>
      </div>

      <!-- Order bulan + hari ini -->
      <div class="card">
        <div class="card-label">Order bulan ini</div>
        <div class="card-value"><?php echo $orders_month; ?></div>
        <div class="card-meta">
          Order hari ini: <strong><?php echo $orders_today; ?></strong>
        </div>
      </div>

      <div class="card">
        <div class="card-label">Total produk</div>
        <div class="card-value"><?php echo $total_products; ?></div>
        <div class="card-meta">Aktif dalam katalog AFK</div>
      </div>
      <div class="card">
        <div class="card-label">Customer terdaftar</div>
        <div class="card-value"><?php echo $total_customers; ?></div>
        <div class="card-meta">Akun pelanggan AFK Footwear</div>
      </div>
    </div>

    <div class="grid-main">
      <div class="card">
        <div style="display:flex;justify-content:space-between;align-items:center;">
          <div>
            <h2>Ringkasan penjualan per bulan</h2>
            <small>Grafik batang berdasarkan total penjualan selesai</small>
          </div>
        </div>
        <div class="chart-bars">
          <?php if(!empty($monthly) && $max_amount > 0): ?>
            <?php foreach($monthly as $m): 
              $percent = ($m['total_amount'] / $max_amount) * 100;
            ?>
              <div class="bar-row">
                <div class="bar-label"><?php echo htmlspecialchars($m['ym']); ?></div>
                <div class="bar-track">
                  <div class="bar-fill" style="width: <?php echo $percent; ?>%;"></div>
                </div>
                <div style="width:90px;text-align:right;font-size:11px;">
                  Rp <?php echo number_format($m['total_amount'],0,',','.'); ?>
                </div>
              </div>
            <?php endforeach; ?>
          <?php else: ?>
            <p style="font-size:12px;margin-top:8px;">Belum ada data penjualan selesai untuk ditampilkan.</p>
          <?php endif; ?>
        </div>

        <div class="table-wrapper" style="margin-top:10px;">
          <table>
            <thead>
              <tr>
                <th>Bulan</th>
                <th>Jumlah Order</th>
                <th>Total Penjualan</th>
              </tr>
            </thead>
            <tbody>
              <?php if(!empty($monthly)): ?>
                <?php foreach($monthly as $m): ?>
                  <tr>
                    <td><?php echo htmlspecialchars($m['ym']); ?></td>
                    <td><?php echo (int)$m['total_order']; ?> order</td>
                    <td>Rp <?php echo number_format($m['total_amount'],0,',','.'); ?></td>
                  </tr>
                <?php endforeach; ?>
              <?php else: ?>
                <tr><td colspan="3">Belum ada catatan penjualan.</td></tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>

      <div class="card">
        <div style="display:flex;justify-content:space-between;align-items:center;">
          <div>
            <h2>Order terbaru</h2>
            <small>6 transaksi terakhir</small>
          </div>
        </div>
        <div class="table-wrapper">
          <table>
            <thead>
              <tr>
                <th>ID</th>
                <th>Customer</th>
                <th>Total</th>
                <th>Status</th>
                <th>Tanggal</th>
              </tr>
            </thead>
            <tbody>
              <?php if($r_recent && mysqli_num_rows($r_recent)>0): ?>
                <?php while($o = mysqli_fetch_assoc($r_recent)): ?>
                  <tr>
                    <td>#AFK<?php echo str_pad($o['id'],4,'0',STR_PAD_LEFT); ?></td>
                    <td><?php echo htmlspecialchars($o['customer']); ?></td>
                    <td>Rp <?php echo number_format($o['total_amount'],0,',','.'); ?></td>
                    <td>
                      <?php
                        $cls = 'status-new';
                        if ($o['status']==='Diproses') $cls='status-process';
                        if ($o['status']==='Dikirim' || $o['status']==='Selesai') $cls='status-done';
                        if ($o['status']==='Dibatalkan') $cls='status-cancel';

                        // Teks status untuk dashboard (bahasa Inggris)
                        $statusText = $o['status'];
                        if ($statusText === 'Baru')      $statusText = 'New';
                        if ($statusText === 'Diproses')  $statusText = 'Processing';
                        if ($statusText === 'Dikirim')   $statusText = 'Shipped';
                        if ($statusText === 'Selesai')   $statusText = 'Delivered';
                        if ($statusText === 'Dibatalkan')$statusText = 'Cancelled';
                      ?>
                      <span class="status-pill <?php echo $cls; ?>">
                        <?php echo htmlspecialchars($statusText); ?>
                      </span>
                    </td>
                    <td><?php echo date('d-m-Y H:i', strtotime($o['created_at'])); ?></td>
                  </tr>
                <?php endwhile; ?>
              <?php else: ?>
                <tr><td colspan="5">Belum ada order.</td></tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>

    <div class="footer-admin">
      <span>© 2025 AFK FOOTWEAR Admin.</span>
      <span>Frontend terhubung ke <a href="../index.php">website pengguna</a></span>
    </div>
  </main>
</div>
</body>
</html>
