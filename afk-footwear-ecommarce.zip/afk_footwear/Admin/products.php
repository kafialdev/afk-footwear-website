<?php
require_once __DIR__ . '/../db.php';
session_start();

// proteksi: hanya admin
if (empty($_SESSION['admin_id'])) {
  header('Location: login.php');
  exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Produk - AFK Footwear Admin</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
  <link href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet">
  <link rel="stylesheet" href="assets/admin.css">
</head>
<body>
<div class="admin-layout">
  <aside class="sidebar">
    <div class="sidebar-logo">
      <img src="../IMG/LOGO.jpg" alt="AFK FOOTWEAR">
      <div>
        <div class="logo-text-title">AFK FOOTWEAR</div>
        <div class="logo-text-sub">Admin Panel</div>
      </div>
    </div>

    <div class="sidebar-section-title">Menu utama</div>
    <ul class="nav-list">
      <li class="nav-item ">
        <a href="index.php"><i class='bx bxs-dashboard'></i><span>Dashboard</span></a>
      </li>
      <li class="nav-item active">
        <a href="products.php"><i class='bx bx-box'></i><span>Produk</span></a>
      </li>
      <li class="nav-item ">
        <a href="orders.php"><i class='bx bx-cart'></i><span>Order</span></a>
      </li>
      <li class="nav-item ">
        <a href="customers.php"><i class='bx bx-user'></i><span>Customer</span></a>
      </li>
      <li class="nav-item ">
        <a href="returns.php"><i class='bx bx-undo'></i><span>Return</span></a>
      </li>
      <li class="nav-item ">
        <a href="reports.php"><i class='bx bx-bar-chart-alt-2'></i><span>Laporan</span></a>
      </li>
    </ul>

    <div class="sidebar-section-title">Session</div>
    <ul class="nav-list">
      <li class="nav-item">
        <a href="logout.php"><i class='bx bx-log-out-circle'></i><span>Logout</span></a>
      </li>
    </ul>

    <div class="sidebar-footer">
      Login sebagai <span><?php echo htmlspecialchars($_SESSION['admin_name'] ?? 'Admin'); ?></span><br>
      A.F.K Footwear &copy; 2025
    </div>
  </aside>

  <main class="main">
<?php
$err = '';
$ok  = '';

// ===== Size range (EU) untuk produk (27 - 45) =====
$SIZE_RANGE = range(27, 45);

// Data untuk mode edit produk
$editProduct = null;
$editSizes = [];
foreach ($SIZE_RANGE as $sz) {
  $editSizes[(string)$sz] = 0;
}

if (isset($_GET['edit'])) {
  $editId = (int)$_GET['edit'];
  if ($editId > 0) {
    $resP = mysqli_query($conn, "SELECT * FROM products WHERE id=$editId LIMIT 1");
    if ($resP && mysqli_num_rows($resP) === 1) {
      $editProduct = mysqli_fetch_assoc($resP);
      // ambil stok per ukuran jika ada
      $resS = mysqli_query($conn, "SELECT size_label, stock FROM product_sizes WHERE product_id=$editId");
      if ($resS) {
        while ($row = mysqli_fetch_assoc($resS)) {
          $label = $row['size_label'];
          if (isset($editSizes[$label])) {
            $editSizes[$label] = (int)$row['stock'];
          }
        }
      }
    }
  }
}

// Tambah / update produk
if ($_SERVER['REQUEST_METHOD']==='POST') {
  $action = $_POST['action'] ?? 'add';
  $name  = esc($conn, $_POST['name'] ?? '');
  $price = (int)($_POST['price'] ?? 0);
  $brand = esc($conn, $_POST['brand'] ?? '');
  $cat   = esc($conn, $_POST['category'] ?? 'Mens');

  // status coming soon
  $isComingSoon = isset($_POST['is_coming_soon']) ? 1 : 0;

  // handle upload gambar
  $img = '';
  if ($action === 'edit') {
    $idEdit = (int)($_POST['id'] ?? 0);
    if ($idEdit > 0) {
      $resImg = mysqli_query($conn, "SELECT image_url FROM products WHERE id=$idEdit LIMIT 1");
      if ($resImg && mysqli_num_rows($resImg) === 1) {
        $rowImg = mysqli_fetch_assoc($resImg);
        $img = $rowImg['image_url'];
      }
    }
  }

  if (isset($_FILES['image_file']) && $_FILES['image_file']['error'] === UPLOAD_ERR_OK) {
    $uploadDir = __DIR__ . '/../Foto product/';
    if (!is_dir($uploadDir)) {
      mkdir($uploadDir, 0777, true);
    }
    $tmpName  = $_FILES['image_file']['tmp_name'];
    $origName = $_FILES['image_file']['name'];
    $ext = strtolower(pathinfo($origName, PATHINFO_EXTENSION));
    $allowedExt = ['jpg','jpeg','png','webp'];
    if (in_array($ext, $allowedExt)) {
      $newName = 'prod_' . time() . '_' . mt_rand(1000,9999) . '.' . $ext;
      if (move_uploaded_file($tmpName, $uploadDir . $newName)) {
        $img = 'Foto product/' . $newName;
      } else {
        $err = 'Gagal mengupload gambar.';
      }
    } else {
      $err = 'Format gambar harus JPG, JPEG, PNG, atau WEBP.';
    }
  } else {
    if ($action === 'add') {
      $err = 'Gambar produk wajib diupload.';
    }
  }
  $img  = esc($conn, $img);
  $desc  = esc($conn, $_POST['description'] ?? '');

  // stok per ukuran (EU 27-45)
  $sizeStocks = [];
  $stock = 0;
  foreach ($SIZE_RANGE as $sz) {
    $key = 'stock_' . $sz;
    $qty = (int)($_POST[$key] ?? 0);
    if ($qty < 0) $qty = 0;
    $sizeStocks[(string)$sz] = $qty;
    $stock += $qty;
  }

  if (!$name || $price <= 0) {
    $err = 'Nama produk dan harga wajib diisi.';
  } else {
    if ($action === 'edit') {
      $id = (int)$_POST['id'];
      if ($id > 0) {
        $q = "UPDATE products SET 
                name='$name',
                price=$price,
                image_url='$img',
                category='$cat',
                brand='$brand',
                description='$desc',
                stock=$stock,
                is_coming_soon=$isComingSoon
              WHERE id=$id";
        if (mysqli_query($conn, $q)) {
          // refresh stok per ukuran di product_sizes
          mysqli_query($conn, "DELETE FROM product_sizes WHERE product_id=$id");
          foreach ($sizeStocks as $label => $qty) {
            if ((int)$qty > 0) {
              $lbl = esc($conn, (string)$label);
              $sq  = "INSERT INTO product_sizes (product_id,size_label,stock)
                      VALUES ($id,'$lbl',".(int)$qty.")";
              mysqli_query($conn, $sq);
            }
          }
          $ok = 'Produk berhasil diperbarui.';
        } else {
          $err = 'Gagal memperbarui produk: ' . mysqli_error($conn);
        }
      }
    } else {
      $q = "INSERT INTO products (name,price,image_url,category,brand,description,stock,is_coming_soon)
            VALUES ('$name',$price,'$img','$cat','$brand','$desc',$stock,$isComingSoon)";
      if (mysqli_query($conn, $q)) {
        $pid = mysqli_insert_id($conn);
        // simpan stok per ukuran ke product_sizes
        foreach ($sizeStocks as $label => $qty) {
          if ((int)$qty > 0) {
            $lbl = esc($conn, (string)$label);
            $sq  = "INSERT INTO product_sizes (product_id,size_label,stock)
                    VALUES ($pid,'$lbl',".(int)$qty.")";
            mysqli_query($conn, $sq);
          }
        }
        $ok = 'Produk baru berhasil ditambahkan.';
      } else {
        $err = 'Gagal menambah produk: ' . mysqli_error($conn);
      }
    }
  }
}

// Hapus produk
if (isset($_GET['delete'])) {
  $id = (int)$_GET['delete'];
  if ($id > 0) {
    // hapus stok size juga
    mysqli_query($conn, "DELETE FROM product_sizes WHERE product_id=$id");
    mysqli_query($conn, "DELETE FROM products WHERE id=$id");
    if (mysqli_affected_rows($conn) > 0) {
      $ok = 'Produk berhasil dihapus.';
    } else {
      $err = 'Gagal menghapus produk.';
    }
  }
}

// ---------------- FILTER & SEARCH ----------------
$where = "1";

$selectedCategory = $_GET['category'] ?? '';
$keyword          = trim($_GET['q'] ?? '');

// filter kategori / coming soon
if ($selectedCategory !== '') {
  $c = esc($conn, $selectedCategory);

  if ($c === 'ComingSoon') {
    $where .= " AND is_coming_soon = 1";
  } else {
    $where .= " AND category='$c' AND is_coming_soon = 0";
  }
}

// pencarian nama / brand
if ($keyword !== '') {
  $qEsc  = esc($conn, $keyword);
  $where .= " AND (name LIKE '%$qEsc%' OR brand LIKE '%$qEsc%')";
}

$r_prod = mysqli_query($conn, "SELECT * FROM products WHERE $where ORDER BY id DESC");
?>

    <div class="topbar">
      <div class="topbar-left">
        <h1>Kelola Produk</h1>
        <div class="breadcrumb">Admin / <span>Produk</span></div>
      </div>
      <div class="topbar-right"></div>
    </div>

    <div class="card">
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px;">
        <div>
          <h2>Tambah / Edit Produk</h2>
          <small>Data akan tampil dinamis di halaman pengguna (Mens, Womens, Kids, Discount, Coming Soon).</small>
        </div>
      </div>

      <?php if($err): ?>
        <div style="font-size:12px;color:#b91c1c;margin-bottom:6px;"><?php echo $err; ?></div>
      <?php elseif($ok): ?>
        <div style="font-size:12px;color:#166534;margin-bottom:6px;"><?php echo $ok; ?></div>
      <?php endif; ?>

      <form method="post" enctype="multipart/form-data">
        <input type="hidden" name="action" value="<?php echo $editProduct ? 'edit' : 'add'; ?>">
        <input type="hidden" name="id" value="<?php echo $editProduct['id'] ?? 0; ?>">
        <div class="form-grid">
          <div class="form-group">
            <label>Nama produk</label>
            <input type="text" name="name" required
                   value="<?php echo $editProduct ? htmlspecialchars($editProduct['name']) : ''; ?>">
          </div>
          <div class="form-group">
            <label>Harga (Rp)</label>
            <input type="number" name="price" min="0" required
                   value="<?php echo $editProduct ? (int)$editProduct['price'] : 0; ?>">
          </div>
          <div class="form-group">
            <label>Brand</label>
            <input type="text" name="brand" placeholder="Nike / Adidas / Puma ..."
                   value="<?php echo $editProduct ? htmlspecialchars($editProduct['brand']) : ''; ?>">
          </div>
          <div class="form-group">
            <label>Kategori</label>
            <select name="category" id="category-select">
              <?php
              $catVal = $editProduct['category'] ?? 'Mens';
              $cats = ['Mens','Womens','Kids','Discount'];
              foreach ($cats as $c) {
                $sel = ($c === $catVal) ? 'selected' : '';
                echo "<option value=\"$c\" $sel>$c</option>";
              }
              ?>
            </select>
            <small id="coming-soon-hint" style="display:none;font-size:11px;color:#b91c1c;">
              Saat Coming Soon aktif, produk tidak tampil di halaman kategori.
            </small>
          </div>
          <div class="form-group">
            <label>Gambar Produk</label>
            <?php if ($editProduct && !empty($editProduct['image_url'])): ?>
              <div style="font-size:12px;margin-bottom:4px;">
                Gambar saat ini: <code><?php echo htmlspecialchars($editProduct['image_url']); ?></code>
              </div>
            <?php endif; ?>
            <input type="file" name="image_file" accept=".jpg,.jpeg,.png,.webp">
            <small style="font-size:11px;color:#6b7280;">Jika tidak diisi saat edit, gambar lama akan dipakai.</small>
          </div>

          <!-- Coming Soon -->
          <div class="form-group" style="grid-column:1/-1;">
            <label>Coming Soon?</label>
            <label style="display:flex;align-items:center;gap:8px;font-size:13px;">
              <input type="checkbox" name="is_coming_soon" id="is-coming-soon" value="1"
                <?php
                if ($editProduct && !empty($editProduct['is_coming_soon'])) {
                  echo 'checked';
                }
                ?>
              >
              <span>Tandai produk ini sebagai Coming Soon (hanya tampil di Home).</span>
            </label>
          </div>

          <!-- Stok per ukuran (EU 27-45) -->
          <div class="form-group" style="grid-column:1/-1;">
            <label>Stok per Ukuran (EU 27 - 45)</label>
            <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(120px,1fr));gap:10px;">
              <?php foreach ($SIZE_RANGE as $sz): $k = (string)$sz; ?>
                <div>
                  <div style="font-size:12px;color:#374151;margin-bottom:4px;font-weight:500;">EU <?php echo $k; ?></div>
                  <input type="number" name="stock_<?php echo $k; ?>" min="0"
                         value="<?php echo (int)($editSizes[$k] ?? 0); ?>"
                         style="width:100%;">
                </div>
              <?php endforeach; ?>
            </div>
            <small style="font-size:11px;color:#6b7280;display:block;margin-top:6px;">
              Isi stok untuk ukuran yang tersedia. Ukuran dengan stok 0 tidak akan tampil di pilihan ukuran pada web pengguna.
            </small>
          </div>

          <div class="form-group" style="grid-column:1/-1;">
            <label>Deskripsi</label>
            <textarea name="description" placeholder="Deskripsi singkat produk..."><?php 
              echo $editProduct ? htmlspecialchars($editProduct['description']) : ''; ?></textarea>
          </div>
        </div>
        <div style="margin-top:8px;">
          <button type="submit" class="btn btn-primary">
            <i class='bx bx-save'></i>
            <?php echo $editProduct ? 'Update produk' : 'Simpan produk baru'; ?>
          </button>
          <?php if ($editProduct): ?>
            <a href="products.php" class="btn btn-secondary" style="margin-left:8px;">Batal edit</a>
          <?php endif; ?>
        </div>
      </form>
    </div>

    <div class="card" style="margin-top:12px;">
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px;">
        <div>
          <h2>Daftar Produk</h2>
          <small>Produk yang tersimpan di database.</small>
        </div>

        <!-- FORM FILTER + SEARCH -->
        <form method="get"
              id="product-filter-form"
              style="display:flex;align-items:center;gap:6px;font-size:12px;flex-wrap:wrap;justify-content:flex-end;">
          <select
            name="category"
            style="padding:6px 8px;border-radius:999px;border:1px solid #e5e7eb;font-size:12px;"
            onchange="document.getElementById('product-filter-form').submit()"
          >
            <option value="">Semua kategori</option>
            <option value="Mens"       <?php if($selectedCategory==='Mens') echo 'selected'; ?>>Mens</option>
            <option value="Womens"     <?php if($selectedCategory==='Womens') echo 'selected'; ?>>Womens</option>
            <option value="Kids"       <?php if($selectedCategory==='Kids') echo 'selected'; ?>>Kids</option>
            <option value="Discount"   <?php if($selectedCategory==='Discount') echo 'selected'; ?>>Discount</option>
            <option value="ComingSoon" <?php if($selectedCategory==='ComingSoon') echo 'selected'; ?>>Coming Soon</option>
          </select>

          <!-- search bar nama / brand -->
          <div style="display:flex;align-items:center;gap:4px;">
            <input
              type="text"
              name="q"
              placeholder="Cari nama / brand..."
              value="<?php echo htmlspecialchars($keyword); ?>"
              style="padding:6px 10px;border-radius:999px;border:1px solid #e5e7eb;font-size:12px;min-width:160px;"
            >
            <button type="submit"
                    class="btn btn-outline"
                    style="padding:6px 10px;font-size:12px;display:inline-flex;align-items:center;gap:4px;">
              <i class="bx bx-search"></i>
              <span>Cari</span>
            </button>
          </div>
        </form>
      </div>

      <div class="table-wrapper">
        <table>
          <thead>
            <tr>
              <th>ID</th>
              <th>Gambar</th>
              <th>Nama</th>
              <th>Brand</th>
              <th>Kategori</th>
              <th>Harga</th>
              <th>Stok</th>
              <th>Coming</th>
              <th>Dibuat</th>
              <th>Aksi</th>
            </tr>
          </thead>
          <tbody>
            <?php if($r_prod && mysqli_num_rows($r_prod)>0): ?>
              <?php while($p = mysqli_fetch_assoc($r_prod)): ?>
                <tr>
                  <td><?php echo $p['id']; ?></td>

                  <!-- thumbnail gambar -->
                  <td>
                    <?php if(!empty($p['image_url'])): ?>
                      <img 
                        src="../<?php echo htmlspecialchars($p['image_url']); ?>" 
                        alt="<?php echo htmlspecialchars($p['name']); ?>" 
                        style="width:60px;height:60px;object-fit:cover;border-radius:8px;border:1px solid #e5e7eb;">
                    <?php else: ?>
                      -
                    <?php endif; ?>
                  </td>

                  <td><?php echo htmlspecialchars($p['name']); ?></td>
                  <td><?php echo htmlspecialchars($p['brand']); ?></td>

                  <!-- kategori: kosongkan kalau Coming Soon -->
                  <td>
                    <?php
                      if (!empty($p['is_coming_soon'])) {
                        echo '-';
                      } else {
                        echo htmlspecialchars($p['category']);
                      }
                    ?>
                  </td>

                  <td>Rp <?php echo number_format($p['price'],0,',','.'); ?></td>
                  <td><?php echo (int)$p['stock']; ?></td>

                  <!-- status Coming -->
                  <td><?php echo !empty($p['is_coming_soon']) ? 'Coming Soon' : '-'; ?></td>

                  <td><?php echo date('d-m-Y', strtotime($p['created_at'])); ?></td>
                  <td>
                    <a href="products.php?edit=<?php echo $p['id']; ?>" class="btn btn-outline" style="padding:4px 10px;margin-right:4px;">
                      <i class='bx bx-edit'></i>
                    </a>
                    <a href="products.php?delete=<?php echo $p['id']; ?>" onclick="return confirm('Hapus produk ini?');" class="btn btn-danger" style="padding:4px 10px;">
                      <i class='bx bx-trash'></i>
                    </a>
                  </td>
                </tr>
              <?php endwhile; ?>
            <?php else: ?>
              <tr><td colspan="10">Belum ada produk yang sesuai filter / pencarian.</td></tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>

    <div class="footer-admin">
      <span>© 2025 AFK FOOTWEAR Admin.</span>
      <span>Frontend terhubung ke <a href="../index.php">website pengguna</a></span>
    </div>
  </main>
</div>

<!-- JS kecil: coming soon + simpan posisi scroll saat filter/search -->
<script>
document.addEventListener("DOMContentLoaded", function () {
  // ====== Coming Soon toggle ======
  const cbComing = document.getElementById("is-coming-soon");
  const selCat   = document.getElementById("category-select");
  const hint     = document.getElementById("coming-soon-hint");

  function updateCategoryState() {
    if (!cbComing || !selCat) return;
    if (cbComing.checked) {
      selCat.disabled = true;
      selCat.style.opacity = "0.6";
      if (hint) hint.style.display = "block";
    } else {
      selCat.disabled = false;
      selCat.style.opacity = "1";
      if (hint) hint.style.display = "none";
    }
  }

  if (cbComing) {
    cbComing.addEventListener("change", updateCategoryState);
    updateCategoryState(); // set awal
  }

  // ====== Simpan & restore posisi scroll untuk filter/search ======
  const filterForm = document.getElementById("product-filter-form");
  const SCROLL_KEY = "afk_products_scrollY";
  const FLAG_KEY   = "afk_products_restore";

  if (filterForm) {
    filterForm.addEventListener("submit", function () {
      // simpan posisi scroll sebelum submit
      sessionStorage.setItem(SCROLL_KEY, String(window.scrollY || window.pageYOffset || 0));
      sessionStorage.setItem(FLAG_KEY, "1");
    });
  }

  // setelah reload: kalau tadi submit filter/search, balikin scroll
  if (sessionStorage.getItem(FLAG_KEY) === "1") {
    const y = parseInt(sessionStorage.getItem(SCROLL_KEY) || "0", 10);
    if (!isNaN(y)) {
      window.scrollTo(0, y);
    }
    sessionStorage.removeItem(FLAG_KEY);
    sessionStorage.removeItem(SCROLL_KEY);
  }
});
</script>

</body>
</html>
