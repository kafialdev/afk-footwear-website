<?php
require_once __DIR__ . '/../db.php';
session_start();

// proteksi: hanya admin
if (empty($_SESSION['admin_id'])) {
  header('Location: login.php');
  exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Customer - AFK Footwear Admin</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
  <link href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet">
  <link rel="stylesheet" href="assets/admin.css">
</head>
<body>
<div class="admin-layout">
  <aside class="sidebar">
    <div class="sidebar-logo">
      <img src="../IMG/LOGO.jpg" alt="AFK FOOTWEAR">
      <div>
        <div class="logo-text-title">AFK FOOTWEAR</div>
        <div class="logo-text-sub">Admin Panel</div>
      </div>
    </div>

    <div class="sidebar-section-title">Menu utama</div>
    <ul class="nav-list">
      <li class="nav-item ">
        <a href="index.php"><i class='bx bxs-dashboard'></i><span>Dashboard</span></a>
      </li>
      <li class="nav-item ">
        <a href="products.php"><i class='bx bx-box'></i><span>Produk</span></a>
      </li>
      <li class="nav-item ">
        <a href="orders.php"><i class='bx bx-cart'></i><span>Order</span></a>
      </li>
      <li class="nav-item active">
        <a href="customers.php"><i class='bx bx-user'></i><span>Customer</span></a>
      </li>
      <li class="nav-item ">
        <a href="returns.php"><i class='bx bx-undo'></i><span>Return</span></a>
      </li>
      <li class="nav-item ">
        <a href="reports.php"><i class='bx bx-bar-chart-alt-2'></i><span>Laporan</span></a>
      </li>
    </ul>

    <div class="sidebar-section-title">Session</div>
    <ul class="nav-list">
      <li class="nav-item">
        <a href="logout.php"><i class='bx bx-log-out-circle'></i><span>Logout</span></a>
      </li>
    </ul>

    <div class="sidebar-footer">
      Login sebagai <span><?php echo htmlspecialchars($_SESSION['admin_name'] ?? 'Admin'); ?></span><br>
      A.F.K Footwear &copy; 2025
    </div>
  </aside>

  <main class="main">
<?php
$err = '';
$ok  = '';

// hapus customer
if (isset($_GET['delete'])) {
  $id = (int)$_GET['delete'];
  if ($id > 0) {
    mysqli_query($conn, "DELETE FROM users WHERE id=$id AND role='customer'");
    if (mysqli_affected_rows($conn) > 0) {
      $ok = 'Customer berhasil dihapus.';
    } else {
      $err = 'Gagal menghapus customer.';
    }
  }
}

// search customer berdasarkan nama (name)
$search = trim($_GET['q'] ?? '');
$where  = "WHERE role='customer'";

if ($search !== '') {
  $safeSearch = mysqli_real_escape_string($conn, $search);
  $where     .= " AND name LIKE '%{$safeSearch}%'";
}

$r_cust = mysqli_query($conn, "SELECT * FROM users {$where} ORDER BY created_at DESC");
?>
    <div class="topbar">
      <div class="topbar-left">
        <h1>Data Customer</h1>
        <div class="breadcrumb">Admin / <span>Customer</span></div>
      </div>
    </div>

    <div class="card">
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px;gap:10px;flex-wrap:wrap;">
        <div>
          <h2>Customer Terdaftar</h2>
          <small>Akun yang dibuat dari halaman Sign In / proses checkout.</small>
        </div>

        <!-- SEARCH BAR -->
        <form method="get" style="display:flex;align-items:center;gap:6px;">
          <input
            type="text"
            name="q"
            placeholder="Cari nama customer..."
            value="<?php echo htmlspecialchars($search, ENT_QUOTES, 'UTF-8'); ?>"
            style="padding:6px 10px;border-radius:999px;border:1px solid #d1d5db;font-size:0.85rem;min-width:180px;"
          >
          <button
            type="submit"
            class="btn"
            style="padding:6px 12px;font-size:0.85rem;border-radius:999px;"
          >
            <i class='bx bx-search'></i> Cari
          </button>
          <?php if ($search !== ''): ?>
            <a
              href="customers.php"
              style="padding:6px 10px;font-size:0.8rem;border-radius:999px;border:1px solid #e5e7eb;text-decoration:none;color:#4b5563;"
            >
              Reset
            </a>
          <?php endif; ?>
        </form>
      </div>

      <?php if($err): ?>
        <div style="font-size:12px;color:#b91c1c;margin-bottom:6px;"><?php echo $err; ?></div>
      <?php elseif($ok): ?>
        <div style="font-size:12px;color:#166534;margin-bottom:6px;"><?php echo $ok; ?></div>
      <?php endif; ?>

      <div class="table-wrapper">
        <table>
          <thead>
            <tr>
              <th>ID</th>
              <th>Nama</th>
              <th>Username</th>
              <th>Email</th>
              <th>Tanggal Daftar</th>
              <th>Aksi</th>
            </tr>
          </thead>
          <tbody>
            <?php if($r_cust && mysqli_num_rows($r_cust)>0): ?>
              <?php while($u = mysqli_fetch_assoc($r_cust)): ?>
                <?php
                  // buat URL hapus yang tetap membawa query pencarian (kalau ada)
                  $deleteUrl = '?delete=' . (int)$u['id'];
                  if ($search !== '') {
                    $deleteUrl .= '&q=' . urlencode($search);
                  }
                ?>
                <tr>
                  <td><?php echo $u['id']; ?></td>
                  <td><?php echo htmlspecialchars($u['name']); ?></td>
                  <td><?php echo htmlspecialchars($u['username']); ?></td>
                  <td><?php echo htmlspecialchars($u['email']); ?></td>
                  <td><?php echo date('d-m-Y', strtotime($u['created_at'])); ?></td>
                  <td>
                    <a href="<?php echo $deleteUrl; ?>" onclick="return confirm('Hapus customer ini?');" class="btn btn-danger" style="padding:4px 10px;">
                      <i class='bx bx-trash'></i>
                    </a>
                  </td>
                </tr>
              <?php endwhile; ?>
            <?php else: ?>
              <tr>
                <td colspan="6">
                  <?php if ($search !== ''): ?>
                    Tidak ada customer dengan nama "<strong><?php echo htmlspecialchars($search); ?></strong>".
                  <?php else: ?>
                    Belum ada customer.
                  <?php endif; ?>
                </td>
              </tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>

    <div class="footer-admin">
      <span>© 2025 AFK FOOTWEAR Admin.</span>
      <span>Frontend terhubung ke <a href="../index.php">website pengguna</a></span>
    </div>
  </main>
</div>
</body>
</html>
