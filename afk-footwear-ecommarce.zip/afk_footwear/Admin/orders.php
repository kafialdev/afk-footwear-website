<?php
require_once __DIR__ . '/../db.php';
session_start();

// proteksi: hanya admin
if (empty($_SESSION['admin_id'])) {
  header('Location: login.php');
  exit;
}

// status yang diizinkan
$allowedStatus = ['Baru','Diproses','Dikirim','Selesai','Dibatalkan'];

// ====== PROSES UPDATE STATUS (POST -> REDIRECT -> GET) ======
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['order_id'], $_POST['status'])) {
  $orderId = (int)($_POST['order_id'] ?? 0);
  $status  = $_POST['status'] ?? 'Baru';

  if ($orderId > 0 && in_array($status, $allowedStatus, true)) {
    $stmt = $conn->prepare("UPDATE orders SET status=? WHERE id=?");
    if ($stmt) {
      $stmt->bind_param('si', $status, $orderId);
      $stmt->execute();
      $stmt->close();
    }
  }

  // redirect supaya tidak ada Confirm Form Resubmission saat refresh
  // (filter_status ikut dibawa jika sedang aktif)
  $qs = [];
  if (!empty($_GET['filter_status'])) {
    $qs[] = 'filter_status=' . urlencode($_GET['filter_status']);
  }
  $qs[] = 'updated=1';
  $queryString = $qs ? ('?' . implode('&', $qs)) : '';

  header('Location: orders.php' . $queryString);
  exit;
}

// ====== FILTER STATUS (GET) ======
$currentFilter = $_GET['filter_status'] ?? 'all';
if ($currentFilter !== 'all' && !in_array($currentFilter, $allowedStatus, true)) {
  $currentFilter = 'all';
}

$whereStatusSql = '';
if ($currentFilter !== 'all') {
  $safeStatus = mysqli_real_escape_string($conn, $currentFilter);
  $whereStatusSql = "WHERE o.status = '{$safeStatus}'";
}

// ambil semua order + nama customer + info bukti pembayaran (kalau ada)
$sql = "
  SELECT 
      o.*,
      u.name AS customer,
      pp.proof_path,
      pp.payment_method AS proof_payment_method
   FROM orders o
   JOIN users u ON u.id = o.user_id
   LEFT JOIN payment_proofs pp 
     ON pp.order_code = CONCAT('AFK', LPAD(o.id,4,'0'))
   {$whereStatusSql}
   ORDER BY o.created_at DESC
";
$r_ord = mysqli_query($conn, $sql);
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Order - AFK Footwear Admin</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
  <link href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet">
  <link rel="stylesheet" href="assets/admin.css">

  <style>
    /* Badge metode pembayaran */
    .pm-badge{
      display:inline-flex;
      align-items:center;
      padding:4px 8px;
      border-radius:999px;
      font-size:0.75rem;
      font-weight:600;
      gap:4px;
      border:1px solid transparent;
    }
    .pm-badge i{
      font-size:1rem;
    }
    .pm-bank{
      background:#e0f2fe;
      color:#0369a1;
      border-color:#bae6fd;
    }
    .pm-qris{
      background:#fef3c7;
      color:#92400e;
      border-color:#fde68a;
    }
    .pm-cod{
      background:#dcfce7;
      color:#166534;
      border-color:#bbf7d0;
    }
    .pm-other{
      background:#f3f4f6;
      color:#374151;
      border-color:#e5e7eb;
    }

    /* link bukti pembayaran */
    .proof-link{
      display:inline-flex;
      align-items:center;
      gap:6px;
      padding:4px 8px;
      border-radius:999px;
      background:#111827;
      color:#f9fafb;
      font-size:0.75rem;
      text-decoration:none;
    }
    .proof-link i{
      font-size:1rem;
    }
    .proof-empty{
      font-size:0.8rem;
      color:#6b7280;
      font-style:italic;
    }

    .btn.btn-xs{
      padding:4px 10px;
      font-size:0.8rem;
      border-radius:999px;
    }

    .status-select{
      font-size:0.8rem;
      padding:4px 6px;
      border-radius:6px;
    }

    /* FILTER BAR */
    .filter-row{
      display:flex;
      justify-content:flex-end;
      align-items:center;
      gap:8px;
      margin-bottom:10px;
      flex-wrap:wrap;
    }
    .filter-row label{
      font-size:0.85rem;
      color:#6b7280;
    }
    .filter-row select{
      padding:4px 10px;
      border-radius:999px;
      font-size:0.85rem;
    }
    .alert-updated{
      margin-top:6px;
      font-size:0.8rem;
      color:#16a34a;
    }
  </style>
</head>
<body>
<div class="admin-layout">
  <aside class="sidebar">
    <div class="sidebar-logo">
      <img src="../IMG/LOGO.jpg" alt="AFK FOOTWEAR">
      <div>
        <div class="logo-text-title">AFK FOOTWEAR</div>
        <div class="logo-text-sub">Admin Panel</div>
      </div>
    </div>

    <div class="sidebar-section-title">Menu utama</div>
    <ul class="nav-list">
      <li class="nav-item ">
        <a href="index.php"><i class='bx bxs-dashboard'></i><span>Dashboard</span></a>
      </li>
      <li class="nav-item ">
        <a href="products.php"><i class='bx bx-box'></i><span>Produk</span></a>
      </li>
      <li class="nav-item active">
        <a href="orders.php"><i class='bx bx-cart'></i><span>Order</span></a>
      </li>
      <li class="nav-item ">
        <a href="customers.php"><i class='bx bx-user'></i><span>Customer</span></a>
      </li>
      <li class="nav-item ">
        <a href="returns.php"><i class='bx bx-undo'></i><span>Return</span></a>
      </li>
      <li class="nav-item ">
        <a href="reports.php"><i class='bx bx-bar-chart-alt-2'></i><span>Laporan</span></a>
      </li>
    </ul>

    <div class="sidebar-section-title">Session</div>
    <ul class="nav-list">
      <li class="nav-item">
        <a href="logout.php"><i class='bx bx-log-out-circle'></i><span>Logout</span></a>
      </li>
    </ul>

    <div class="sidebar-footer">
      Login sebagai <span><?php echo htmlspecialchars($_SESSION['admin_name'] ?? 'Admin'); ?></span><br>
      A.F.K Footwear &copy; 2025
    </div>
  </aside>

  <main class="main">
    <div class="topbar">
      <div class="topbar-left">
        <h1>Daftar Order</h1>
        <div class="breadcrumb">Admin / <span>Order</span></div>
      </div>
    </div>

    <div class="card">
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px;">
        <div>
          <h2>Order Masuk</h2>
          <small>Semua order yang tercatat di sistem.</small>
          <?php if (!empty($_GET['updated'])): ?>
            <div class="alert-updated">Status order berhasil diperbarui.</div>
          <?php endif; ?>
        </div>
      </div>

      <!-- FILTER STATUS -->
      <?php
        $statusLabelMap = [
          'Baru'       => 'Processed',
          'Diproses'   => 'Shipped',
          'Dikirim'    => 'Out for Delivery',
          'Selesai'    => 'Delivered',
          'Dibatalkan' => 'Cancelled'
        ];
      ?>
      <div class="filter-row">
        <form method="get" class="filter-form">
          <label for="filter_status">Filter status:</label>
          <select name="filter_status" id="filter_status" onchange="this.form.submit()">
            <option value="all" <?php echo ($currentFilter === 'all' ? 'selected' : ''); ?>>Semua Status</option>
            <?php foreach ($statusLabelMap as $code => $label): ?>
              <option value="<?php echo $code; ?>" <?php echo ($currentFilter === $code ? 'selected' : ''); ?>>
                <?php echo htmlspecialchars($label); ?>
              </option>
            <?php endforeach; ?>
          </select>
          <noscript>
            <button type="submit" class="btn btn-xs">Terapkan</button>
          </noscript>
        </form>
      </div>

      <div class="table-wrapper">
        <table>
          <thead>
            <tr>
              <th>ID Order</th>
              <th>Customer</th>
              <th>Items</th>
              <th>Total</th>
              <th>Metode</th>
              <th>Bukti Pembayaran</th>
              <th>Status</th>
              <th>Tanggal</th>
            </tr>
          </thead>

          <tbody>
            <?php if($r_ord && mysqli_num_rows($r_ord)>0): ?>
              <?php while($o = mysqli_fetch_assoc($r_ord)): ?>
                <?php
                  // ringkasan items per order
                  $oid = (int)$o['id'];
                  $itemCount = 0;
                  $itemSummary = '-';
                  if ($stmtItems = $conn->prepare("
                    SELECT 
                      SUM(quantity) AS qty_total,
                      GROUP_CONCAT(CONCAT(p.name,' (',oi.quantity,'x)') SEPARATOR ', ') AS items
                    FROM order_items oi
                    JOIN products p ON p.id = oi.product_id
                    WHERE oi.order_id = ?
                  ")) {
                    $stmtItems->bind_param('i', $oid);
                    $stmtItems->execute();
                    $resItems = $stmtItems->get_result();
                    if ($rowItems = $resItems->fetch_assoc()) {
                      $itemCount   = (int)($rowItems['qty_total'] ?? 0);
                      $itemSummary = $rowItems['items'] ?: '-';
                    }
                    $stmtItems->close();
                  }
                ?>
                <tr>
                  <td>#AFK<?php echo str_pad($o['id'],4,'0',STR_PAD_LEFT); ?></td>
                  <td><?php echo htmlspecialchars($o['customer']); ?></td>
                  <td>
                    <?php if ($itemCount > 0): ?>
                      <strong><?php echo $itemCount; ?> item</strong><br>
                      <small><?php echo htmlspecialchars($itemSummary); ?></small>
                    <?php else: ?>
                      -
                    <?php endif; ?>
                  </td>
                  <td>Rp <?php echo number_format($o['total_amount'],0,',','.'); ?></td>

                  <!-- METODE PEMBAYARAN (badge) -->
                  <td>
                    <?php
                      // ambil dari orders.payment_method, kalau kosong pakai dari payment_proofs
                      $pmRaw = trim($o['payment_method'] ?? '');
                      if ($pmRaw === '' && !empty($o['proof_payment_method'])) {
                        $pmRaw = trim($o['proof_payment_method']);
                      }

                      // mapping ENUM ke label user-friendly
                      $pmLabelMap = [
                        'Transfer' => 'Bank Transfer',
                        'COD'      => 'Cash on Delivery',
                        // di sistem ini, nilai 'E-Wallet' hanya dipakai untuk pembayaran QRIS
                        'E-Wallet' => 'QRIS'
                      ];
                      $pmLabel = $pmLabelMap[$pmRaw] ?? ($pmRaw !== '' ? $pmRaw : 'Tidak diketahui');

                      // pilih kelas badge
                      $pmClass = 'pm-badge pm-other';
                      if ($pmRaw === 'E-Wallet' || stripos($pmLabel,'qris') !== false) {
                        $pmClass = 'pm-badge pm-qris';
                      } elseif ($pmRaw === 'Transfer') {
                        $pmClass = 'pm-badge pm-bank';
                      } elseif ($pmRaw === 'COD') {
                        $pmClass = 'pm-badge pm-cod';
                      }
                    ?>
                    <span class="<?php echo $pmClass; ?>">
                      <?php if ($pmRaw === 'E-Wallet'): ?>
                        <i class='bx bx-qr'></i>
                      <?php else: ?>
                        <i class='bx bx-credit-card'></i>
                      <?php endif; ?>
                      <?php echo htmlspecialchars($pmLabel); ?>
                    </span>
                  </td>

                  <!-- BUKTI PEMBAYARAN -->
                  <td>
                    <?php
                      $proofPath = $o['proof_path'] ?? '';
                      if (!empty($proofPath)) {
                        // path relatif dari root -> di-admin perlu ../
                        $proofUrl = '../' . ltrim($proofPath, '/');
                    ?>
                        <a href="<?php echo htmlspecialchars($proofUrl); ?>" target="_blank" class="proof-link">
                          <i class='bx bx-image'></i>
                          <span>Lihat Bukti</span>
                        </a>
                    <?php
                      } else {
                        echo '<span class="proof-empty">Belum ada bukti</span>';
                      }
                    ?>
                  </td>

                  <!-- STATUS -->
                  <td>
                    <?php
                      // kelas status (kalau mau dipakai di CSS global)
                      $cls = 'status-new';
                      if ($o['status']==='Diproses')   $cls='status-process';
                      if ($o['status']==='Dikirim')    $cls='status-otw';
                      if ($o['status']==='Selesai')    $cls='status-done';
                      if ($o['status']==='Dibatalkan') $cls='status-cancel';

                      // mapping kode status di DB -> label UI user
                      // (sudah didefinisikan di atas, pakai lagi di sini)
                    ?>
                    <form method="post" style="display:flex;align-items:center;gap:6px;">
                      <input type="hidden" name="order_id" value="<?php echo (int)$o['id']; ?>">

                      <select name="status" class="status-select">
                        <?php
                          $opts = ['Baru','Diproses','Dikirim','Selesai','Dibatalkan'];
                          foreach ($opts as $code) {
                            $sel   = $o['status'] === $code ? 'selected' : '';
                            $label = $statusLabelMap[$code] ?? $code;
                            echo "<option value=\"$code\" $sel>$label</option>";
                          }
                        ?>
                      </select>

                      <button type="submit" class="btn btn-xs">Simpan</button>
                    </form>
                  </td>

                  <td><?php echo date('d-m-Y H:i', strtotime($o['created_at'])); ?></td>
                </tr>
              <?php endwhile; ?>
            <?php else: ?>
              <tr><td colspan="8">Belum ada order.</td></tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>

    <div class="footer-admin">
      <span>© 2025 AFK FOOTWEAR Admin.</span>
      <span>Frontend terhubung ke <a href="../index.php">website pengguna</a></span>
    </div>
  </main>
</div>
</body>
</html>
