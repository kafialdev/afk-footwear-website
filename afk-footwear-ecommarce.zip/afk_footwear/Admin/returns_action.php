<?php
require_once __DIR__ . '/../db.php';
session_start();

// proteksi: hanya admin
if (empty($_SESSION['admin_id'])) {
  header('Location: login.php');
  exit;
}

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$action = strtolower(trim($_GET['action'] ?? ''));

if ($id <= 0 || !in_array($action, ['approve','reject'], true)) {
  header('Location: returns.php');
  exit;
}

$newStatus = ($action === 'approve') ? 'approved' : 'rejected';

$stmt = @$conn->prepare("UPDATE returns SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ? LIMIT 1");
if ($stmt) {
  $stmt->bind_param('si', $newStatus, $id);
  @$stmt->execute();
  $stmt->close();
}

header('Location: returns.php');
exit;
