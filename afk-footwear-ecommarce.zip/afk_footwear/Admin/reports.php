<?php
require_once __DIR__ . '/../db.php';
session_start();

// proteksi: hanya admin
if (empty($_SESSION['admin_id'])) {
  header('Location: login.php');
  exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Laporan - AFK Footwear Admin</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
  <link href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet">
  <link rel="stylesheet" href="assets/admin.css">
  <style>
    /* KPI kecil untuk ringkasan return (hanya untuk halaman laporan) */
    .kpi{background:#fff;border:1px solid rgba(13, 32, 68, .08);border-radius:14px;padding:14px;}
    .kpi-label{color:#64748b;font-size:12px;font-weight:600;margin-bottom:6px;}
    .kpi-value{color:#0f172a;font-size:22px;font-weight:700;}
    @media (max-width: 720px){
      .kpi-value{font-size:18px;}
    }
  </style>
</head>
<body>
<div class="admin-layout">
  <aside class="sidebar">
    <div class="sidebar-logo">
      <img src="../IMG/LOGO.jpg" alt="AFK FOOTWEAR">
      <div>
        <div class="logo-text-title">AFK FOOTWEAR</div>
        <div class="logo-text-sub">Admin Panel</div>
      </div>
    </div>

    <div class="sidebar-section-title">Menu utama</div>
    <ul class="nav-list">
      <li class="nav-item ">
        <a href="index.php"><i class='bx bxs-dashboard'></i><span>Dashboard</span></a>
      </li>
      <li class="nav-item ">
        <a href="products.php"><i class='bx bx-box'></i><span>Produk</span></a>
      </li>
      <li class="nav-item ">
        <a href="orders.php"><i class='bx bx-cart'></i><span>Order</span></a>
      </li>
      <li class="nav-item ">
        <a href="customers.php"><i class='bx bx-user'></i><span>Customer</span></a>
      </li>
      <li class="nav-item ">
        <a href="returns.php"><i class='bx bx-undo'></i><span>Return</span></a>
      </li>
      <li class="nav-item active">
        <a href="reports.php"><i class='bx bx-bar-chart-alt-2'></i><span>Laporan</span></a>
      </li>
    </ul>

    <div class="sidebar-section-title">Session</div>
    <ul class="nav-list">
      <li class="nav-item">
        <a href="logout.php"><i class='bx bx-log-out-circle'></i><span>Logout</span></a>
      </li>
    </ul>

    <div class="sidebar-footer">
      Login sebagai <span><?php echo htmlspecialchars($_SESSION['admin_name'] ?? 'Admin'); ?></span><br>
      A.F.K Footwear &copy; 2025
    </div>
  </aside>

  <main class="main">
<?php
// Rekap harian (Gross / Return / Net)
// Return dihitung dari tabel `returns` dengan status 'approved'.
// Nilai return:
// - Jika product_id terisi: subtotal item (price*qty) dari order_items
// - Jika product_id NULL: fallback ke total_amount order
$r_daily = mysqli_query($conn, "
  SELECT
    DATE(o.created_at) AS tgl,
    COUNT(DISTINCT o.id) AS total_order,
    COALESCE(SUM(o.total_amount),0) AS gross_amount,
    COALESCE(rr.return_count,0) AS return_count,
    COALESCE(rr.return_amount,0) AS return_amount
  FROM orders o
  LEFT JOIN (
    SELECT
      DATE(COALESCE(r.updated_at, r.created_at)) AS tgl,
      COUNT(*) AS return_count,
      SUM(
        CASE
          WHEN r.product_id IS NOT NULL THEN COALESCE(oi.price * oi.quantity, 0)
          ELSE COALESCE(o2.total_amount, 0)
        END
      ) AS return_amount
    FROM returns r
    LEFT JOIN orders o2 ON o2.id = r.order_id
    LEFT JOIN order_items oi ON oi.order_id = r.order_id AND (r.product_id IS NULL OR oi.product_id = r.product_id)
    WHERE r.status = 'approved'
    GROUP BY DATE(COALESCE(r.updated_at, r.created_at))
  ) rr ON rr.tgl = DATE(o.created_at)
  WHERE o.status IN ('Diproses','Dikirim','Selesai')
  GROUP BY DATE(o.created_at)
  ORDER BY tgl DESC
");

// Rekap bulanan (Gross / Return / Net)
$r_monthly = mysqli_query($conn, "
  SELECT
    DATE_FORMAT(o.created_at,'%Y-%m') AS ym,
    COUNT(DISTINCT o.id) AS total_order,
    COALESCE(SUM(o.total_amount),0) AS gross_amount,
    COALESCE(rr.return_count,0) AS return_count,
    COALESCE(rr.return_amount,0) AS return_amount
  FROM orders o
  LEFT JOIN (
    SELECT
      DATE_FORMAT(COALESCE(r.updated_at, r.created_at),'%Y-%m') AS ym,
      COUNT(*) AS return_count,
      SUM(
        CASE
          WHEN r.product_id IS NOT NULL THEN COALESCE(oi.price * oi.quantity, 0)
          ELSE COALESCE(o2.total_amount, 0)
        END
      ) AS return_amount
    FROM returns r
    LEFT JOIN orders o2 ON o2.id = r.order_id
    LEFT JOIN order_items oi ON oi.order_id = r.order_id AND (r.product_id IS NULL OR oi.product_id = r.product_id)
    WHERE r.status = 'approved'
    GROUP BY DATE_FORMAT(COALESCE(r.updated_at, r.created_at),'%Y-%m')
  ) rr ON rr.ym = DATE_FORMAT(o.created_at,'%Y-%m')
  WHERE o.status IN ('Diproses','Dikirim','Selesai')
  GROUP BY DATE_FORMAT(o.created_at,'%Y-%m')
  ORDER BY ym DESC
");

// Rekap tahunan (Gross / Return / Net)
$r_yearly = mysqli_query($conn, "
  SELECT
    DATE_FORMAT(o.created_at,'%Y') AS yy,
    COUNT(DISTINCT o.id) AS total_order,
    COALESCE(SUM(o.total_amount),0) AS gross_amount,
    COALESCE(rr.return_count,0) AS return_count,
    COALESCE(rr.return_amount,0) AS return_amount
  FROM orders o
  LEFT JOIN (
    SELECT
      DATE_FORMAT(COALESCE(r.updated_at, r.created_at),'%Y') AS yy,
      COUNT(*) AS return_count,
      SUM(
        CASE
          WHEN r.product_id IS NOT NULL THEN COALESCE(oi.price * oi.quantity, 0)
          ELSE COALESCE(o2.total_amount, 0)
        END
      ) AS return_amount
    FROM returns r
    LEFT JOIN orders o2 ON o2.id = r.order_id
    LEFT JOIN order_items oi ON oi.order_id = r.order_id AND (r.product_id IS NULL OR oi.product_id = r.product_id)
    WHERE r.status = 'approved'
    GROUP BY DATE_FORMAT(COALESCE(r.updated_at, r.created_at),'%Y')
  ) rr ON rr.yy = DATE_FORMAT(o.created_at,'%Y')
  WHERE o.status IN ('Diproses','Dikirim','Selesai')
  GROUP BY DATE_FORMAT(o.created_at,'%Y')
  ORDER BY yy DESC
");

// Ringkasan return (untuk KPI singkat)
$return_summary = [
  'pending' => 0,
  'approved' => 0,
  'rejected' => 0,
  'approved_amount' => 0,
];

if ($conn instanceof mysqli) {
  $q = mysqli_query($conn, "
    SELECT
      SUM(CASE WHEN status='pending' THEN 1 ELSE 0 END) AS pending,
      SUM(CASE WHEN status='approved' THEN 1 ELSE 0 END) AS approved,
      SUM(CASE WHEN status='rejected' THEN 1 ELSE 0 END) AS rejected
    FROM returns
  ");
  if ($q) {
    $row = mysqli_fetch_assoc($q);
    $return_summary['pending'] = (int)($row['pending'] ?? 0);
    $return_summary['approved'] = (int)($row['approved'] ?? 0);
    $return_summary['rejected'] = (int)($row['rejected'] ?? 0);
  }

  $q2 = mysqli_query($conn, "
    SELECT
      COALESCE(SUM(
        CASE
          WHEN r.product_id IS NOT NULL THEN COALESCE(oi.price * oi.quantity, 0)
          ELSE COALESCE(o.total_amount, 0)
        END
      ),0) AS approved_amount
    FROM returns r
    LEFT JOIN orders o ON o.id = r.order_id
    LEFT JOIN order_items oi ON oi.order_id = r.order_id AND (r.product_id IS NULL OR oi.product_id = r.product_id)
    WHERE r.status = 'approved'
  ");
  if ($q2) {
    $row2 = mysqli_fetch_assoc($q2);
    $return_summary['approved_amount'] = (float)($row2['approved_amount'] ?? 0);
  }
}
?>
    <div class="topbar">
      <div class="topbar-left">
        <h1>Laporan Penjualan</h1>
        <div class="breadcrumb">Admin / <span>Laporan</span></div>
      </div>
    </div>

    <!-- RINGKASAN RETURN -->
    <div class="card">
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px;">
        <div>
          <h2>Ringkasan Return</h2>
          <small>Return yang dihitung ke laporan keuangan hanya yang statusnya <b>approved</b>.</small>
        </div>
      </div>
      <div style="display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:12px;">
        <div class="kpi">
          <div class="kpi-label">Pending</div>
          <div class="kpi-value"><?php echo (int)$return_summary['pending']; ?></div>
        </div>
        <div class="kpi">
          <div class="kpi-label">Approved</div>
          <div class="kpi-value"><?php echo (int)$return_summary['approved']; ?></div>
        </div>
        <div class="kpi">
          <div class="kpi-label">Rejected</div>
          <div class="kpi-value"><?php echo (int)$return_summary['rejected']; ?></div>
        </div>
        <div class="kpi">
          <div class="kpi-label">Total Return Disetujui (Rp)</div>
          <div class="kpi-value">Rp <?php echo number_format($return_summary['approved_amount'], 0, ',', '.'); ?></div>
        </div>
      </div>
    </div>

    <!-- REKAP PER HARI -->
    <div class="card">
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px;">
        <div>
          <h2>Rekap Penjualan Harian</h2>
          <small>Data penjualan per tanggal dari tabel orders (status selesai, dikirim, diproses).</small>
        </div>
      </div>
      <div class="table-wrapper">
        <table>
          <thead>
            <tr>
              <th>Tanggal</th>
              <th>Jumlah Order</th>
              <th>Gross Sales (Rp)</th>
              <th>Return (Rp)</th>
              <th>Net Sales (Rp)</th>
            </tr>
          </thead>
          <tbody>
            <?php if ($r_daily && mysqli_num_rows($r_daily) > 0): ?>
              <?php while ($d = mysqli_fetch_assoc($r_daily)): ?>
                <tr>
                  <td>
                    <?php
                      // format jadi 02 Des 2025
                      $tgl = htmlspecialchars($d['tgl']);
                      echo date('d M Y', strtotime($tgl));
                    ?>
                  </td>
                  <td><?php echo (int)$d['total_order']; ?></td>
                  <td>Rp <?php echo number_format($d['gross_amount'], 0, ',', '.'); ?></td>
                  <td>
                    Rp <?php echo number_format($d['return_amount'], 0, ',', '.'); ?>
                    <?php if ((int)$d['return_count'] > 0): ?>
                      <span style="color:#64748b;">(<?php echo (int)$d['return_count']; ?>)</span>
                    <?php endif; ?>
                  </td>
                  <td>Rp <?php echo number_format(($d['gross_amount'] - $d['return_amount']), 0, ',', '.'); ?></td>
                </tr>
              <?php endwhile; ?>
            <?php else: ?>
              <tr><td colspan="5">Belum ada data penjualan harian.</td></tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>

    <!-- REKAP PER BULAN -->
    <div class="card">
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px;">
        <div>
          <h2>Rekap Penjualan Per Bulan</h2>
          <small>Data berdasarkan tabel orders (status selesai, dikirim, diproses).</small>
        </div>
      </div>
      <div class="table-wrapper">
        <table>
          <thead>
            <tr>
              <th>Bulan</th>
              <th>Jumlah Order</th>
              <th>Gross Sales (Rp)</th>
              <th>Return (Rp)</th>
              <th>Net Sales (Rp)</th>
            </tr>
          </thead>
          <tbody>
            <?php if($r_monthly && mysqli_num_rows($r_monthly)>0): ?>
              <?php while($m = mysqli_fetch_assoc($r_monthly)): ?>
                <tr>
                  <td><?php echo htmlspecialchars($m['ym']); ?></td>
                  <td><?php echo (int)$m['total_order']; ?></td>
                  <td>Rp <?php echo number_format($m['gross_amount'],0,',','.'); ?></td>
                  <td>
                    Rp <?php echo number_format($m['return_amount'],0,',','.'); ?>
                    <?php if ((int)$m['return_count'] > 0): ?>
                      <span style="color:#64748b;">(<?php echo (int)$m['return_count']; ?>)</span>
                    <?php endif; ?>
                  </td>
                  <td>Rp <?php echo number_format(($m['gross_amount'] - $m['return_amount']),0,',','.'); ?></td>
                </tr>
              <?php endwhile; ?>
            <?php else: ?>
              <tr><td colspan="5">Belum ada data penjualan.</td></tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>

    <!-- REKAP PER TAHUN -->
    <div class="card">
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px;">
        <div>
          <h2>Rekap Penjualan Per Tahun</h2>
          <small>Akumulasi penjualan per tahun dari tabel orders (status selesai, dikirim, diproses).</small>
        </div>
      </div>
      <div class="table-wrapper">
        <table>
          <thead>
            <tr>
              <th>Tahun</th>
              <th>Jumlah Order</th>
              <th>Gross Sales (Rp)</th>
              <th>Return (Rp)</th>
              <th>Net Sales (Rp)</th>
            </tr>
          </thead>
          <tbody>
            <?php if($r_yearly && mysqli_num_rows($r_yearly)>0): ?>
              <?php while($y = mysqli_fetch_assoc($r_yearly)): ?>
                <tr>
                  <td><?php echo htmlspecialchars($y['yy']); ?></td>
                  <td><?php echo (int)$y['total_order']; ?></td>
                  <td>Rp <?php echo number_format($y['gross_amount'],0,',','.'); ?></td>
                  <td>
                    Rp <?php echo number_format($y['return_amount'],0,',','.'); ?>
                    <?php if ((int)$y['return_count'] > 0): ?>
                      <span style="color:#64748b;">(<?php echo (int)$y['return_count']; ?>)</span>
                    <?php endif; ?>
                  </td>
                  <td>Rp <?php echo number_format(($y['gross_amount'] - $y['return_amount']),0,',','.'); ?></td>
                </tr>
              <?php endwhile; ?>
            <?php else: ?>
              <tr><td colspan="5">Belum ada data penjualan tahunan.</td></tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>

    <div class="footer-admin">
      <span>© 2025 AFK FOOTWEAR Admin.</span>
      <span>Frontend terhubung ke <a href="../index.php">website pengguna</a></span>
    </div>
  </main>
</div>
</body>
</html>
