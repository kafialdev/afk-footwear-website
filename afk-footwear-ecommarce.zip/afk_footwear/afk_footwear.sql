
CREATE DATABASE IF NOT EXISTS afk_footwear CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE afk_footwear;

-- ====== USERS ======
DROP TABLE IF EXISTS users;
CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(150) NOT NULL UNIQUE,
  username VARCHAR(50) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  role ENUM('admin','customer') NOT NULL DEFAULT 'customer',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);


-- ====== PASSWORD RESETS ======
DROP TABLE IF EXISTS password_resets;
CREATE TABLE password_resets (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  token VARCHAR(64) NOT NULL UNIQUE,
  expires_at DATETIME NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_password_resets_user FOREIGN KEY (user_id)
    REFERENCES users(id) ON DELETE CASCADE
);

-- ====== PRODUCTS ======
DROP TABLE IF EXISTS products;
CREATE TABLE products (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(150) NOT NULL,
  price INT NOT NULL,
  image_url VARCHAR(255) DEFAULT NULL,
  category ENUM('Mens','Womens','Kids','Discount') NOT NULL,
  brand VARCHAR(50) NOT NULL,
  description TEXT,
  stock INT NOT NULL DEFAULT 0,
  is_coming_soon TINYINT(1) NOT NULL DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ====== ORDERS (ORDER HEADER) ======
DROP TABLE IF EXISTS orders;
CREATE TABLE orders (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  total_amount INT NOT NULL,
  payment_method ENUM('Transfer','COD','E-Wallet') NOT NULL,
  status ENUM('Baru','Diproses','Dikirim','Selesai','Dibatalkan') NOT NULL DEFAULT 'Baru',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ====== ORDER ITEMS (DETAIL) ======
DROP TABLE IF EXISTS order_items;
CREATE TABLE order_items (
  id INT AUTO_INCREMENT PRIMARY KEY,
  order_id INT NOT NULL,
  product_id INT NOT NULL,
  size_label VARCHAR(10) DEFAULT NULL,
  quantity INT NOT NULL,
  price INT NOT NULL,
  subtotal INT NOT NULL,
  FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
  FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
);

-- ADMIN DEFAULT
INSERT INTO users (name,email,username,password_hash,role)
VALUES ('Admin AFK','admin@afkfootwear.com','admin',
        '$2y$10$9Wm6iXIt0W1LkTIabW.CMO7G4ZcX3YQInZfQ9hFSGQBBd3qsVqFea','admin');
-- password: admin123

-- BEBERAPA CUSTOMER DUMMY
INSERT INTO users (name,email,username,password_hash,role) VALUES
('Zina','zina@example.com','zina','$2y$10$123456789012345678901uZ2qNaHashExample1','customer'),
('Customer Demo','demo@example.com','demo','$2y$10$123456789012345678901uZ2qNaHashExample2','customer');

-- PRODUK DUMMY
INSERT INTO products (name,price,image_url,category,brand,description,stock) VALUES
('Nike Air Max 270',1250000,'Foto product/NIKE MAN/Nike Air Max 90 LTR.jpg','Mens','Nike','Running shoes dengan Air unit empuk.',10),
('Adidas Ultraboost',1800000,'Foto product/ADIDAS MAN/Adizero Adior 9.png','Mens','Adidas','Sepatu lari ringan dan responsif.',8),
('Puma RS-X',1050000,'Foto product/PUMA MAN/Velocity NITRO™ 4 Running Shoes Men.jpg','Mens','Puma','Sneaker chunky retro.',6),
('Kids Adidas Superstar',750000,'Foto product/ADIDAS KIDS/adidas_anak_dino_advantage_2.0-.png','Kids','Adidas','Sepatu klasik untuk anak.',12),
('Nike Cortez SE',950000,'Foto product/NIKE MAN/Nike Cortez SE.jpg','Discount','Nike','Sneaker klasik dengan harga spesial.',5);

-- ORDER DUMMY (untuk grafik dan tabel penghasilan per bulan)
INSERT INTO orders (user_id,total_amount,payment_method,status,created_at) VALUES
(2,2000000,'Transfer','Selesai','2025-07-05 10:10:00'),
(3,1250000,'COD','Diproses','2025-08-10 12:00:00'),
(2,1800000,'E-Wallet','Selesai','2025-09-15 09:30:00'),
(3,2500000,'Transfer','Selesai','2025-10-20 14:45:00'),
(2,1500000,'E-Wallet','Dikirim','2025-11-02 16:20:00');

INSERT INTO order_items (order_id,product_id,quantity,price,subtotal) VALUES
(1,1,1,1250000,1250000),
(1,4,1,750000,750000),
(2,1,1,1250000,1250000),
(3,2,1,1800000,1800000),
(4,3,2,1050000,2100000),
(5,5,1,950000,950000);


-- ====== PAYMENT PROOFS (BUKTI TRANSFER) ======
DROP TABLE IF EXISTS payment_proofs;
CREATE TABLE payment_proofs (
  id INT AUTO_INCREMENT PRIMARY KEY,
  order_code VARCHAR(50) NOT NULL,
  customer_name VARCHAR(100) NOT NULL,
  customer_email VARCHAR(150) DEFAULT NULL,
  customer_phone VARCHAR(50) DEFAULT NULL,
  payment_method VARCHAR(50) DEFAULT NULL,
  proof_path VARCHAR(255) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);



-- ====== PRODUCT SIZES (stok per ukuran) ======
DROP TABLE IF EXISTS product_sizes;
CREATE TABLE product_sizes (
  id INT AUTO_INCREMENT PRIMARY KEY,
  product_id INT NOT NULL,
  size_label VARCHAR(10) NOT NULL,
  stock INT NOT NULL DEFAULT 0,
  FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
);


-- ====== RETURNS (AJUKAN RETURN) ======
DROP TABLE IF EXISTS returns;
CREATE TABLE returns (
  id INT AUTO_INCREMENT PRIMARY KEY,
  order_id INT NOT NULL,
  user_id INT NOT NULL,
  product_id INT DEFAULT NULL,
  item_code VARCHAR(50) DEFAULT NULL,
  reason VARCHAR(120) NOT NULL,
  note TEXT DEFAULT NULL,
  photo VARCHAR(255) DEFAULT NULL,
  return_address VARCHAR(255) DEFAULT NULL,
  status ENUM('pending','approved','rejected') NOT NULL DEFAULT 'pending',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NULL DEFAULT NULL,
  UNIQUE KEY uniq_return_order (order_id),
  FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE SET NULL
);
