<?php
// Sign Up AFK FOOTWEAR
require_once __DIR__ . '/db.php';
session_start();

$err = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $full_name = trim($_POST['full_name'] ?? '');
    $username  = trim($_POST['username'] ?? '');
    $email     = trim($_POST['email'] ?? '');
    $password  = $_POST['password'] ?? '';
    $confirm   = $_POST['confirm_password'] ?? '';

    if ($full_name === '') {
        $err = 'Nama lengkap wajib diisi.';
    } elseif ($username === '' || strpos($username, '@') === false) {
        $err = 'Username harus mengandung @.';
    } elseif ($email === '' || !str_ends_with($email, '@gmail.com')) {
        $err = 'Email harus menggunakan domain @gmail.com.';
    } elseif (!preg_match('/^(?=.*[a-z])(?=.*[A-Z])(?=.*[\d\W]).{8,}$/', $password)) {
        $err = 'Password tidak memenuhi kriteria.';
    } elseif ($password !== $confirm) {
        $err = 'Konfirmasi password tidak sama.';
    } else {
        // cek apakah email sudah dipakai
        $stmt = $conn->prepare("SELECT id FROM users WHERE email = ? LIMIT 1");
        $stmt->bind_param('s', $email);
        $stmt->execute();
        $stmt->store_result();
        if ($stmt->num_rows > 0) {
            $err = 'Email sudah terdaftar. Silakan gunakan email lain atau Sign In.';
        } else {
            $stmt->close();
            $hash = password_hash($password, PASSWORD_BCRYPT);
            $stmt = $conn->prepare("INSERT INTO users (name, username, email, password_hash, created_at) VALUES (?, ?, ?, ?, NOW())");
            $stmt->bind_param('ssss', $full_name, $username, $email, $hash);
            if ($stmt->execute()) {
                header('Location: signin.php');
                exit;
            } else {
                $err = 'Gagal mendaftar. Coba lagi nanti.';
            }
        }
        $stmt->close();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Sign Up - A.F.K FOOTWEAR</title>
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <link href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet"/>

  <style>
    *, *::before, *::after { box-sizing: border-box; }
    html, body { height: 100%; }
    body{
      background-image:url(https://i.pinimg.com/1200x/34/0b/64/340b64f7ed20b916eb5e12260e42899c.jpg);
      background-size:cover;
      background-position:center;
      background-repeat:no-repeat;
      min-height:100vh;
      display:flex;
      justify-content:center;
      align-items:center;
      font-family:system-ui,-apple-system,Segoe UI,Roboto,"Helvetica Neue",Arial,"Noto Sans","Liberation Sans",sans-serif;
      margin:0;
      padding:12px;
    }
    .login-container{ width:400px; max-width:92vw; }
    .login-form{
      width:100%;
      max-width:420px;
      padding:2rem;
      background:#fff;
      border-radius:16px;
      box-shadow:0 10px 30px rgba(0,0,0,.15);
      position:relative;
      overflow:hidden;
    }
    .icon-top{
      text-align:center;
      margin-bottom:1.1rem;
    }
    .icon-top i{
      font-size:28px;
      color:#9d2b2b;
      margin-bottom:6px;
      display:inline-block;
    }
    .icon-top h2{
      margin:0;
      letter-spacing:.5px;
    }
    .input-group{
      position:relative;
      margin-bottom:1.4rem;
      width:100%;
    }
    .input-group input{
      display:block;
      width:100%;
      max-width:100%;
      height:46px;
      line-height:46px;
      padding:0 42px 0 12px;
      border-radius:10px;
      border:1px solid #ccc;
      outline:none;
      background:#fff;
      transition:box-shadow .2s, border-color .2s;
    }
    .input-group input:focus{
      border-color:#000;
      box-shadow:0 0 0 4px rgba(0,0,0,.08);
    }
    .input-group .icon-right{
      position:absolute;
      right:12px;
      top:50%;
      transform:translateY(-50%);
      color:#777;
      font-size:18px;
      pointer-events:none;
    }
    .toggle-password{
      position:absolute;
      right:8px;
      top:50%;
      transform:translateY(-50%);
      width:32px;
      height:32px;
      border:none;
      background:transparent;
      padding:0;
      cursor:pointer;
      display:flex;
      align-items:center;
      justify-content:center;
    }
    .toggle-password i{
      font-size:18px;
      color:#777;
    }

    .login-btn{
      width:100%;
      padding:12px;
      background:#4CAF50;
      color:#fff;
      border:none;
      border-radius:10px;
      cursor:pointer;
      font-size:16px;
      margin-top:.5rem;
      font-weight:600;
      letter-spacing:0.5px;
    }

    .other-links{
      display:flex;
      justify-content:flex-end;
      align-items:center;
      gap:10px;
      font-size:13px;
      margin-top:10px;
    }
    .signup-text{
      margin:0;
      font-size:13px;
      color:#555;
    }
    .signup-text a{
      color:#007bff;
      text-decoration:none;
      font-weight:500;
    }

    .validation-info{
      font-size:12px;
      text-align:left;
      color:#555;
      margin:.5rem 0 0.2rem;
    }
    .validation-info h4{
      margin:0 0 .5rem;
    }
    .validation-info ul{
      margin:0;
      padding-left:18px;
    }

    .top-nav{
      position:fixed;
      top:12px;
      left:12px;
      z-index:10;
    }
    .home-icon{
      display:inline-flex;
      width:42px;
      height:42px;
      align-items:center;
      justify-content:center;
      border-radius:12px;
      background:rgba(0,0,0,.35);
      backdrop-filter:blur(4px);
    }
    .home-icon i{
      font-size:22px;
      color:#fff;
    }
  </style>
</head>
<body>

  <!-- Tombol kembali ke Home -->
  <div class="top-nav">
    <a href="index.php" class="home-icon" title="Back to Home" aria-label="Back to Home">
      <i class='bx bx-home'></i>
    </a>
  </div>

  <?php if($err): ?>
    <script>alert("<?= htmlspecialchars($err, ENT_QUOTES) ?>");</script>
  <?php endif; ?>

  <div class="login-container">
    <form class="login-form" method="POST">
      <div class="icon-top">
        <i class="fas fa-user-plus"></i>
        <h2>SIGN UP</h2>
      </div>

      <div class="input-group">
        <input type="text" id="full_name" name="full_name" placeholder="Nama Lengkap" required>
        <i class="fas fa-id-card icon-right"></i>
      </div>

      <div class="input-group">
        <input type="text" id="username" name="username" placeholder="Username (@something)" required>
        <i class="fas fa-user icon-right"></i>
      </div>

      <div class="input-group">
        <input type="email" id="email" name="email" placeholder="Email (@gmail.com)" required>
        <i class="fas fa-envelope icon-right"></i>
      </div>

      <div class="input-group">
        <input type="password" id="password" name="password" placeholder="Password" required>
        <button type="button" class="toggle-password" data-target="password">
          <i class="fa-solid fa-eye"></i>
        </button>
      </div>

      <div class="input-group">
        <input type="password" id="confirm_password" name="confirm_password" placeholder="Konfirmasi Password" required>
        <button type="button" class="toggle-password" data-target="confirm_password">
          <i class="fa-solid fa-eye"></i>
        </button>
      </div>

      <div class="validation-info">
        <h4>Requirements:</h4>
        <ul>
          <li>Username harus mengandung simbol "@".</li>
          <li>Email harus menggunakan domain @gmail.com.</li>
          <li>Password minimal 8 karakter, mengandung huruf besar, kecil, dan angka/simbol.</li>
        </ul>
      </div>

      <button type="submit" class="login-btn">SIGN UP</button>

      <div class="other-links">
        <p class="signup-text">Sudah punya akun? <a href="signin.php">Sign In</a></p>
      </div>

    </form>
  </div>

  <script>
    document.addEventListener('DOMContentLoaded', () => {
      const toggleIcons = document.querySelectorAll('.toggle-password');
      toggleIcons.forEach(btn => {
        btn.addEventListener('click', () => {
          const targetId = btn.getAttribute('data-target');
          const input = document.getElementById(targetId);
          const icon  = btn.querySelector('i');
          if (!input || !icon) return;

          if (input.type === 'password') {
            input.type = 'text';
            icon.classList.remove('fa-eye');
            icon.classList.add('fa-eye-slash');
          } else {
            input.type = 'password';
            icon.classList.remove('fa-eye-slash');
            icon.classList.add('fa-eye');
          }
        });
      });
    });
  </script>

</body>
</html>
