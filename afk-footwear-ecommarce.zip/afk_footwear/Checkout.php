<?php
// TAMPILKAN ERROR (untuk debug)
ini_set('display_errors', 1);
error_reporting(E_ALL);

require_once __DIR__ . '/db.php';
session_start();
$trackingCount = getTrackingCount($conn);

$currentUserId    = (int)($_SESSION['user_id'] ?? 0);
$currentUserName  = $_SESSION['user_name'] ?? '';
$currentUserEmail = $_SESSION['user_email'] ?? '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Checkout - A.F.K FOOTWEAR</title>

  <!-- Font & Icon -->
  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" />
  <link href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet" />

  <style>
    :root {
      --color-dark: #111827;
      --color-dark-muted: #374151;
      --color-accent: #b91c1c;
      --color-accent-hover: #9d2b2b;
      --color-light: #f9fafb;
      --color-gray: #e5e7eb;
      --color-text-dark: #000000;
      --color-text-light: #f9fafb;
      --footer-bg: #020033;
      --white-color: #ffffff;
      --primary-color: #9d2b2b;
      --font-primary: "Poppins", sans-serif;
    }

    *{margin:0;padding:0;box-sizing:border-box;}
    html{scroll-behavior:smooth;}
    body{
      background-color:#ffffff;
      color:var(--color-text-dark);
      font-family:var(--font-primary);
      line-height:1.6;
    }
    .container{max-width:1280px;margin:0 auto;padding:0 2rem;}
    a{text-decoration:none;color:inherit;}
    img{max-width:100%;display:block;}
    ul{list-style:none;}

    /* HEADER */
    header.header{
      background-color:#020033;
      color:#ffffff;
      padding:15px 0;
      position:sticky;
      top:0;
      z-index:999;
      box-shadow:0 2px 10px rgba(0,0,0,0.15);
      width:100%;
    }
    .main-nav-simple{
      display:flex;
      align-items:center;
      justify-content:space-between;
      max-width:1400px;
      margin:0 auto;
      padding:0 2rem;
    }
    .main-nav-simple img{height:45px;}
    .center-nav{flex:1;display:flex;justify-content:center;}
    .center-nav .nav-links{display:flex;gap:3rem;}
    .center-nav .nav-links a{
      color:#ffffff;
      font-weight:600;
      font-size:1.05rem;
      transition:color 0.3s ease;
    }
    .center-nav .nav-links a:hover{color:var(--color-accent);}
    .right-nav{display:flex;align-items:center;gap:2rem;}
    .right-nav-links{display:flex;align-items:center;gap:2rem;}
    .right-nav-links a{
      color:#ffffff;
      font-weight:600;
      font-size:1.05rem;
      transition:color 0.3s ease;
    }
    .right-nav-links a:hover{color:var(--color-accent);}
    .icon-link{
      color:#ffffff;
      font-size:1.6rem;
      display:inline-flex;
      align-items:center;
      justify-content:center;
      transition:transform 0.2s ease,color 0.2s ease;
    }
    .icon-link:hover{transform:scale(1.1);color:var(--color-accent);}
    .cart-icon,.track-icon{position:relative;}
    .cart-item-count{
      position:absolute;
      top:-8px;right:-10px;
      background:#d00000;color:#fff;
      padding:2px 7px;
      border-radius:50%;
      font-size:.75rem;
      font-weight:bold;
      display:none;
    }
    .track-count-badge{
      position:absolute;
      top:-8px;right:-10px;
      background:#d00000;color:#fff;
      padding:2px 7px;
      border-radius:50%;
      font-size:.75rem;
      font-weight:bold;
    }

    /* LAYOUT CHECKOUT */
    .site-main{padding:4rem 0;}
    .cart-layout{
      display:grid;
      grid-template-columns:2fr 1fr;
      gap:3rem;
      align-items:flex-start;
    }
    .order-summary-panel{
      background-color:var(--color-light);
      padding:2rem;
      border-radius:12px;
      border:1px solid var(--color-gray);
      position:sticky;
      top:120px;
    }
    .order-summary-panel h2{
      font-size:1.5rem;
      font-weight:700;
      margin-bottom:1.5rem;
    }
    .summary-row{
      display:flex;
      justify-content:space-between;
      margin-bottom:1rem;
    }
    .summary-row.total{
      font-size:1.2rem;
      font-weight:700;
      margin-top:1.5rem;
      color:var(--color-accent);
    }
    .summary-divider{
      height:1px;
      background-color:var(--color-gray);
      margin:1.5rem 0;
    }
    .payment-methods{
      margin-top:1.8rem;
      text-align:center;
      padding-top:1rem;
      border-top:1px solid var(--color-gray);
    }
    .payment-methods .icons{
      display:flex;
      justify-content:center;
      gap:1.5rem;
      font-size:2rem;
      color:var(--color-dark-muted);
    }
    .payment-methods i{transition:transform 0.2s ease-in-out;}
    .payment-methods i:hover{transform:scale(1.2);}
    .btn{
      display:inline-block;
      padding:.8rem 1.5rem;
      border:none;
      border-radius:8px;
      font-weight:600;
      font-size:1rem;
      cursor:pointer;
      text-align:center;
      transition:all 0.3s ease;
    }
    .btn-primary{
      background-color:var(--color-accent);
      color:#fff;
      width:100%;
    }
    .btn-primary:hover{
      background-color:var(--color-accent-hover);
      transform:translateY(-2px);
      box-shadow:0 4px 10px rgba(0,0,0,0.1);
    }

    .checkout-details-panel{
      background-color:#fff;
      padding:2.5rem;
      border-radius:12px;
      border:1px solid var(--color-gray);
    }
    .checkout-section{margin-bottom:2.5rem;}
    .checkout-section h2{
      font-size:1.3rem;
      font-weight:600;
      border-bottom:1px solid var(--color-gray);
      padding-bottom:10px;
      margin-bottom:1.5rem;
    }
    .checkout-section h2 i{margin-right:10px;color:var(--color-accent);}
    .form-group{margin-bottom:1rem;}
    .form-group label{
      display:block;
      font-weight:500;
      margin-bottom:.5rem;
      font-size:.9rem;
      color:var(--color-dark-muted);
    }
    .form-group input[type="text"],
    .form-group input[type="tel"]{
      width:100%;
      padding:.75rem 1rem;
      border:1px solid var(--color-gray);
      border-radius:8px;
      font-size:1rem;
      font-family:var(--font-primary);
      transition:border-color .2s, box-shadow .2s;
    }
    .form-group input:focus{
      border-color:var(--color-dark);
      outline:none;
      box-shadow:0 0 0 3px rgba(17,24,39,.1);
    }
    .form-row{display:flex;gap:1rem;}
    .form-row .form-group{flex:1;}

    .cart-header{
      display:flex;
      align-items:center;
      gap:.75rem;
      border-bottom:1px solid #eee;
      padding-bottom:1rem;
      margin-bottom:1.5rem;
    }
    .cart-header h1{margin:0;font-size:1.8rem;}
    .back-to-cart-btn{
      font-size:2rem;
      color:#333;
      text-decoration:none;
      padding:5px;
      border-radius:50%;
      display:inline-flex;
      align-items:center;
      justify-content:center;
      transition:background-color .2s ease;
    }
    .back-to-cart-btn:hover{background-color:#f5f5f5;}

    /* TAB METODE PEMBAYARAN */
    .payment-tabs{display:flex;gap:10px;margin-bottom:1rem;}
    .tab-btn{
      flex:1;
      padding:10px 14px;
      border:1px solid var(--color-gray);
      background:#fff;
      border-radius:8px;
      cursor:pointer;
      font-size:0.95rem;
      display:flex;
      align-items:center;
      justify-content:center;
      gap:8px;
      color:var(--color-dark-muted);
      font-weight:500;
      transition:all .2s;
    }
    .tab-btn i{
      font-size:1.2rem;
    }
    .tab-btn:hover{border-color:var(--color-accent);}
    .tab-btn.active{
      background:var(--color-accent);
      color:#fff;
      font-weight:600;
      border-color:var(--color-accent);
    }
    .payment-panel{
      display:none;
      padding:16px 14px;
      background-color:#fafafa;
      border:1px solid #eee;
      border-radius:8px;
      animation:fadeIn .3s;
    }
    .payment-panel p{
      margin-bottom:10px;
      font-size:.9rem;
    }
    .payment-panel.active{display:block;}
    .va-details{
      padding:.8rem 1rem;
      margin-bottom:.5rem;
      display:flex;
      justify-content:space-between;
      align-items:center;
      background:#fff;
      border-radius:8px;
      border:1px solid #eee;
    }
    .va-details span{
      font-weight:600;
      font-family:monospace;
      font-size:1.05rem;
      color:var(--color-dark);
    }

    /* Tombol download QRIS */
    .qris-download-btn{
      width:auto;
      margin:12px auto 4px;
      display:inline-flex;
      align-items:center;
      justify-content:center;
      gap:8px;
      padding:.7rem 1.4rem;
      font-size:.9rem;
    }
    .qris-download-btn i{
      font-size:1rem;
    }

    .checkout-item-list{
      max-height:300px;
      overflow-y:auto;
      padding-right:10px;
      margin-bottom:1.5rem;
    }
    .summary-item-checkout{
      display:flex;
      gap:1rem;
      align-items:center;
      padding-bottom:1rem;
      margin-bottom:1rem;
      border-bottom:1px solid var(--color-gray);
    }
    .summary-item-checkout:last-child{border-bottom:none;margin-bottom:0;}
    .summary-item-checkout img{
      width:60px;height:60px;
      object-fit:contain;
      border-radius:4px;
      background-color:var(--color-light);
    }
    .summary-item-checkout-details{flex:1;}
    .summary-item-checkout-details .name{
      font-weight:600;
      font-size:.95rem;
      display:block;
      margin-bottom:2px;
    }
    .summary-item-checkout-details .info{
      font-size:.85rem;
      color:#6b7280;
    }
    .summary-item-checkout-price{
      font-weight:600;
      font-size:.95rem;
    }

    .empty-cart-view{
      text-align:center;
      padding:5rem 1rem;
    }
    .empty-cart-view .empty-icon{
      font-size:6rem;
      color:#22c55e;
      margin-bottom:1.5rem;
    }
    .empty-cart-view h2{
      font-size:2rem;
      font-weight:700;
      margin-bottom:1rem;
    }
    .empty-cart-view p{
      max-width:450px;
      margin:0 auto 2rem;
      color:#6b7280;
    }
    .empty-cart-actions{
      display:flex;
      flex-direction:column;
      align-items:center;
      gap:0.75rem;
    }
    .empty-cart-actions a{
      display:inline-flex;
      align-items:center;
      justify-content:center;
      gap:8px;
      min-width:190px;
    }
    .empty-cart-view .btn-primary{
      width:auto;
      background-color:var(--color-accent);
    }
    .btn-track-thankyou i{
      font-size:1.3rem;
    }
    .btn-home-thankyou{
      background:#111827;
      color:#fff;
    }
    .btn-home-thankyou:hover{
      background:#020033;
      transform:translateY(-2px);
      box-shadow:0 4px 10px rgba(0,0,0,0.1);
    }

    /* MODAL UPLOAD */
    .modal{
      display:none;
      position:fixed;
      z-index:9999;
      inset:0;
      width:100%;
      height:100%;
      background-color:rgba(0,0,0,0.55);
      justify-content:center;
      align-items:flex-start;
      padding:16px;
      box-sizing:border-box;
      overflow-y:auto;
      animation:fadeIn .3s ease-in-out;
    }
    .modal-content{
      background:#fff;
      border-radius:12px;
      padding:20px 24px;
      width:100%;
      max-width:430px;
      margin:auto;
      box-shadow:0 4px 20px rgba(0,0,0,0.25);
      position:relative;
      text-align:center;
      animation:slideUp .3s ease-out;
    }
    .close{
      position:absolute;
      top:12px;right:18px;
      font-size:28px;
      color:#777;
      cursor:pointer;
      transition:color .2s;
    }
.close:hover{color:#d32f2f;}
    .modal-title{
      font-size:1.4rem;
      font-weight:700;
      color:#d32f2f;
      margin-bottom:8px;
    }
    .modal-desc{
      font-size:.95rem;
      color:#555;
      margin-bottom:15px;
    }
    .modal-order-info{
      background:#fafafa;
      border:1px solid #eee;
      border-radius:8px;
      padding:10px 15px;
      margin-bottom:15px;
      text-align:left;
    }
    .modal-order-info p{margin:4px 0;font-size:.9rem;}
    .upload-section{margin-top:10px;}
    .upload-label{
      display:inline-block;
      background:#d32f2f;
      color:#fff;
      padding:12px 18px;
      border-radius:8px;
      cursor:pointer;
      font-weight:600;
      font-size:.95rem;
      transition:background .3s ease;
      margin-top:10px;
    }
    .upload-label:hover{background:#b71c1c;}
    .upload-label i{margin-right:6px;}
    .proof-preview{
      margin-top:12px;
      display:flex;
      justify-content:center;
    }
    .proof-preview img{
      width:100%;
      max-width:260px;
      max-height:260px;
      border-radius:8px;
      border:2px solid #eee;
      box-shadow:0 2px 5px rgba(0,0,0,0.1);
      object-fit:contain;
    }
    .upload-btn{
      background:#d32f2f;
      color:#fff;
      border:none;
      padding:10px 18px;
      border-radius:8px;
      margin-top:20px;
      cursor:pointer;
      font-weight:600;
      font-family:"Poppins",sans-serif;
      transition:background .3s ease,transform .2s;
    }
    .upload-btn:hover{
      background:#b71c1c;
      transform:translateY(-1px);
    }

    @media (max-width: 600px){
    .modal{
      padding:12px;
    }
    .modal-content{
      padding:16px 18px;
      max-width:360px;
    }
    .upload-label{
      width:100%;
      font-size:0.9rem;
      padding:10px;
    }
    .payment-info{
      font-size:0.9rem;
    }
    .proof-preview img{
      max-width:100%;
      max-height:220px;
    }
  }

.toast{
      position:fixed;
      bottom:25px;right:25px;
      background:#4caf50;
      color:#fff;
      padding:14px 20px;
      border-radius:8px;
      font-size:.95rem;
      display:none;
      animation:fadeInUp .4s ease;
    }

    @keyframes fadeIn{from{opacity:0;}to{opacity:1;}}
    @keyframes slideUp{from{transform:translateY(40px);opacity:0;}to{transform:translateY(0);opacity:1;}}
    @keyframes fadeInUp{from{opacity:0;transform:translateY(20px);}to{opacity:1;transform:translateY(0);}}

    @media(max-width:992px){
      .cart-layout{grid-template-columns:1fr;}
      .order-summary-panel{position:static;margin-top:2rem;}
    }
    @media(max-width:768px){
      .main-nav-simple{flex-wrap:wrap;gap:1rem;}
      .center-nav .nav-links{gap:1.5rem;}
      .checkout-details-panel{padding:1.5rem;}
      .form-row{flex-direction:column;gap:0;}
    }
  </style>
</head>
<body>
  <!-- HEADER -->
  <header class="header">
    <div class="container">
      <div class="main-nav-simple">
        <a href="index.php">
          <img src="IMG/LOGO.jpg" alt="A.F.K FOOTWEAR Logo" />
        </a>

        <nav class="center-nav">
          <ul class="nav-links">
            <li><a href="Mens.php">Mens</a></li>
            <li><a href="Womens.php">Womens</a></li>
            <li><a href="Kids.php">Kids</a></li>
            <li><a href="Discount.php">Discounts</a></li>
          </ul>
        </nav>

        <div class="right-nav">
          <ul class="right-nav-links">
            <li><a href="index.php">Home</a></li>
            <li><a href="About.php">About</a></li>
            <li><a href="Help.php">Help</a></li>
          </ul>

          <a href="Tracking.php" class="icon-link track-icon" title="Track Order">
            <i class="bx bxs-truck"></i>
            <?php if (!empty($trackingCount)): ?>
              <span class="track-count-badge"><?php echo $trackingCount; ?></span>
            <?php endif; ?>
          </a>

          <a href="Cart.php" class="icon-link cart-icon" title="Cart">
            <i class="bx bx-cart"></i>
            <span id="header-cart-count" class="cart-item-count">0</span>
          </a>
        </div>
      </div>
    </div>
  </header>

  <!-- MAIN -->
  <main class="site-main">
    <div class="container">
      <!-- VIEW CHECKOUT -->
      <div class="checkout-view" id="checkout-view">
        <div class="cart-header">
          <a href="Cart.php" class="back-to-cart-btn" title="Back to Cart">
            <i class="bx bx-arrow-back"></i>
          </a>
          <h1 id="cart-title">Shipping & Payment</h1>
        </div>

        <div class="cart-layout">
          <!-- PANEL KIRI: FORM -->
          <section class="checkout-details-panel">
            <form id="checkout-form">
              <section class="checkout-section">
                <h2><i class="fas fa-shipping-fast"></i> Shipping Address</h2>
                <div class="form-group">
                  <label for="full-name">Full Name</label>
                  <input type="text" id="full-name" name="full-name" placeholder="Arfan Maulana" required />
                </div>
                <div class="form-group">
                  <label for="address">Address</label>
                  <input type="text" id="address" name="address" placeholder="Ketintang Surabaya" required />
                </div>
                <div class="form-row">
                  <div class="form-group">
                    <label for="city">City</label>
                    <input type="text" id="city" name="city" placeholder="Surabaya" required />
                  </div>
                  <div class="form-group">
                    <label for="postalCode">ZIP / Postal Code</label>
                    <input type="text" id="postalCode" name="postalCode" placeholder="320089" required />
                  </div>
                </div>
                <div class="form-group">
                  <label for="phone">Phone Number</label>
                  <input type="tel" id="phone" name="phone" placeholder="+62 812 3456 7890" required />
                </div>
              </section>

              <section class="checkout-section">
                <h2><i class="fas fa-credit-card"></i> Payment Method</h2>
                <p>Choose your payment method below.</p>

                <div class="payment-tabs">
                  <button type="button" class="tab-btn active" data-tab="bank-transfer">
                    <i class="fas fa-university"></i>
                    <span>Bank Transfer</span>
                  </button>
                  <button type="button" class="tab-btn" data-tab="qris">
                    <i class="fas fa-qrcode"></i>
                    <span>QRIS</span>
                  </button>
                </div>

                <div class="payment-panels">
                  <!-- Bank Transfer -->
                  <div id="bank-transfer" class="payment-panel active">
                    <p><strong>Metode: Transfer Bank</strong><br>
                       Silakan transfer ke salah satu rekening berikut:</p>
                    <div class="va-details">
                      <strong>BCA</strong>
                      <span>1234 5678 9012</span>
                    </div>
                    <div class="va-details">
                      <strong>Mandiri</strong>
                      <span>8888 9012 3456</span>
                    </div>
                  </div>

                  <!-- QRIS -->
                  <div id="qris" class="payment-panel">
                    <p><strong>Metode: QRIS</strong><br>
                       Scan atau <strong>download QRIS</strong> di bawah ini untuk menyelesaikan pembayaran:</p>
                    <img src="IMG/Qrcode.jpg" alt="QRIS Code" style="width: 200px; margin: 10px auto; display: block" />
                    <!-- Tombol download QRIS -->
                    <a href="IMG/Qrcode.jpg" download="AFK_QRIS.jpg" class="btn btn-primary qris-download-btn">
                      <i class="fas fa-download"></i>
                      <span>Download QRIS</span>
                    </a>
                  </div>
                </div>
              </section>
            </form>
          </section>

          <!-- PANEL KANAN: ORDER SUMMARY -->
          <aside class="order-summary-panel">
            <h2>Order Summary</h2>

            <div class="checkout-item-list" id="summary-item-list">
              <p>Loading your cart...</p>
            </div>

            <div class="summary-divider"></div>

            <div class="summary-row">
              <span>Subtotal</span>
              <span id="summary-subtotal">Rp 0</span>
            </div>
            <div class="summary-row">
              <span>Shipping</span>
              <span id="summary-shipping">Rp 25.000</span>
            </div>

            <div class="summary-divider"></div>

            <div class="summary-row total">
              <span>Total</span>
              <span id="summary-total">Rp 25.000</span>
            </div>

            <button type="button" class="btn btn-primary checkout-btn" id="pay-now-button">
              Pay Now
            </button>

            <div class="payment-methods">
              <div class="icons">
                <i class="fas fa-university"></i>
                <i class="fas fa-qrcode"></i>
              </div>
            </div>
          </aside>
        </div>
      </div>

      <!-- VIEW THANK YOU -->
      <div class="empty-cart-view" id="thank-you-view" style="display: none">
        <i class="fas fa-check-circle empty-icon"></i>
        <h2>Payment Successful!</h2>
        <p>
          Thank you for your purchase. Your order ID is
          <strong id="order-id">#000000</strong>.
        </p>
        <div class="empty-cart-actions">
          <a href="Tracking.php" class="btn btn-primary btn-track-thankyou">
            <i class="bx bxs-truck"></i>
            <span>View Order Tracking</span>
          </a>
          <a href="index.php" class="btn btn-home-thankyou">
            <i class="bx bx-home-alt"></i>
            <span>Back to Home</span>
          </a>
        </div>
      </div>
    </div>
  </main>

  <!-- MODAL UPLOAD BUKTI PEMBAYARAN -->
  <div id="uploadModal" class="modal">
    <div class="modal-content">
      <span class="close" onclick="closeModal()">&times;</span>
      <h2 class="modal-title">Upload Bukti Pembayaran</h2>
      <p class="modal-desc">Silakan upload bukti transfer Anda untuk pesanan berikut:</p>
      <div class="modal-order-info">
        <p><strong>Pesanan:</strong> <span id="modal-order-name">-</span></p>
        <p><strong>Total:</strong> <span id="modal-order-total">Rp 0</span></p>
      </div>
      <div class="upload-section">
        <label for="payment-proof-modal" class="upload-label">
          <i class="fas fa-upload"></i> Pilih File Bukti Pembayaran
        </label>
        <input
          type="file"
          id="payment-proof-modal"
          accept="image/*"
          onchange="previewProof()"
          hidden
        />
        <div id="proof-preview" class="proof-preview"></div>
      </div>
      <button class="upload-btn" onclick="submitProof()">
        <i class="fas fa-paper-plane"></i> Kirim Bukti Pembayaran
      </button>
    </div>
  </div>

  <div class="toast" id="toast"></div>

  <script>
    const CURRENT_USER_ID    = <?php echo $currentUserId; ?>;
    const CURRENT_USER_NAME  = <?php echo json_encode($currentUserName); ?>;
    const CURRENT_USER_EMAIL = <?php echo json_encode($currentUserEmail); ?>;

    function formatRupiah(angka) {
      return new Intl.NumberFormat("id-ID", {
        style: "currency",
        currency: "IDR",
        minimumFractionDigits: 0
      }).format(angka);
    }
    function parseRupiah(str){
      if(!str) return 0;
      return Number(String(str).replace(/[^0-9]/g,""));
    }
    function getCart(){
      try{
        const raw = localStorage.getItem("cartItems");
        if(!raw) return [];
        const data = JSON.parse(raw);
        return Array.isArray(data)?data:[];
      }catch(e){return[];}
    }
    function saveCart(items){
      localStorage.setItem("cartItems",JSON.stringify(items));
    }
    function updateCartIcon(){
      const cart = getCart();
      const totalItems = cart.reduce((s,it)=>s+(it.quantity||0),0);
      const el = document.getElementById("header-cart-count");
      if(!el)return;
      if(totalItems>0){
        el.textContent = totalItems;
        el.style.display = "block";
      }else{
        el.style.display = "none";
      }
    }
    function showToast(message){
      const toast = document.getElementById("toast");
      if(!toast)return;
      toast.textContent = message;
      toast.style.display="block";
      toast.style.opacity="1";
      setTimeout(()=>{
        toast.style.opacity="0";
        setTimeout(()=>{toast.style.display="none";},400);
      },2500);
    }

    document.addEventListener("DOMContentLoaded", function(){
      const summaryList       = document.getElementById("summary-item-list");
      const summarySubtotalEl = document.getElementById("summary-subtotal");
      const summaryShippingEl = document.getElementById("summary-shipping");
      const summaryTotalEl    = document.getElementById("summary-total");
      const payNowButton      = document.getElementById("pay-now-button");
      const headerCartCount   = document.getElementById("header-cart-count");
      const checkoutForm      = document.getElementById("checkout-form");
      const checkoutView      = document.getElementById("checkout-view");
      const thankYouView      = document.getElementById("thank-you-view");
      const modal             = document.getElementById("uploadModal");

      updateCartIcon();

      const tabButtons    = document.querySelectorAll(".tab-btn");
      const paymentPanels = document.querySelectorAll(".payment-panel");
      tabButtons.forEach(btn=>{
        btn.addEventListener("click",()=>{
          const targetId = btn.getAttribute("data-tab");
          const panel = document.getElementById(targetId);
          tabButtons.forEach(b=>b.classList.remove("active"));
          paymentPanels.forEach(p=>p.classList.remove("active"));
          btn.classList.add("active");
          if(panel) panel.classList.add("active");
        });
      });

      function loadCheckoutSummary(){
        const cartItems = getCart();
        summaryList.innerHTML="";
        let subtotal=0;
        let totalItems=0;
        if(!cartItems.length){
          summaryList.innerHTML="<p>Your cart is empty.</p>";
          if(payNowButton){
            payNowButton.disabled=true;
            payNowButton.textContent="Cart is Empty";
          }
        }else{
          cartItems.forEach(item=>{
            const itemPrice    = item.priceRaw || parseRupiah(item.price);
            const itemSubtotal = itemPrice * item.quantity;
            subtotal+=itemSubtotal;
            totalItems+=item.quantity;
            const div=document.createElement("div");
            div.className="summary-item-checkout";
            div.innerHTML=`
              <img src="${item.image}" alt="${item.name}">
              <div class="summary-item-checkout-details">
                <span class="name">${item.name}</span>
                <span class="info">Size: ${item.size}, Qty: ${item.quantity}</span>
              </div>
              <span class="summary-item-checkout-price">${formatRupiah(itemSubtotal)}</span>
            `;
            summaryList.appendChild(div);
          });
        }
        const shippingCost = parseRupiah(summaryShippingEl.textContent);
        const total        = subtotal+shippingCost;

        summarySubtotalEl.textContent    = formatRupiah(subtotal);
        summaryTotalEl.textContent       = formatRupiah(total);
        summarySubtotalEl.dataset.subRaw = subtotal;
        summaryShippingEl.dataset.shipRaw= shippingCost;
        summaryTotalEl.dataset.totalRaw  = total;

        if(cartItems.length && payNowButton){
          payNowButton.disabled=false;
          payNowButton.textContent=`Pay Now - ${formatRupiah(total)}`;
        }
        if(headerCartCount){
          headerCartCount.textContent=totalItems;
          headerCartCount.style.display=totalItems>0?"block":"none";
        }
      }
      loadCheckoutSummary();

      if(checkoutForm){
        checkoutForm.addEventListener("submit",e=>e.preventDefault());
      }

      if(payNowButton){
        payNowButton.addEventListener("click",function(e){
          e.preventDefault();
          const cartItems = getCart();
          if(!cartItems.length){
            alert("Your cart is empty. Please add items first.");
            return;
          }
          if(modal) modal.style.display="flex";
          const modalOrderName  = document.getElementById("modal-order-name");
          const modalOrderTotal = document.getElementById("modal-order-total");
          const totalRaw = Number(summaryTotalEl.dataset.totalRaw||0);
          if(modalOrderName){
            if(cartItems.length===1){
              modalOrderName.textContent=cartItems[0].name;
            }else{
              modalOrderName.textContent = `${cartItems[0].name} & ${cartItems.length-1} more item(s)`;
            }
          }
          if(modalOrderTotal){
            modalOrderTotal.textContent = formatRupiah(totalRaw);
          }
        });
      }

      window.addEventListener("click",e=>{
        if(modal && e.target===modal){ closeModal(); }
      });

      window.closeModal=function(){
        if(modal) modal.style.display="none";
      };

      window.previewProof=function(){
        const fileInput=document.getElementById("payment-proof-modal");
        const preview=document.getElementById("proof-preview");
        if(!fileInput || !preview)return;
        preview.innerHTML="";
        if(fileInput.files && fileInput.files[0]){
          const reader=new FileReader();
          reader.onload=function(ev){
            const img=document.createElement("img");
            img.src=ev.target.result;
            preview.appendChild(img);
          };
          reader.readAsDataURL(fileInput.files[0]);
        }
      };

      window.submitProof = async function(){
        const fileInput=document.getElementById("payment-proof-modal");
        if(!fileInput || !fileInput.files.length){
          alert("Silakan upload bukti pembayaran terlebih dahulu!");
          return;
        }
        const cartItems=getCart();
        if(!cartItems.length){
          alert("Cart sudah kosong.");
          closeModal();
          return;
        }
        const nameEl=document.getElementById("full-name");
        const addrEl=document.getElementById("address");
        const cityEl=document.getElementById("city");
        const postEl=document.getElementById("postalCode");
        const phoneEl=document.getElementById("phone");

        const customerData={
          name:       nameEl?nameEl.value:"",
          address:    addrEl?addrEl.value:"",
          city:       cityEl?cityEl.value:"",
          postalCode: postEl?postEl.value:"",
          phone:      phoneEl?phoneEl.value:""
        };

        const subtotal = Number(summarySubtotalEl.dataset.subRaw||0);
        const shipping = Number(summaryShippingEl.dataset.shipRaw||0);
        const total    = Number(summaryTotalEl.dataset.totalRaw||0);

        let paymentMethod="Transfer Bank";
        const activeTabBtn=document.querySelector(".tab-btn.active");
        if(activeTabBtn){
          const tabId = activeTabBtn.getAttribute("data-tab")||"";
          if(tabId==="qris") paymentMethod="QRIS";
          else if(tabId==="bank-transfer") paymentMethod="Transfer Bank";
          else paymentMethod=tabId||"Lainnya";
        }

        if(!CURRENT_USER_ID){
          alert("Silakan Sign In terlebih dahulu sebelum menyelesaikan checkout.");
          return;
        }

        let orderSaved=false;
        let dbOrderId=0;
        let orderCode="";
        try{
          const payload={
            user_id:CURRENT_USER_ID,
            items:cartItems,
            customer:customerData,
            subtotal:subtotal,
            shipping:shipping,
            total:total,
            paymentMethod:paymentMethod
          };
          const resp = await fetch("place_order.php",{
            method:"POST",
            headers:{"Content-Type":"application/json"},
            body:JSON.stringify(payload)
          });
          const data = await resp.json();
          if(data && data.success){
            orderSaved=true;
            dbOrderId=parseInt(data.order_id||0,10)||0;
            if(data.order_code){
              orderCode=data.order_code;
            }else if(dbOrderId){
              orderCode="AFK"+String(dbOrderId).padStart(4,"0");
            }else{
              orderCode="AFK"+Date.now().toString().slice(-6);
            }
          }else{
            alert("Gagal menyimpan order ke server: "+(data&&data.message?data.message:""));
            return;
          }
        }catch(err){
          console.error(err);
          alert("Terjadi error saat menyimpan order ke server.");
          return;
        }
        if(!orderSaved) return;

        try{
          const formData=new FormData();
          formData.append("proof",fileInput.files[0]);
          formData.append("order_code",orderCode);
          if(dbOrderId) formData.append("order_id",dbOrderId);
          formData.append("customer_name",customerData.name);
          formData.append("customer_email",CURRENT_USER_EMAIL||"");
          formData.append("customer_phone",customerData.phone);
          formData.append("payment_method",paymentMethod);

          fetch("save_proof.php",{method:"POST",body:formData})
            .then(r=>r.json())
            .then(r=>{
              if(!r.success){
                console.warn("Gagal simpan bukti transfer:",r.message);
                alert("Bukti transfer gagal disimpan ke server: "+(r.message||""));
              }
            })
            .catch(e=>{
              console.error("Error upload bukti:",e);
              alert("Terjadi error saat mengirim bukti transfer.");
            });
        }catch(e){
          console.error("Exception upload bukti:",e);
        }

        const orderObj={
          id:orderCode,
          db_id:dbOrderId,
          items:cartItems,
          subtotal:subtotal,
          shipping:shipping,
          total:total,
          customer:customerData,
          status:"Baru",
          createdAt:new Date().toISOString(),
          paymentMethod:paymentMethod
        };
        localStorage.setItem("lastOrder",JSON.stringify(orderObj));

        saveCart([]);
        updateCartIcon();
        closeModal();
        showToast("✅ Bukti pembayaran berhasil dikirim!");

        setTimeout(()=>{
          if(checkoutView && thankYouView){
            checkoutView.style.display="none";
            thankYouView.style.display="block";
            const orderIdEl=document.getElementById("order-id");
            if(orderIdEl) orderIdEl.textContent="#"+orderCode;
            window.scrollTo(0,0);
          }
        },1500);
      };
    });
  </script>
</body>
</html>
