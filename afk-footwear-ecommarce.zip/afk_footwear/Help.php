<?php
require_once __DIR__ . '/db.php';
session_start();
$trackingCount = getTrackingCount($conn);
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Help - A.F.K FOOTWEAR</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <!-- Fonts & Icons -->
  <link rel="stylesheet" href="css/style.css">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
  <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>

  <!-- HEADER STYLE (SAMA DENGAN CART) -->
  <style>
    header.header {
      background-color: #020033;
      color: white;
      padding: 15px 0;
      position: sticky;
      top: 0;
      z-index: 999;
      width: 100%;
      box-shadow: 0 2px 10px rgba(0,0,0,0.2);
    }

    .main-nav-simple {
      max-width: 1400px;
      margin: auto;
      padding: 0 2rem;
      display: flex;
      align-items: center;
      justify-content: space-between;
    }

    /* LOGO */
    .main-nav-simple img {
      height: 45px;
    }

    /* Hilangkan bullet */
    .nav-links, .nav-links li,
    .right-nav-links, .right-nav-links li {
      list-style: none;
      margin: 0; padding: 0;
    }

    /* Menu tengah */
    .center-nav {
      flex: 1;
      display: flex;
      justify-content: center;
    }
    .center-nav .nav-links {
      display: flex;
      gap: 3rem;
    }
    .center-nav .nav-links a {
      color: white;
      font-weight: 600;
      transition: .3s;
      text-decoration: none;
    }
    .center-nav .nav-links a:hover {
      color: #B91C1C;
    }

    /* Menu kanan */
    .right-nav {
      display: flex;
      align-items: center;
      gap: 2rem;
    }
    .right-nav-links {
      display: flex;
      gap: 2rem;
    }
    .right-nav-links a {
      color: white;
      font-weight: 600;
      text-decoration: none;
    }
    .right-nav-links a.active-link {
      color: #B91C1C;
    }

    /* Icons */
    .icon-link {
      font-size: 1.7rem;
      color: white;
      transition: .2s;
      text-decoration: none;
    }
    .icon-link:hover {
      transform: scale(1.1);
      color: #B91C1C;
    }

    /* Badge cart */
    .cart-icon {
      position: relative;
    }
    .cart-item-count {
      position: absolute;
      top: -8px; right: -10px;
      background: red;
      color: white;
      border-radius: 50%;
      padding: 3px 7px;
      font-size: 0.7rem;
      font-weight: bold;
      display: none;
    }

    /* RESPONSIVE */
    @media (max-width: 768px) {
      .main-nav-simple {
        flex-wrap: wrap;
        gap: 1rem;
      }
      .center-nav .nav-links {
        gap: 1rem;
      }
    }
  
    /* === MOBILE ORDER FIX (logo + Home/About/Help+icons on top, categories on row 2) === */
    .main-nav-simple { gap: 1rem; flex-wrap: nowrap; }
    .logo-wrap { display:flex; align-items:center; }

    @media (max-width: 768px) {
      .main-nav-simple { flex-wrap: wrap; }
      .logo-wrap { order: 1; }
      .right-nav { order: 2; }
      .center-nav { order: 3; width: 100%; flex: 0 0 100%; justify-content: center; }
      .center-nav .nav-links { justify-content: center; gap: 1rem; flex-wrap: wrap; }
    }

  </style>

</head>
<body>

<!-- ========================= HEADER (SAMA SEPERTI CART) ========================= -->
<!-- ========================= HEADER (SAMA SEPERTI TRACKING/HELP) ========================= -->
<header class="header">
  <div class="container">
    <div class="main-nav-simple">

      <!-- LOGO -->
      <a href="index.php" class="logo-wrap">
        <img src="IMG/LOGO.jpg" alt="A.F.K FOOTWEAR Logo">
      </a>

      <!-- MENU KANAN (Home/About/Help + icons) -->
      <div class="right-nav">
        <ul class="right-nav-links">
          <li><a href="index.php">Home</a></li>
          <li><a href="About.php">About</a></li>
          <li><a href="Help.php" class="active-link">Help</a></li>
        </ul>

        <!-- TRACKING -->
        <a href="Tracking.php" class="icon-link track-icon">
          <i class="bx bxs-truck"></i>
          <?php if (!empty($trackingCount)): ?>
            <span class="track-count-badge"><?php echo (int)$trackingCount; ?></span>
          <?php endif; ?>
        </a>

        <!-- CART -->
        <a href="Cart.php" class="icon-link cart-icon">
          <i class='bx bx-cart'></i>
          <span id="header-cart-count" class="cart-item-count">0</span>
        </a>
      </div>

      <!-- MENU BAWAH (Mens/Womens/Kids/Discounts) -->
      <nav class="center-nav">
        <ul class="nav-links">
          <li><a href="Mens.php">Mens</a></li>
          <li><a href="Womens.php">Womens</a></li>
          <li><a href="Kids.php">Kids</a></li>
          <li><a href="Discount.php">Discounts</a></li>
        </ul>
      </nav>

    </div>
  </div>
</header>

<!-- ========================= HERO HELP ========================= -->
<section class="hero-help-AFK">
  <div class="container">
    <h1>Help & Support</h1>
    <p>Kami siap membantu masalah & pertanyaan Anda.</p>
  </div>
</section>

<!-- (ISI HALAMAN HELP TETAP, TIDAK DIUBAH) -->
<section class="help-section-AFK">
  <div class="container">
    <h2 style="text-align:center;margin-bottom:2rem;">Help Center</h2>

    <div class="help-grid-AFK">

      <!-- Get Help -->
      <div class="help-card-AFK" onclick="toggleCard(this)">
        <h3><i class="fas fa-headset"></i> Get Help</h3>
        <p>Butuh bantuan cepat? Hubungi tim support kami.</p>
        <button class="toggle">Lihat Detail <i class="fas fa-chevron-down"></i></button>
        <div class="more-info">
          <p>Tim support tersedia 24/7. Email: support@afkfootwear.com</p>
        </div>
      </div>

      <!-- Order Status -->
      <div class="help-card-AFK" onclick="toggleCard(this)">
        <h3><i class="fas fa-truck"></i> Order Status</h3>
        <p>Lacak status pesanan secara real-time.</p>
        <button class="toggle">Lihat Detail <i class="fas fa-chevron-down"></i></button>
        <div class="more-info">
          <p>Cek status pesanan Anda dengan nomor order.</p>
        </div>
      </div>

      <!-- Returns -->
      <div class="help-card-AFK" onclick="toggleCard(this)">
        <h3><i class="fas fa-undo"></i> Returns</h3>
        <p>Proses pengembalian mudah & cepat.</p>
        <button class="toggle">Lihat Detail <i class="fas fa-chevron-down"></i></button>
        <div class="more-info">
          <p>Pengembalian tersedia dalam 30 hari.</p>
        </div>
      </div>

      <!-- Delivery -->
      <div class="help-card-AFK" onclick="toggleCard(this)">
        <h3><i class="fas fa-shipping-fast"></i> Delivery</h3>
        <p>Informasi lengkap pengiriman.</p>
        <button class="toggle">Lihat Detail <i class="fas fa-chevron-down"></i></button>
        <div class="more-info">
          <p>Pengiriman 1–5 hari ke seluruh Indonesia.</p>
        </div>
      </div>

      <!-- Payment Options (FIX: TANPA E-WALLET) -->
      <div class="help-card-AFK" onclick="toggleCard(this)">
        <h3><i class="fas fa-credit-card"></i> Payment Options</h3>
        <p>Pilih metode pembayaran yang aman.</p>
        <button class="toggle">Lihat Detail <i class="fas fa-chevron-down"></i></button>
        <div class="more-info">
          <p>Metode pembayaran yang tersedia saat ini: Transfer Bank dan QRIS.</p>
        </div>
      </div>

    </div>
  </div>
</section>

<!-- FOOTER (TETAP) -->
<footer class="footer">
  <div class="footer-container container">

    <div class="footer-about">
      <h3 class="footer-title">About Us</h3>
      <p>Selamat Datang di A.F.K FOOTWEAR Store.<br> 
          Berawal dari kecintaan pada dunia fashion dan olahraga, A.F.K FOOTWEAR hadir untuk memberikan pengalaman belanja sepatu yang berbeda. 
          Kami ingin menghadirkan koleksi sepatu terbaik dari brand terkenal di dunia seperti Nike, Adidas, Puma, langsung ke genggamanmu.</p>
    </div>

    <div class="footer-links">
      <h3 class="footer-title">Products</h3>
      <ul>
        <li><a href="Mens.php">Mens</a></li>
        <li><a href="Womens.php">Womens</a></li>
        <li><a href="Kids.php">Kids</a></li>
        <li><a href="#">New Collections</a></li>
      </ul>
    </div>

    <div class="footer-links">
      <h3 class="footer-title">Help</h3>
      <ul>
        <li><a href="Help.php">Get Help</a></li>
        <li><a href="Help.php">Order Status</a></li>
        <li><a href="Help.php">Delivery</a></li>
        <li><a href="Help.php">Returns</a></li>
        <li><a href="Help.php">Payment Options</a></li>
      </ul>
    </div>

    <div class="footer-contact">
        <h3 class="footer-title">Contact Us</h3>
        <ul>
          <p><i class='bx bxs-map'></i> JL. Lidah Wetan, Surabaya</p>
          <p><i class='bx bxs-phone'></i> 0812-3456-7890</p>
          <p><i class='bx bxs-envelope'></i> AFKFootwear@gmail.com</p>
          <p><i class='bx bxs-time'></i> Setiap Hari: 08.00 - 22.00</p>
          <p><i class='bx bxs-web'></i> www.AFKFOOTWEAR.com</p>
        </ul>

        <div class="footer-socials">
          <a href="#"><i class='bx bxl-instagram'></i></a>
          <a href="#"><i class='bx bxl-facebook-square'></i></a>
          <a href="#"><i class='bx bxl-twitter'></i></a>
          <a href="#"><i class='bx bxl-whatsapp'></i></a>
          <a href="#"><i class='bx bxl-youtube'></i></a>
        </div>
      </div>
    </div>
  <div class="footer-bottom">
    <p>&copy; 2025 A.F.K FOOTWEAR. All rights reserved</p>
  </div>
</footer>

<!-- JS -->
<script>
  function toggleCard(card) {
    card.classList.toggle("active");
  }

  /* Cart Badge Update */
  document.addEventListener("DOMContentLoaded", () => {
    const cart = JSON.parse(localStorage.getItem("cartItems")) || [];
    const total = cart.reduce((a, c) => a + c.quantity, 0);
    const badge = document.getElementById("header-cart-count");
    if (total > 0) {
      badge.textContent = total;
      badge.style.display = "block";
    }
  });
</script>

</body>
</html>
