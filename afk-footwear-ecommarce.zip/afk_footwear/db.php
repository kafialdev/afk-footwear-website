<?php
// db.php - koneksi database AFK Footwear
$DB_HOST = 'localhost';
$DB_USER = 'root';
$DB_PASS = '';
$DB_NAME = 'afk_footwear';

$conn = mysqli_connect($DB_HOST, $DB_USER, $DB_PASS, $DB_NAME);

if (!$conn) {
    die('Koneksi database gagal: ' . mysqli_connect_error());
}

function esc($conn, $str) {
    return mysqli_real_escape_string($conn, $str ?? '');
}


if (!function_exists('getTrackingCount')) {
    function getTrackingCount($conn) {
        if (empty($_SESSION['user_id'])) {
            return 0;
        }

        $userId = (int)$_SESSION['user_id'];

        $sql = "SELECT COUNT(*) AS c 
                FROM orders 
                WHERE user_id = ? 
                AND status IN ('Baru','Diproses','Dikirim')";
        if (!($stmt = mysqli_prepare($conn, $sql))) {
            return 0;
        }
        mysqli_stmt_bind_param($stmt, 'i', $userId);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_bind_result($stmt, $c);
        mysqli_stmt_fetch($stmt);
        mysqli_stmt_close($stmt);

        return (int)$c;
    }
}

?>
