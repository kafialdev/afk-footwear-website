<?php
require_once __DIR__ . '/db.php';
session_start();

// wajib login
if (empty($_SESSION['user_id'])) {
  header('Location: signin.php');
  exit;
}

$userId = (int)$_SESSION['user_id'];

// ambil semua pesanan yang sudah selesai / dibatalkan (riwayat)
$orders = [];
$stmt = $conn->prepare("SELECT * FROM orders WHERE user_id = ? AND status IN ('Selesai','Dibatalkan') ORDER BY created_at DESC");
$stmt->bind_param('i', $userId);
$stmt->execute();
$res = $stmt->get_result();
while ($row = $res->fetch_assoc()) {
  $orders[] = $row;
}
$stmt->close();
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Riwayat Pembelian - A.F.K FOOTWEAR</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <link rel="stylesheet" href="css/style.css" />
  <link href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet">

  <style>
    body{
      background:#f3f4f6;
      font-family:'Poppins',system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;
    }

    /* ========== HEADER SAMA DENGAN TRACKING ========== */
    header.header {
      background-color: #020033;
      color: #ffffff;
      padding: 15px 0;
      position: sticky;
      top: 0;
      z-index: 999;
      box-shadow: 0 2px 10px rgba(0, 0, 0, 0.15);
      width: 100%;
    }

    .main-nav-simple {
      display: flex;
      align-items: center;
      justify-content: space-between;
      max-width: 1400px;
      margin: 0 auto;
      padding: 0 2rem;
    }

    .main-nav-simple img {
      height: 45px;
      display:block;
    }

    .center-nav {
      flex: 1;
      display: flex;
      justify-content: center;
    }

    .center-nav .nav-links {
      display: flex;
      gap: 3rem;
      list-style:none;
    }

    .center-nav .nav-links a {
      color: #ffffff;
      font-weight: 600;
      font-size: 1.05rem;
      padding:6px 4px;
      text-decoration:none;
      transition: color 0.3s ease;
    }

    .center-nav .nav-links a:hover,
    .center-nav .nav-links a.active-link {
      color: var(--primary-color);
    }

    .right-nav {
      display: flex;
      align-items: center;
      gap: 2rem;
    }

    .right-nav-links {
      display: flex;
      align-items: center;
      gap: 2rem;
      list-style:none;
    }

    .right-nav-links a {
      color: #ffffff;
      font-weight: 600;
      font-size: 1.05rem;
      text-decoration:none;
      transition: color 0.3s ease;
    }

    .right-nav-links a:hover {
      color: var(--primary-color);
    }

    .icon-link {
      color: #ffffff;
      font-size: 1.6rem;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      position:relative;
      text-decoration:none;
      transition: transform 0.2s ease, color 0.2s ease;
    }

    .icon-link:hover {
      transform: scale(1.1);
      color: var(--primary-color);
    }

    .cart-item-count {
      position: absolute;
      top: -8px;
      right: -10px;
      background: #d00000;
      color: white;
      padding: 2px 7px;
      border-radius: 50%;
      font-size: 0.75rem;
      font-weight: bold;
      display: none;
    }

    /* ========== CONTENT RIWAYAT ========== */
    main{
      max-width:1100px;
      margin:20px auto 32px;
      padding:0 16px 32px;
    }
    .page-header{
      display:flex;
      justify-content:space-between;
      align-items:center;
      margin-bottom:16px;
    }
    .page-header h1{
      font-size:1.5rem;
      color:#111827;
    }
    .page-header p{
      font-size:.9rem;
      color:#6b7280;
    }
    .page-header a.back-link{
      font-size:.9rem;
      color:#0b66c3;
      text-decoration:none;
      display:inline-flex;
      align-items:center;
      gap:6px;
      font-weight:600;
    }
    .page-header a.back-link:hover{
      text-decoration:underline;
    }

    .history-card{
      background:#ffffff;
      border-radius:16px;
      padding:14px 16px;
      box-shadow:0 10px 30px rgba(15,23,42,0.12);
      margin-bottom:12px;
      border:1px solid #e5e7eb;
    }
    .history-top{
      display:flex;
      justify-content:space-between;
      align-items:center;
      margin-bottom:6px;
    }
    .order-code{
      font-weight:600;
      color:#111827;
      font-size:.95rem;
    }
    .order-date{
      font-size:.8rem;
      color:#6b7280;
    }
    .history-middle{
      display:flex;
      justify-content:space-between;
      align-items:center;
      margin:4px 0 8px;
      font-size:.9rem;
    }
    .history-middle span.label{
      color:#6b7280;
    }
    .history-middle span.value{
      font-weight:600;
      color:#111827;
    }
    .status-pill{
      padding:3px 10px;
      border-radius:999px;
      font-size:.75rem;
      display:inline-flex;
      align-items:center;
      gap:4px;
      border:1px solid #e5e7eb;
    }
    .status-done{
      background:#ecfdf5;
      color:#15803d;
      border-color:#bbf7d0;
    }
    .status-cancel{
      background:#fef2f2;
      color:#b91c1c;
      border-color:#fecaca;
    }
    .empty-state{
      background:#ffffff;
      border-radius:16px;
      padding:18px 16px;
      box-shadow:0 10px 30px rgba(15,23,42,0.12);
      border:1px solid #e5e7eb;
      font-size:.9rem;
      color:#4b5563;
    }

    /* ========== RESPONSIVE HEADER ========== */
    @media (max-width:768px){
      header.header{
        padding: 8px 0;
      }

      .main-nav-simple{
        flex-wrap: wrap;
        gap: 8px;
        height: auto;
        /* padding kiri-kanan agar tulisan tidak mepet frame */
        padding: 0 14px;
      }

      .main-nav-simple img{
        height: 38px;
      }

      /* menu kanan dan logo tetap di baris atas */
      .right-nav{
        gap: 14px;
      }

      .right-nav-links a{
        font-size: .9rem;
      }

      /* menu kategori di tengah pindah ke baris bawah, full width */
      .center-nav{
        order: 3;
        width: 100%;
        justify-content: center;
      }

      .center-nav .nav-links{
        justify-content: center;
        flex-wrap: wrap;
        gap: 16px;
      }

      .center-nav .nav-links a{
        font-size: .9rem;
      }
    }
  </style>
</head>
<body>

<!-- HEADER SAMA DENGAN TRACKING -->
<header class="header">
  <div class="main-nav-simple">
    <!-- Logo kiri -->
    <a href="index.php">
      <img src="IMG/LOGO.jpg" alt="AFK Footwear Logo">
    </a>

    <!-- Menu tengah -->
    <nav class="center-nav">
      <ul class="nav-links">
        <li><a href="Mens.php">Mens</a></li>
        <li><a href="Womens.php">Womens</a></li>
        <li><a href="Kids.php">Kids</a></li>
        <li><a href="Discount.php">Discounts</a></li>
      </ul>
    </nav>

    <!-- Kanan: Home / About / Help + ikon truck + cart -->
    <div class="right-nav">
      <ul class="right-nav-links">
        <li><a href="index.php">Home</a></li>
        <li><a href="About.php">About</a></li>
        <li><a href="Help.php">Help</a></li>
      </ul>

      <!-- Tracking icon -->
      <a href="Tracking.php" class="icon-link track-icon" title="Track Order">
        <i class='bx bxs-truck'></i>
      </a>

      <!-- Cart icon -->
      <a href="Cart.php" class="icon-link cart-icon" title="Cart">
        <i class='bx bx-cart'></i>
        <span id="header-cart-count" class="cart-item-count">0</span>
      </a>
    </div>
  </div>
</header>

<main>
  <div class="page-header">
    <div>
      <h1>Riwayat Pembelian</h1>
      <p>Daftar semua pesanan yang sudah selesai atau dibatalkan.</p>
    </div>
    <a href="Tracking.php" class="back-link"><i class="bx bx-left-arrow-alt"></i> Kembali ke Tracking</a>
  </div>

  <?php if (empty($orders)): ?>
    <div class="empty-state">
      Belum ada pesanan yang masuk ke riwayat. Setelah kamu mengkonfirmasi bahwa barang sudah diterima, pesanan akan muncul di sini.
    </div>
  <?php else: ?>
    <?php foreach ($orders as $order): ?>
      <?php
        $date   = date('d M Y, H:i', strtotime($order['created_at']));
        $total  = (int)$order['total_amount'];
        $status = $order['status'];
        $code   = sprintf('#AFK%04d', $order['id']);
        $isDone = ($status === 'Selesai');

        // Normalisasi metode pembayaran: sama seperti di Tracking
        $rawMethod = strtolower(trim($order['payment_method'] ?? ''));
        if ($rawMethod === 'e-wallet' || strpos($rawMethod, 'wallet') !== false) {
          $methodLabel = 'QRIS';
        } else {
          $methodLabel = 'Transfer Bank';
        }
      ?>
      <div class="history-card">
        <div class="history-top">
          <span class="order-code"><?php echo htmlspecialchars($code); ?></span>
          <span class="order-date"><?php echo htmlspecialchars($date); ?></span>
        </div>
        <div class="history-middle">
          <span class="label">Total</span>
          <span class="value">Rp <?php echo number_format($total, 0, ',', '.'); ?></span>
        </div>
        <div class="history-middle">
          <span class="label">Metode Pembayaran</span>
          <span class="value"><?php echo htmlspecialchars($methodLabel); ?></span>
        </div>
        <div class="history-middle">
          <span class="label">Status</span>
          <span>
            <span class="status-pill <?php echo $isDone ? 'status-done' : 'status-cancel'; ?>">
              <i class="bx <?php echo $isDone ? 'bx-check-circle' : 'bx-x-circle'; ?>"></i>
              <?php echo htmlspecialchars($status); ?>
            </span>
          </span>
        </div>

        <!-- Aksi: Return (hanya jika pesanan selesai) -->
        <?php if ($isDone): ?>
          <div style="margin-top:10px; display:flex; gap:10px; flex-wrap:wrap;">
            <a href="ReturnRequest.php?order_id=<?php echo (int)$order['id']; ?>"
               style="display:inline-flex; align-items:center; gap:8px; padding:9px 12px; border-radius:12px; background:#111827; color:#fff; text-decoration:none; font-weight:700; font-size:.9rem;">
              <i class='bx bx-undo' style="font-size:1.1rem;"></i>
              Ajukan Return
            </a>
            <a href="ReturnMy.php"
               style="display:inline-flex; align-items:center; gap:8px; padding:9px 12px; border-radius:12px; background:#ffffff; color:#111827; border:1px solid #e5e7eb; text-decoration:none; font-weight:700; font-size:.9rem;">
              <i class='bx bx-time-five' style="font-size:1.1rem;"></i>
              Status Return
            </a>
          </div>
        <?php endif; ?>
      </div>
    <?php endforeach; ?>
  <?php endif; ?>
</main>

<script>
  function getCart(){
    try {
      const raw = localStorage.getItem('cartItems');
      if (!raw) return [];
      const data = JSON.parse(raw);
      return Array.isArray(data) ? data : [];
    } catch(e) {
      return [];
    }
  }

  function updateCartIcon(){
    const cart = getCart();
    const totalItems = cart.reduce((s,it)=> s + (it.quantity || 0), 0);
    var el = document.getElementById('header-cart-count');
    if (!el) return;
    if (totalItems > 0) {
      el.textContent = totalItems;
      el.style.display = 'block';
    } else {
      el.style.display = 'none';
    }
  }

  document.addEventListener('DOMContentLoaded', updateCartIcon);
</script>
</body>
</html>
