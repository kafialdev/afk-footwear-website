<?php
require_once __DIR__ . '/db.php';
session_start();
$trackingCount = getTrackingCount($conn);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>About - A.F.K FOOTWEAR</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <!-- CSS utama -->
  <link rel="stylesheet" href="css/style.css">
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <link rel="shortcut icon" href="./foto/.jpg" type="image/x-icon" />
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
  <link href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet" />

  <!-- PATCH HEADER: samakan dengan Cart (tanpa search & sign in) -->
  <style>
    :root {
      --color-dark: #111827;
      --color-dark-muted: #374151;
      --color-accent: #B91C1C;
      --color-accent-hover: #9d2b2b;
      --color-text-light: #F9FAFB;
    }

    header.header {
      background-color: #020033;
      color: #ffffff;
      padding: 15px 0;
      position: sticky;
      top: 0;
      z-index: 999;
      box-shadow: 0 2px 10px rgba(0,0,0,0.15);
      width: 100%;
    }

    .main-nav-simple {
      display: flex;
      align-items: center;
      justify-content: space-between;
      max-width: 1400px;
      margin: 0 auto;
      padding: 0 2rem;
    }

    .main-nav-simple img {
      height: 45px;
      display: block;
    }

    /* Hilangkan bullet di semua menu */
    .nav-links,
    .nav-links li,
    .right-nav-links,
    .right-nav-links li {
      list-style: none;
      margin: 0;
      padding: 0;
    }

    /* MENU TENGAH (Mens / Womens / Kids / Discounts) */
    .center-nav {
      flex: 1;
      display: flex;
      justify-content: center;
    }

    .center-nav .nav-links {
      display: flex;
      gap: 3rem;
    }

    .center-nav .nav-links a {
      color: #ffffff;
      font-weight: 600;
      font-size: 1.05rem;
      transition: .3s ease;
    }

    .center-nav .nav-links a:hover {
      color: var(--color-accent);
    }

    /* MENU KANAN (Home / About / Help + ikon) */
    .right-nav {
      display: flex;
      align-items: center;
      gap: 1.5rem;
    }

    .right-nav-links {
      display: flex;
      align-items: center;
      gap: 2rem;
    }

    .right-nav-links a {
      color: #ffffff;
      font-weight: 600;
      font-size: 1.05rem;
      transition: .3s ease;
    }

    .right-nav-links a:hover {
      color: var(--color-accent);
    }

    .right-nav-links a.active-link {
      color: var(--color-accent);
    }

    .icon-link {
      color: #ffffff;
      font-size: 1.6rem;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      transition: transform .2s ease, color .2s ease;
    }

    .icon-link:hover {
      transform: scale(1.1);
      color: var(--color-accent);
    }

    .cart-icon, .track-icon {
      position: relative;
    }

    .cart-item-count {
      position: absolute;
      top: -8px;
      right: -10px;
      background: #d00000;
      color: white;
      padding: 2px 7px;
      border-radius: 50%;
      font-size: 0.75rem;
      font-weight: bold;
      display: none;
    }

    /* Responsive sedikit */
    @media (max-width: 768px) {
      .main-nav-simple {
        flex-wrap: wrap;
        gap: 0.75rem;
      }
      .center-nav .nav-links {
        gap: 1.5rem;
        flex-wrap: wrap;
      }
      .right-nav-links {
        gap: 1rem;
      }
    }
  
    /* === MOBILE ORDER FIX (logo + Home/About/Help+icons on top, categories on row 2) === */
    .main-nav-simple { gap: 1rem; flex-wrap: nowrap; }
    .logo-wrap { display:flex; align-items:center; }

    @media (max-width: 768px) {
      .main-nav-simple { flex-wrap: wrap; }
      .logo-wrap { order: 1; }
      .right-nav { order: 2; }
      .center-nav { order: 3; width: 100%; flex: 0 0 100%; justify-content: center; }
      .center-nav .nav-links { justify-content: center; gap: 1rem; flex-wrap: wrap; }
    }

  </style>
</head>

<body>

  <!-- ====================== HEADER (sama seperti Cart) ====================== -->
  <!-- ========================= HEADER (SAMA SEPERTI TRACKING/HELP) ========================= -->
<header class="header">
  <div class="container">
    <div class="main-nav-simple">

      <!-- LOGO -->
      <a href="index.php" class="logo-wrap">
        <img src="IMG/LOGO.jpg" alt="A.F.K FOOTWEAR Logo">
      </a>

      <!-- MENU KANAN (Home/About/Help + icons) -->
      <div class="right-nav">
        <ul class="right-nav-links">
          <li><a href="index.php">Home</a></li>
          <li><a href="About.php" class="active-link">About</a></li>
          <li><a href="Help.php">Help</a></li>
        </ul>

        <!-- TRACKING -->
        <a href="Tracking.php" class="icon-link track-icon">
          <i class="bx bxs-truck"></i>
          <?php if (!empty($trackingCount)): ?>
            <span class="track-count-badge"><?php echo (int)$trackingCount; ?></span>
          <?php endif; ?>
        </a>

        <!-- CART -->
        <a href="Cart.php" class="icon-link cart-icon">
          <i class='bx bx-cart'></i>
          <span id="header-cart-count" class="cart-item-count">0</span>
        </a>
      </div>

      <!-- MENU BAWAH (Mens/Womens/Kids/Discounts) -->
      <nav class="center-nav">
        <ul class="nav-links">
          <li><a href="Mens.php">Mens</a></li>
          <li><a href="Womens.php">Womens</a></li>
          <li><a href="Kids.php">Kids</a></li>
          <li><a href="Discount.php">Discounts</a></li>
        </ul>
      </nav>

    </div>
  </div>
</header>
  <!-- =================== /HEADER =================== -->

  <!-- =================== ABOUT SECTION =================== -->
  <section class="about-section-AFK">
    <div class="about-image-AFK">
      <img src="IMG/LOGO.jpg" alt="A.F.K FOOTWEAR Store Image">
    </div>
    <div class="about-content-AFK">
      <h2>Who We Are</h2>
      <p>
        Selamat Datang di A.F.K FOOTWEAR Store.
      </p>
      <p>
        Hi Pace Setter! Temukan koleksi sepatu pilihan yang dirancang untuk kenyamanan dan gaya kamu.
        Setiap langkahmu kami dukung dengan kualitas terbaik dan pelayanan sepenuh hati. Kami percaya bahwa
        sepatu bukan hanya pelengkap gaya, tapi juga bagian dari identitas dan kenyamanan setiap langkah.
      </p>
      <p>
        Berawal dari kecintaan pada dunia fashion dan olahraga, A.F.K FOOTWEAR didirikan di Surabaya oleh
        tiga orang laki-laki dengan visi yang sama. Kami hadir untuk memberikan pengalaman belanja sepatu
        yang berbeda dan menghadirkan koleksi sepatu terbaik dari brand terkenal di dunia seperti Nike,
        Adidas, dan Puma langsung ke genggamanmu.
      </p>
      <strong>Visi:</strong>
      <p>
        Menjadi destinasi utama untuk sepatu berkualitas yang menginspirasi setiap langkah percaya diri seseorang.
      </p>
      <strong>Misi:</strong>
      <p>
        Menghadirkan koleksi sepatu pilihan dari brand ternama yang mengutamakan kenyamanan dan gaya, melalui
        pelayanan personal yang sepenuh hati.
      </p>
    </div>
  </section>

  <!-- =================== FOOTER =================== -->
  <footer class="footer">
    <div class="footer-container container">
      <div class="footer-about">
        <h3 class="footer-title">About Us</h3>
       <p>Selamat Datang di A.F.K FOOTWEAR Store.<br> 
          Berawal dari kecintaan pada dunia fashion dan olahraga, A.F.K FOOTWEAR hadir untuk memberikan pengalaman belanja sepatu yang berbeda. 
          Kami ingin menghadirkan koleksi sepatu terbaik dari brand terkenal di dunia seperti Nike, Adidas, Puma, langsung ke genggamanmu.</p>
      </div>

      <div class="footer-links">
        <h3 class="footer-title">Products</h3>
        <ul>
          <li><a href="Mens.php">Mens</a></li>
          <li><a href="Womens.php">Womens</a></li>
          <li><a href="Kids.php">Kids</a></li>
          <li><a href="index.php">New Collections</a></li>
        </ul>
      </div>

      <div class="footer-links">
        <h3 class="footer-title">Help</h3>
        <ul>
          <li><a href="Help.php">Get Help</a></li>
          <li><a href="Help.php">Order Status</a></li>
          <li><a href="Help.php">Delivery</a></li>
          <li><a href="Help.php">Returns</a></li>
          <li><a href="Help.php">Payment Options</a></li>
        </ul>
      </div>

      <div class="footer-contact">
        <h3 class="footer-title">Contact Us</h3>
        <ul>
          <p><i class='bx bxs-map'></i> JL. Lidah Wetan, Surabaya</p>
          <p><i class='bx bxs-phone'></i> 0812-3456-7890</p>
          <p><i class='bx bxs-envelope'></i> AFKFootwear@gmail.com</p>
          <p><i class='bx bxs-time'></i> Setiap Hari: 08.00 - 22.00</p>
          <p><i class='bx bxs-web'></i> www.AFKFOOTWEAR.com</p>
        </ul>

        <div class="footer-socials">
          <a href="#"><i class='bx bxl-instagram'></i></a>
          <a href="#"><i class='bx bxl-facebook-square'></i></a>
          <a href="#"><i class='bx bxl-twitter'></i></a>
          <a href="#"><i class='bx bxl-whatsapp'></i></a>
          <a href="#"><i class='bx bxl-youtube'></i></a>
        </div>
      </div>
    </div>


    <div class="footer-bottom">
      <p>&copy; 2025 A.F.K FOOTWEAR. All rights reserved | Privacy Policy</p>
    </div>
  </footer>

  <!-- Scroll to top -->
  <a href="#" id="scrollTopBtn" class="scroll-top-btn">
    <i class="bx bx-up-arrow-alt"></i>
  </a>

  <!-- JS lain (kalau dipakai di halaman lain) -->
  <script src="js/pageup.js"></script>
  <script src="js/nav-active.js"></script>

  <!-- Badge cart di header -->
  <script>
    function getCartFromStorage() {
      const raw = localStorage.getItem('cartItems');
      if (!raw) return [];
      try { return JSON.parse(raw); } catch { return []; }
    }

    function updateCartIcon() {
      const cart = getCartFromStorage();
      const totalItems = cart.reduce((sum, item) => sum + (item.quantity || 0), 0);
      const badge = document.getElementById('header-cart-count');
      if (!badge) return;
      badge.textContent = totalItems;
      badge.style.display = totalItems > 0 ? 'block' : 'none';
    }

    document.addEventListener('DOMContentLoaded', updateCartIcon);
  </script>
</body>
</html>