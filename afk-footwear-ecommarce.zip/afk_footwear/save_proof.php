<?php
// save_proof.php
// Menerima upload bukti transfer dari Checkout (AJAX) dan menyimpannya ke folder + database.

header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/db.php';

$response = [
  'success' => false,
  'message' => 'Terjadi kesalahan tak dikenal.'
];

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
  $response['message'] = 'Metode harus POST.';
  echo json_encode($response);
  exit;
}

// Validasi file
if (!isset($_FILES['proof']) || $_FILES['proof']['error'] !== UPLOAD_ERR_OK) {
  $response['message'] = 'File bukti transfer belum di-upload atau terjadi error.';
  echo json_encode($response);
  exit;
}

// Ambil data lain (opsional, boleh kosong)
$order_code     = trim($_POST['order_code'] ?? '');
$customer_name  = trim($_POST['customer_name'] ?? '');
$customer_email = trim($_POST['customer_email'] ?? '');
$customer_phone = trim($_POST['customer_phone'] ?? '');
$payment_method = trim($_POST['payment_method'] ?? '');

if ($order_code === '' || $customer_name === '') {
  $response['message'] = 'Data order / nama pelanggan belum lengkap.';
  echo json_encode($response);
  exit;
}

// Siapkan folder upload
$uploadDir = __DIR__ . '/uploads/proofs/';
if (!is_dir($uploadDir)) {
  if (!mkdir($uploadDir, 0777, true)) {
    $response['message'] = 'Gagal membuat folder upload.';
    echo json_encode($response);
    exit;
  }
}

// Nama file aman
$originalName = $_FILES['proof']['name'];
$ext = pathinfo($originalName, PATHINFO_EXTENSION);
$ext = strtolower($ext ?: 'jpg');

$basename = 'proof_' . date('Ymd_His') . '_' . mt_rand(1000, 9999) . '.' . $ext;
$targetPath = $uploadDir . $basename;
$relativePath = 'uploads/proofs/' . $basename;

// Pindahkan file
if (!move_uploaded_file($_FILES['proof']['tmp_name'], $targetPath)) {
  $response['message'] = 'Gagal menyimpan file ke server.';
  echo json_encode($response);
  exit;
}

// Simpan ke database
$stmt = $conn->prepare("INSERT INTO payment_proofs
  (order_code, customer_name, customer_email, customer_phone, payment_method, proof_path)
  VALUES (?, ?, ?, ?, ?, ?)");
if ($stmt) {
  $stmt->bind_param(
    'ssssss',
    $order_code,
    $customer_name,
    $customer_email,
    $customer_phone,
    $payment_method,
    $relativePath
  );
  if ($stmt->execute()) {
    $response['success'] = true;
    $response['message'] = 'Bukti transfer berhasil disimpan.';
  } else {
    $response['message'] = 'Gagal menyimpan ke database: ' . $stmt->error;
  }
  $stmt->close();
} else {
  $response['message'] = 'Gagal menyiapkan query database.';
}

echo json_encode($response);
exit;
