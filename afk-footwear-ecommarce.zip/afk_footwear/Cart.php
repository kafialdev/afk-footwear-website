<?php
require_once __DIR__ . '/db.php';
session_start();
$trackingCount = getTrackingCount($conn);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Shopping Cart - A.F.K FOOTWEAR</title>

  <!-- Font & Icon -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
  <link href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet">

  <style>
    /* =================================
       GLOBAL STYLES & VARIABLES
    ==================================== */
    :root {
      --color-dark: #111827;
      --color-dark-muted: #374151;
      --color-accent: #B91C1C;
      --color-accent-hover: #9d2b2b;
      --color-light: #F9FAFB;
      --color-gray: #E5E7EB;
      --color-text-dark: #000000;
      --color-text-light: #F9FAFB;
      --footer-bg: #020033;
      --white-color: #ffffff;
      --primary-color: #9d2b2b;
      --font-primary: 'Poppins', sans-serif;
    }

    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    html { scroll-behavior: smooth; }

    body {
      background-color: #FFFFFF;
      color: var(--color-text-dark);
      font-family: var(--font-primary);
      line-height: 1.6;
    }

    .container {
      max-width: 1280px;
      margin: 0 auto;
      padding: 0 2rem;
    }

    a {
      text-decoration: none;
      color: inherit;
    }

    img {
      max-width: 100%;
      display: block;
    }

    /* =================================
       HEADER (SAMA DENGAN CHECKOUT)
    ==================================== */
    header.header {
      background-color: #020033;
      color: #ffffff;
      padding: 15px 0;
      position: sticky;
      top: 0;
      z-index: 999;
      box-shadow: 0 2px 10px rgba(0,0,0,0.15);
      width: 100%;
    }

    .main-nav-simple {
      display: flex;
      align-items: center;
      justify-content: space-between;
      max-width: 1400px;
      margin: 0 auto;
      padding: 0 2rem;
    }

    .main-nav-simple img {
      height: 45px;
    }

    /* HILANGKAN TITIK BULLET DI SEMUA UL NAV */
    .nav-links,
    .nav-links li,
    .right-nav-links,
    .right-nav-links li {
      list-style: none;
      margin: 0;
      padding: 0;
    }

    /* MENU TENGAH */
    .center-nav {
      flex: 1;
      display: flex;
      justify-content: center;
    }

    .center-nav .nav-links {
      display: flex;
      gap: 3rem;
    }

    .center-nav .nav-links a {
      color: #ffffff;
      font-weight: 600;
      font-size: 1.05rem;
      transition: color 0.3s ease;
    }

    .center-nav .nav-links a:hover {
      color: var(--color-accent);
    }

    /* MENU KANAN (Home - About - Help + Truck + Cart) */
    .right-nav {
      display: flex;
      align-items: center;
      gap: 2rem;
    }

    .right-nav-links {
      display: flex;
      align-items: center;
      gap: 2rem;
    }

    .right-nav-links a {
      color: #ffffff;
      font-weight: 600;
      font-size: 1.05rem;
      transition: color 0.3s ease;
    }

    .right-nav-links a:hover {
      color: var(--color-accent);
    }

    .icon-link {
      color: #ffffff;
      font-size: 1.6rem;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      transition: transform 0.2s ease, color 0.2s ease;
    }

    .icon-link:hover {
      transform: scale(1.1);
      color: var(--color-accent);
    }

    .cart-icon, .track-icon {
      position: relative;
    }

    .cart-item-count {
      position: absolute;
      top: -8px;
      right: -10px;
      background: #d00000;
      color: #fff;
      padding: 2px 7px;
      border-radius: 50%;
      font-size: 0.75rem;
      font-weight: bold;
      display: none;
    }

    .track-count-badge {
      position: absolute;
      top: -8px;
      right: -10px;
      background: #d00000;
      color: #fff;
      padding: 2px 7px;
      border-radius: 50%;
      font-size: 0.75rem;
      font-weight: bold;
    }

    /* =================================
       MAIN CART PAGE STYLES
    ==================================== */
    .site-main {
      padding: 4rem 0;
    }

    .cart-header h1 {
      font-size: 2.2rem;
      font-weight: 700;
      margin-bottom: 2rem;
      border-bottom: 2px solid var(--color-gray);
      padding-bottom: 1rem;
    }

    .cart-layout {
      display: grid;
      grid-template-columns: 2fr 1fr;
      gap: 3rem;
      align-items: flex-start;
    }

    /* --- Left Panel: Cart Items --- */
    .cart-items-panel {
      display: flex;
      flex-direction: column;
      gap: 1.5rem;
    }

    .cart-item {
      display: grid;
      grid-template-columns: 120px 1fr auto;
      gap: 1.5rem;
      padding-bottom: 1.5rem;
      border-bottom: 1px solid var(--color-gray);
    }

    .cart-item-image a {
      display: block;
      background-color: var(--color-light);
      border-radius: 8px;
      overflow: hidden;
    }

    .cart-item-image img {
      width: 120px;
      height: 120px;
      object-fit: contain;
      transition: transform 0.3s ease;
    }

    .cart-item-image a:hover img {
      transform: scale(1.05);
    }

    .cart-item-info {
      display: flex;
      flex-direction: column;
    }

    .cart-item-info .product-name {
      font-size: 1.1rem;
      font-weight: 600;
      color: var(--color-dark);
    }

    .cart-item-info .category {
      color: #6B7280;
      font-size: 0.9rem;
      margin: 0.25rem 0;
    }

    .cart-item-info .price {
      font-weight: 600;
      margin-top: auto;
    }

    .cart-item-actions {
      text-align: right;
      display: flex;
      flex-direction: column;
      justify-content: space-between;
    }

    .quantity-selector {
      display: flex;
      align-items: center;
      border: 1px solid var(--color-gray);
      border-radius: 8px;
      overflow: hidden;
      align-self: flex-end;
    }

    .quantity-selector button {
      background-color: transparent;
      border: none;
      cursor: pointer;
      padding: 0.5rem 0.8rem;
      font-size: 1rem;
    }

    .quantity-selector button:hover {
      background-color: var(--color-light);
    }

    .quantity-selector .quantity-input {
      width: 40px;
      text-align: center;
      border: none;
      font-size: 1rem;
      font-weight: 500;
    }

    .quantity-input::-webkit-outer-spin-button,
    .quantity-input::-webkit-inner-spin-button {
      -webkit-appearance: none;
      margin: 0;
    }

    .remove-item-btn {
      background: none;
      border: none;
      color: #6B7280;
      font-size: 0.9rem;
      cursor: pointer;
      margin-top: 1rem;
      transition: color 0.3s ease;
    }

    .remove-item-btn:hover {
      color: var(--color-accent);
    }

    .remove-item-btn i {
      margin-right: 0.25rem;
    }

    /* --- Right Panel: Order Summary --- */
    .order-summary-panel {
      background-color: var(--color-light);
      padding: 2rem;
      border-radius: 12px;
      border: 1px solid var(--color-gray);
      position: sticky;
      top: 120px;
    }

    .order-summary-panel h2 {
      font-size: 1.5rem;
      font-weight: 700;
      margin-bottom: 1.5rem;
    }

    .summary-row {
      display: flex;
      justify-content: space-between;
      margin-bottom: 1rem;
    }

    .summary-row.total {
      font-size: 1.2rem;
      font-weight: 700;
      margin-top: 1.5rem;
      color: var(--color-accent);
    }

    .summary-divider {
      height: 1px;
      background-color: var(--color-gray);
      margin: 1.5rem 0;
    }

    .payment-methods {
      margin-top: 1.8rem;
      text-align: center;
      padding-top: 1rem;
      border-top: 1px solid var(--color-gray);
    }

    .payment-methods p {
      display: none;
    }

    .payment-methods .icons {
      display: flex;
      justify-content: center;
      gap: 1.5rem;
      font-size: 2rem;
      color: var(--color-dark-muted);
    }

    .payment-methods i {
      transition: transform .2s ease;
    }

    .payment-methods i:hover {
      transform: scale(1.2);
    }

    /* --- Buttons --- */
    .btn {
      display: inline-block;
      padding: 0.8rem 1.5rem;
      border: none;
      border-radius: 8px;
      font-weight: 600;
      font-size: 1rem;
      cursor: pointer;
      text-align: center;
      transition: all 0.3s ease;
    }

    .btn-primary {
      background-color: var(--color-accent);
      color: white;
      width: 100%;
    }

    .btn-primary:hover {
      background-color: var(--color-accent-hover);
      transform: translateY(-2px);
      box-shadow: 0 4px 10px rgba(0,0,0,0.1);
    }

    /* =================================
       EMPTY CART VIEW
    ==================================== */
    .empty-cart-view {
      text-align: center;
      padding: 5rem 1rem;
    }

    .empty-cart-view .empty-icon {
      font-size: 6rem;
      color: var(--color-gray);
      margin-bottom: 1.5rem;
    }

    .empty-cart-view h2 {
      font-size: 2rem;
      font-weight: 700;
      margin-bottom: 1rem;
    }

    .empty-cart-view p {
      max-width: 450px;
      margin: 0 auto 2rem;
      color: #6B7280;
    }

    .empty-cart-actions {
      display: flex;
      justify-content: center;
      gap: 1rem;
      flex-wrap: wrap;
    }

    .empty-cart-actions .btn-primary {
      width: auto;
    }

    /* Notifikasi kecil kalau add to cart */
    .cart-notification {
      position: fixed;
      bottom: 20px;
      right: 20px;
      background: #111827;
      color: #fff;
      padding: 10px 16px;
      border-radius: 8px;
      opacity: 0;
      transform: translateY(15px);
      transition: all 0.3s ease;
      z-index: 9999;
      font-size: .9rem;
    }

    .cart-notification.show {
      opacity: 1;
      transform: translateY(0);
    }

    /* =================================
        RESPONSIVE
    ==================================== */
    @media (max-width: 992px) {
      .cart-layout {
        grid-template-columns: 1fr;
      }
      .order-summary-panel {
        position: static;
        margin-top: 2rem;
      }
    }

    @media (max-width: 768px) {
      .main-nav-simple {
        flex-wrap: wrap;
        gap: 1rem;
      }
      .center-nav .nav-links {
        gap: 1.5rem;
      }
      .cart-item {
        grid-template-columns: 80px 1fr;
        gap: 1rem;
      }
      .cart-item-actions {
        grid-column: 2 / 3;
        flex-direction: row;
        align-items: center;
        margin-top: 1rem;
        justify-content: space-between;
      }
      .quantity-selector {
        align-self: center;
      }
    }
  </style>
</head>
<body>

  <!-- ===== HEADER (SAMA DENGAN CHECKOUT) ===== -->
  <header class="header">
    <div class="container">
      <div class="main-nav-simple">
        <!-- LOGO -->
        <a href="index.php">
          <img src="IMG/LOGO.jpg" alt="A.F.K FOOTWEAR Logo" />
        </a>

        <!-- MENU TENGAH -->
        <nav class="center-nav">
          <ul class="nav-links">
            <li><a href="Mens.php">Mens</a></li>
            <li><a href="Womens.php">Womens</a></li>
            <li><a href="Kids.php">Kids</a></li>
            <li><a href="Discount.php">Discounts</a></li>
          </ul>
        </nav>

        <!-- MENU KANAN + TRUCK + CART -->
        <div class="right-nav">
          <ul class="right-nav-links">
            <li><a href="index.php">Home</a></li>
            <li><a href="About.php">About</a></li>
            <li><a href="Help.php">Help</a></li>
          </ul>

          <!-- ICON TRACKING ORDER -->
          <a href="Tracking.php" class="icon-link track-icon" title="Track Order">
            <i class="bx bxs-truck"></i>
            <?php if (!empty($trackingCount)): ?>
              <span class="track-count-badge"><?php echo $trackingCount; ?></span>
            <?php endif; ?>
          </a>

          <!-- ICON CART -->
          <a href="Cart.php" class="icon-link cart-icon" title="Cart">
            <i class='bx bx-cart'></i>
            <span id="header-cart-count" class="cart-item-count">0</span>
          </a>
        </div>
      </div>
    </div>
  </header>

  <!-- ===== MAIN CONTENT CART ===== -->
  <main class="site-main">
    <div class="container">
      <div class="cart-view" id="cart-view">
        <div class="cart-header">
          <h1 id="cart-title">Your Cart</h1>
        </div>

        <div class="cart-layout">
          <!-- List item keranjang -->
          <section class="cart-items-panel" id="cart-items-list"></section>

          <!-- Ringkasan order -->
          <aside class="order-summary-panel">
            <h2>Order Summary</h2>

            <div class="summary-row">
              <span>Subtotal</span>
              <span id="summary-subtotal">Rp 0</span>
            </div>

            <div class="summary-row">
              <span>Estimated Shipping</span>
              <span id="summary-shipping">Rp 25.000</span>
            </div>

            <div class="summary-divider"></div>

            <div class="summary-row total">
              <span>Total</span>
              <span id="summary-total">Rp 0</span>
            </div>

            <a href="Checkout.php" class="btn btn-primary checkout-btn">
              Proceed to Checkout
            </a>

            <div class="payment-methods">
              <div class="icons">
                <i class="fas fa-university"></i>
                <i class="fas fa-qrcode"></i>
              </div>
            </div>
          </aside>
        </div>
      </div>

      <!-- View jika keranjang kosong -->
      <div class="empty-cart-view" id="empty-cart-view" style="display:none;">
        <i class="fas fa-shopping-bag empty-icon"></i>
        <h2>Your Cart is Empty</h2>
        <p>Looks like you haven't added anything yet. Let's find something for you!</p>
        <div class="empty-cart-actions">
          <a href="Mens.php" class="btn btn-primary">Shop Men's</a>
          <a href="Womens.php" class="btn btn-primary">Shop Women's</a>
          <a href="Kids.php" class="btn btn-primary">Shop Kids'</a>
        </div>
      </div>
    </div>
  </main>

  <script>
    // =================== HELPER ===================
    function formatCurrency(amount) {
      return new Intl.NumberFormat('id-ID', {
        style: 'currency',
        currency: 'IDR',
        minimumFractionDigits: 0
      }).format(amount).replace(/\s/g, '');
    }

    function parseRupiah(rupiahString) {
      const numberString = String(rupiahString).replace(/[^0-9]/g, '');
      return parseFloat(numberString) || 0;
    }

    function showNotification(message) {
      const notif = document.createElement('div');
      notif.classList.add('cart-notification');
      notif.textContent = message;
      document.body.appendChild(notif);

      setTimeout(() => {
        notif.classList.add('show');
      }, 10);

      setTimeout(() => {
        notif.classList.remove('show');
        setTimeout(() => {
          document.body.removeChild(notif);
        }, 500);
      }, 3000);
    }

    // =================== CART LOGIC ===================
    function updateCartIcon() {
      const cart = JSON.parse(localStorage.getItem('cartItems')) || [];
      const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);

      const cartIconCounts = document.querySelectorAll('.cart-item-count, #header-cart-count');
      cartIconCounts.forEach(icon => {
        icon.textContent = totalItems;
        if (totalItems > 0) {
          icon.style.display = 'block';
        } else {
          icon.style.display = 'none';
        }
      });
    }

    function displayCartItems() {
      const cartItemsList = document.getElementById('cart-items-list');
      const cartView = document.getElementById('cart-view');
      const emptyCartView = document.getElementById('empty-cart-view');

      let cart = JSON.parse(localStorage.getItem('cartItems')) || [];

      if (cart.length === 0) {
        if (cartView) cartView.style.display = 'none';
        if (emptyCartView) emptyCartView.style.display = 'block';
        updateOrderSummary();
        updateCartIcon();
        return;
      }

      if (cartView) cartView.style.display = 'block';
      if (emptyCartView) emptyCartView.style.display = 'none';

      cartItemsList.innerHTML = '';

      cart.forEach(item => {
        const cartItemEl = document.createElement('div');
        cartItemEl.classList.add('cart-item');
        cartItemEl.dataset.id = item.id;
        cartItemEl.dataset.size = item.size;

        const itemPrice = item.priceRaw || parseRupiah(item.price);

        cartItemEl.innerHTML = `
          <div class="cart-item-image">
            <a href="#"><img src="${item.image}" alt="${item.name}"></a>
          </div>
          <div class="cart-item-info">
            <a href="#" class="product-name">${item.name}</a>
            <p class="category">Size: ${item.size}</p>
            <p class="price">${formatCurrency(itemPrice)}</p>
          </div>
          <div class="cart-item-actions">
            <div class="quantity-selector">
              <button class="quantity-btn-minus" data-action="minus">-</button>
              <input type="number" value="${item.quantity}" min="1" class="quantity-input">
              <button class="quantity-btn-plus" data-action="plus">+</button>
            </div>
            <button class="remove-item-btn" data-action="remove">
              <i class="fas fa-trash-alt"></i> Remove
            </button>
          </div>
        `;

        cartItemsList.appendChild(cartItemEl);
      });

      addCartEventListeners();
      updateOrderSummary();
      updateCartIcon();
    }

    function addCartEventListeners() {
      const cartItemsList = document.getElementById('cart-items-list');

      cartItemsList.querySelectorAll('.cart-item').forEach(itemEl => {
        const id = itemEl.dataset.id;
        const size = itemEl.dataset.size;

        itemEl.querySelector('.quantity-btn-minus').addEventListener('click', () => {
          updateQuantity(id, size, -1);
        });

        itemEl.querySelector('.quantity-btn-plus').addEventListener('click', () => {
          updateQuantity(id, size, 1);
        });

        itemEl.querySelector('.quantity-input').addEventListener('change', (e) => {
          changeQuantity(id, size, e.target.value);
        });

        itemEl.querySelector('.remove-item-btn').addEventListener('click', () => {
          removeItem(id, size);
        });
      });
    }

    function updateQuantity(id, size, change) {
      let cart = JSON.parse(localStorage.getItem('cartItems')) || [];
      const itemIndex = cart.findIndex(item => item.id === id && item.size === size);

      if (itemIndex > -1) {
        cart[itemIndex].quantity += change;
        if (cart[itemIndex].quantity < 1) cart[itemIndex].quantity = 1;
        localStorage.setItem('cartItems', JSON.stringify(cart));
        displayCartItems();
      }
    }

    function changeQuantity(id, size, newQuantity) {
      let cart = JSON.parse(localStorage.getItem('cartItems')) || [];
      const itemIndex = cart.findIndex(item => item.id === id && item.size === size);

      if (itemIndex > -1) {
        cart[itemIndex].quantity = parseInt(newQuantity) || 1;
        if (cart[itemIndex].quantity < 1) cart[itemIndex].quantity = 1;
        localStorage.setItem('cartItems', JSON.stringify(cart));
        displayCartItems();
      }
    }

    function removeItem(id, size) {
      let cart = JSON.parse(localStorage.getItem('cartItems')) || [];
      const itemIndex = cart.findIndex(item => item.id === id && item.size === size);

      if (itemIndex > -1) {
        if (confirm(`Are you sure you want to remove ${cart[itemIndex].name}?`)) {
          cart.splice(itemIndex, 1);
          localStorage.setItem('cartItems', JSON.stringify(cart));
          displayCartItems();
        }
      }
    }

    function updateOrderSummary() {
      let cart = JSON.parse(localStorage.getItem('cartItems')) || [];

      const shippingEl = document.getElementById('summary-shipping');
      const shippingCost = shippingEl ? parseRupiah(shippingEl.textContent) : 25000;

      const subtotal = cart.reduce((total, item) => {
        const price = item.priceRaw || parseRupiah(item.price);
        return total + (price * item.quantity);
      }, 0);

      const total = subtotal + shippingCost;

      const subtotalEl = document.getElementById('summary-subtotal');
      const totalEl = document.getElementById('summary-total');

      if (subtotalEl) subtotalEl.textContent = formatCurrency(subtotal);
      if (totalEl) totalEl.textContent = formatCurrency(total);
    }

    // ========================================
    // INIT
    // ========================================
    document.addEventListener('DOMContentLoaded', () => {
      displayCartItems();   // render cart
      updateCartIcon();     // update header icon
    });
  </script>
</body>
</html>
