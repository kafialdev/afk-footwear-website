<?php
require_once __DIR__ . '/db.php';
session_start();

$trackingCount = getTrackingCount($conn);
if (empty($_SESSION['user_id'])) {
  header('Location: signin.php');
  exit;
}

$userId = (int)$_SESSION['user_id'];
$submitted = isset($_GET['submitted']);

// ambil semua return milik user
$rows = [];
$sql = "
  SELECT r.id, r.order_id, r.product_id, r.item_code, r.return_address, r.reason, r.note, r.photo, r.status, r.created_at,
         o.total_amount, o.created_at AS order_created_at,
         p.name AS product_name
  FROM returns r
  JOIN orders o ON o.id = r.order_id
  LEFT JOIN products p ON p.id = r.product_id
  WHERE r.user_id = ?
  ORDER BY r.created_at DESC
";

$stmt = $conn->prepare($sql);
@$stmt->bind_param('i', $userId);
@$stmt->execute();
if ($stmt && ($res = $stmt->get_result())) {
  while ($r = $res->fetch_assoc()) {
    $rows[] = $r;
  }
}
if ($stmt) { $stmt->close(); }

function status_label($s) {
  $s = strtolower(trim((string)$s));
  if ($s === 'approved' || $s === 'disetujui') return ['Disetujui','ok','bx-check-circle'];
  if ($s === 'rejected' || $s === 'ditolak') return ['Ditolak','bad','bx-x-circle'];
  return ['Menunggu','wait','bx-time-five'];
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Status Return - A.F.K FOOTWEAR</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/style.css" />
  <link href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet">
  <style>
    body{
      background:#f3f4f6;
      font-family:'Poppins',system-ui,-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;
    }

    /* ========== HEADER GLOBAL (SAMA DENGAN RIWAYAT) ========== */
    header.header {
      background-color: #020033;
      color: #ffffff;
      padding: 15px 0;
      position: sticky;
      top: 0;
      z-index: 999;
      box-shadow: 0 2px 10px rgba(0, 0, 0, 0.15);
      width: 100%;
    }
    .main-nav-simple {
      display: flex;
      align-items: center;
      justify-content: space-between;
      max-width: 1400px;
      margin: 0 auto;
      padding: 0 2rem;
    }
    .main-nav-simple img { 
      height: 45px; 
      display:block; 
    }
    .center-nav { 
      flex: 1; 
      display: flex; 
      justify-content: center; 
    }
    .center-nav .nav-links {
      display: flex;
      gap: 3rem;
      list-style:none;
    }
    .center-nav .nav-links a {
      color: #ffffff;
      font-weight: 600;
      font-size: 1.05rem;
      padding:6px 4px;
      text-decoration:none;
      transition: color 0.3s ease;
    }
    .center-nav .nav-links a:hover,
    .center-nav .nav-links a.active-link { 
      color: var(--primary-color); 
    }

    .right-nav { 
      display: flex; 
      align-items: center; 
      gap: 2rem; 
    }
    .right-nav-links {
      display: flex;
      align-items: center;
      gap: 2rem;
      list-style:none;
    }
    .right-nav-links a {
      color: #ffffff;
      font-weight: 600;
      font-size: 1.05rem;
      text-decoration:none;
      transition: color 0.3s ease;
    }
    .right-nav-links a:hover { 
      color: var(--primary-color); 
    }

    .icon-link {
      color: #ffffff;
      font-size: 1.6rem;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      position:relative;
      text-decoration:none;
      transition: transform 0.2s ease, color 0.2s ease;
    }
    .icon-link:hover {
      transform: scale(1.1);
      color: var(--primary-color);
    }

    .cart-item-count {
      position: absolute;
      top: -8px;
      right: -10px;
      background: #d00000;
      color: white;
      padding: 2px 7px;
      border-radius: 50%;
      font-size: 0.75rem;
      font-weight: bold;
      display: none;
    }
    .track-count-badge{
      position:absolute;
      top:-8px;
      right:-10px;
      background:#d00000;
      color:#fff;
      padding:2px 7px;
      border-radius:50%;
      font-size:.75rem;
      font-weight:bold;
    }

    main{ max-width:1100px; margin:20px auto 32px; padding:0 16px 32px; }
    .card{ background:#fff; border:1px solid #e5e7eb; border-radius:16px; box-shadow:0 10px 30px rgba(15,23,42,.12); padding:16px; margin-bottom:12px; }
    .pill{ display:inline-flex; align-items:center; gap:8px; padding:8px 12px; border-radius:999px; border:1px solid #e5e7eb; background:#fff; font-weight:800; }
    .pill.ok{ border-color:#bbf7d0; background:#f0fdf4; color:#166534; }
    .pill.bad{ border-color:#fecaca; background:#fef2f2; color:#991b1b; }
    .pill.wait{ border-color:#fde68a; background:#fffbeb; color:#92400e; }
    .muted{ color:#6b7280; font-weight:600; }
    .btn{ display:inline-flex; align-items:center; gap:8px; padding:10px 14px; border-radius:12px; font-weight:800; text-decoration:none; border:1px solid #e5e7eb; background:#fff; color:#111827; }
    .btn-primary{ border-color:transparent; background:#111827; color:#fff; }
    .notice{ background:#ecfeff; border:1px solid #a5f3fc; color:#155e75; border-radius:14px; padding:12px 14px; margin-bottom:12px; }

    /* ========== RESPONSIVE (SAMAKAN HEADER & RAPIKAN) ========== */
    @media (max-width:768px){
          header.header{
            padding:8px 0;
          }
    
          .main-nav-simple{
            flex-wrap:wrap;
            gap:8px;
            height:auto;
            /* padding kiri-kanan supaya tidak mepet frame */
            padding:0 14px;
          }
    
          .main-nav-simple img{
            height:38px;
          }
    
          /* logo + menu kanan di baris atas */
          .right-nav{
            gap:14px;
          }
          .right-nav-links a{
            font-size:.9rem;
          }
          .icon-link{
            font-size:1.3rem;
          }
    
          /* menu kategori turun ke baris bawah, full width */
          .center-nav{
            order:3;
            width:100%;
            justify-content:center;
          }
          .center-nav .nav-links{
            justify-content:center;
            flex-wrap:wrap;
            gap:16px;
          }
          .center-nav .nav-links a{
            font-size:.9rem;
          }
    
          .cart-item-count,
          .track-count-badge{
            /* sedikit geser agar tidak nabrak icon di layar kecil */
            transform: translate(25%, -30%);
          }

  </style>
</head>
<body>

<header class="header">
  <div class="main-nav-simple">
    <a href="index.php">
      <img src="IMG/LOGO.jpg" alt="AFK Footwear Logo">
    </a>

    <nav class="center-nav">
      <ul class="nav-links">
        <li><a href="Mens.php">Mens</a></li>
        <li><a href="Womens.php">Womens</a></li>
        <li><a href="Kids.php">Kids</a></li>
        <li><a href="Discount.php">Discounts</a></li>
      </ul>
    </nav>

    <div class="right-nav">
      <ul class="right-nav-links">
        <li><a href="index.php">Home</a></li>
        <li><a href="About.php">About</a></li>
        <li><a href="Help.php">Help</a></li>
      </ul>

      <a href="Tracking.php" class="icon-link track-icon" title="Track Order">
        <i class="bx bxs-truck"></i>
        <?php if (!empty($trackingCount)): ?>
          <span class="track-count-badge"><?php echo $trackingCount; ?></span>
        <?php endif; ?>
      </a>

      <a href="Cart.php" class="icon-link cart-icon" title="Cart">
        <i class='bx bx-cart'></i>
        <span id="header-cart-count" class="cart-item-count">0</span>
      </a>
    </div>
  </div>
</header>

<main>
  <?php if ($submitted): ?>
    <div class="notice"><b>Berhasil!</b> Pengajuan return kamu sudah dikirim dan menunggu verifikasi admin.</div>
  <?php endif; ?>

  <div class="card">
    <div style="display:flex; justify-content:space-between; align-items:center; gap:12px; flex-wrap:wrap;">
      <div>
        <h2 style="margin:0; color:#111827;">Status Return</h2>
        <div class="muted" style="margin-top:6px;">Daftar pengajuan return yang pernah kamu buat.</div>
      </div>
      <div style="display:flex; gap:10px; flex-wrap:wrap;">
        <a class="btn" href="OrderHistory.php"><i class='bx bx-left-arrow-alt'></i> Riwayat Pesanan</a>
        <a class="btn btn-primary" href="Tracking.php"><i class='bx bxs-truck'></i> Tracking</a>
      </div>
    </div>
  </div>

  <?php if (empty($rows)): ?>
    <div class="card">
      <div class="muted">Belum ada pengajuan return.</div>
    </div>
  <?php else: ?>
    <?php foreach ($rows as $r): ?>
      <?php
        [$label,$cls,$icon] = status_label($r['status'] ?? '');
        $code = sprintf('#AFK%04d', (int)$r['order_id']);
        $dt   = !empty($r['created_at']) ? date('d M Y, H:i', strtotime($r['created_at'])) : '-';
      ?>
      <div class="card">
        <div style="display:flex; justify-content:space-between; align-items:center; gap:12px; flex-wrap:wrap;">
          <div>
            <div style="font-weight:900; color:#111827; font-size:1.05rem;"><?php echo htmlspecialchars($code); ?></div>
            <div class="muted" style="margin-top:4px;">Diajukan: <?php echo htmlspecialchars($dt); ?></div>
          </div>
          <span class="pill <?php echo $cls; ?>"><i class='bx <?php echo $icon; ?>'></i> <?php echo htmlspecialchars($label); ?></span>
        </div>

        <div style="margin-top:10px; display:grid; gap:6px;">
          <?php
            $pname = $r['product_name'] ?? '-';
            $pcode = $r['item_code'] ?? (isset($r['product_id']) ? sprintf('PRD%04d', (int)$r['product_id']) : '-');
          ?>
          <div><span class="muted">Barang:</span> <b><?php echo htmlspecialchars($pname); ?></b></div>
          <div><span class="muted">Kode Barang:</span> <b><?php echo htmlspecialchars($pcode); ?></b></div>
          <div><span class="muted">Alasan:</span> <b><?php echo htmlspecialchars($r['reason'] ?? '-'); ?></b></div>
          <?php if (!empty($r['note'])): ?>
            <div><span class="muted">Catatan:</span> <?php echo nl2br(htmlspecialchars($r['note'])); ?></div>
          <?php endif; ?>
          <?php if (!empty($r['return_address'])): ?>
            <div style="margin-top:6px;">
              <div class="muted">Lokasi Pengiriman Pengembalian:</div>
              <div style="white-space:pre-line; font-weight:700;"><?php echo htmlspecialchars($r['return_address']); ?></div>
            </div>
          <?php endif; ?>
          <?php if (!empty($r['photo'])): ?>
            <div style="margin-top:6px;">
              <a class="btn" href="<?php echo htmlspecialchars($r['photo']); ?>" target="_blank" rel="noopener"><i class='bx bx-image'></i> Lihat Foto</a>
            </div>
          <?php endif; ?>
        </div>
      </div>
    <?php endforeach; ?>
  <?php endif; ?>
</main>

</body>
</html>
