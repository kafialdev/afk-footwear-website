// =================================================================
// KESELURUHAN SCRIPT ANDA (DALAM SATU DOMContentLoaded)
// =================================================================
document.addEventListener('DOMContentLoaded', () => {

    // =================================================================
    // LOGIKA UNTUK HALAMAN PRODUK (misal: Mens.html)
    // =================================================================
    const addToCartButtons = document.querySelectorAll('.add-to-cart');

    addToCartButtons.forEach(button => {
        button.addEventListener('click', (event) => {
            const card = event.target.closest('.product-card');
            const sizeSelector = card.querySelector('.product-size');
            const selectedSize = sizeSelector.value;

            if (!selectedSize) {
                alert('Please select a size first!');
                return;
            }

            // KOREKSI 1: Ubah format 'product' agar sesuai dengan js/Checkout.js
            // Kita simpan harga mentah (priceRaw) dan harga string (price)
            const priceRaw = parseFloat(card.dataset.price);
            const product = {
                id: card.dataset.id,
                name: card.dataset.name,
                priceRaw: priceRaw, // Angka (misal: 1799000)
                price: formatCurrency(priceRaw), // String (misal: "Rp 1.799.000")
                image: card.dataset.image,
                size: selectedSize,
                quantity: 1
            };

            addItemToCart(product);
        });
    });

    // =================================================================
    // LOGIKA UNTUK HALAMAN KERANJANG (Cart.html)
    // =================================================================
    const cartItemsList = document.getElementById('cart-items-list');
    
    // Guard clause ini sudah benar, untuk mengecek apakah kita di halaman Cart.html
    if (cartItemsList) {
        displayCartItems();
    }
    
    // Panggil fungsi update ikon saat halaman pertama kali dimuat
    updateCartIcon();

    // KOREKSI 2: HAPUS 'DOMContentLoaded' KEDUA
    // Kode tombol checkout yang konflik sudah dihapus.
    // HTML Anda <a href="Checkout.html"> sudah cukup.
});

// =================================================================
// FUNGSI-FUNGSI GLOBAL
// (Diletakkan di luar DOMContentLoaded)
// =================================================================

function updateCartIcon() {
    // KOREKSI 3: GANTI NAMA KEY DARI 'cart' MENJADI 'cartItems'
    const cart = JSON.parse(localStorage.getItem('cartItems')) || [];
    const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);
    
    // Perbarui semua ikon keranjang (di header dan di halaman produk jika ada)
    const cartIconCounts = document.querySelectorAll('.cart-item-count, #header-cart-count');

    cartIconCounts.forEach(icon => {
        icon.textContent = totalItems;
        if (totalItems > 0) {
            icon.style.display = 'block'; // Tampilkan
            icon.classList.add('visible'); // Tambahkan class jika ada
        } else {
            icon.style.display = 'none'; // Sembunyikan
            icon.classList.remove('visible');
        }
    });
}

function addItemToCart(newItem) {
    // KOREKSI 3: GANTI NAMA KEY DARI 'cart' MENJADI 'cartItems'
    let cart = JSON.parse(localStorage.getItem('cartItems')) || [];
    
    // Logika 'find' Anda sudah benar
    const existingItem = cart.find(item => item.id === newItem.id && item.size === newItem.size);

    if (existingItem) {
        existingItem.quantity += 1;
    } 

    else {
        cart.push(newItem);
    }

    // KOREKSI 3: GANTI NAMA KEY DARI 'cart' MENJADI 'cartItems'
    localStorage.setItem('cartItems', JSON.stringify(cart));

    updateCartIcon(); 
    
    // Opsi: Tampilkan notifikasi pop-up yang lebih baik
    showNotification(`${newItem.name} (Size: ${newItem.size}) added to cart.`);
}

function displayCartItems() {
    const cartItemsList = document.getElementById('cart-items-list');
    const cartView = document.getElementById('cart-view');
    const emptyCartView = document.getElementById('empty-cart-view');
    
    // KOREKSI 3: GANTI NAMA KEY DARI 'cart' MENJADI 'cartItems'
    let cart = JSON.parse(localStorage.getItem('cartItems')) || [];

    // Logika empty view Anda sudah benar
    if (cart.length === 0) {
        if (cartView) cartView.style.display = 'none';
        if (emptyCartView) emptyCartView.style.display = 'block';
        updateOrderSummary(); // Pastikan summary juga 0
        updateCartIcon(); // Pastikan ikon 0
        return;
    }

    if (cartView) cartView.style.display = 'block';
    if (emptyCartView) emptyCartView.style.display = 'none';

    cartItemsList.innerHTML = '';
    cart.forEach(item => {
        // KOREKSI 4: Perbaiki cara membuat item, gunakan addEventListener (Best Practice)
        
        const cartItemEl = document.createElement('div');
        cartItemEl.classList.add('cart-item');
        // Gunakan 'item.id' dan 'item.size' sebagai data-attribute
        cartItemEl.dataset.id = item.id;
        cartItemEl.dataset.size = item.size;
        
        // Gunakan 'priceRaw' untuk kalkulasi, 'price' untuk tampilan jika perlu
        // Perbaikan kecil: pastikan itemPrice selalu valid
        const itemPrice = item.priceRaw || parseRupiah(item.price);
        
        cartItemEl.innerHTML = `
            <div class="cart-item-image">
                <a href="#"><img src="${item.image}" alt="${item.name}"></a>
            </div>
            <div class="cart-item-info">
                <a href="#" class="product-name">${item.name}</a>
                <p class="category">Size: ${item.size}</p>
                <p class="price">${formatCurrency(itemPrice)}</p>
            </div>
            <div class="cart-item-actions">
                <div class="quantity-selector">
                    <button class="quantity-btn-minus" data-action="minus">-</button>
                    <input type="number" value="${item.quantity}" min="1" class="quantity-input">
                    <button class="quantity-btn-plus" data-action="plus">+</button>
                </div>
                <button class="remove-item-btn" data-action="remove">
                    <i class="fas fa-trash-alt"></i> Remove
                </button>
            </div>
        `;
        
        cartItemsList.appendChild(cartItemEl);
    });
    
    // KOREKSI 5: Tambahkan event listener di sini, BUKAN via onclick
    addCartEventListeners();

    updateOrderSummary();
    updateCartIcon(); 
}

function addCartEventListeners() {
    const cartItemsList = document.getElementById('cart-items-list');

    cartItemsList.querySelectorAll('.cart-item').forEach(itemEl => {
        const id = itemEl.dataset.id;
        const size = itemEl.dataset.size;

        // Listener untuk tombol +/-
        itemEl.querySelector('.quantity-btn-minus').addEventListener('click', () => {
            updateQuantity(id, size, -1);
        });
        
        itemEl.querySelector('.quantity-btn-plus').addEventListener('click', () => {
            updateQuantity(id, size, 1);
        });

        // Listener untuk input manual
        itemEl.querySelector('.quantity-input').addEventListener('change', (e) => {
            changeQuantity(id, size, e.target.value);
        });

        // Listener untuk tombol remove
        itemEl.querySelector('.remove-item-btn').addEventListener('click', () => {
            removeItem(id, size);
        });
    });
}

// KOREKSI 6: Ubah fungsi agar menggunakan ID + Size, bukan 'index'
function updateQuantity(id, size, change) {
    let cart = JSON.parse(localStorage.getItem('cartItems')) || [];
    const itemIndex = cart.findIndex(item => item.id === id && item.size === size);

    if (itemIndex > -1) {
        cart[itemIndex].quantity += change;
        if (cart[itemIndex].quantity < 1) cart[itemIndex].quantity = 1;
        
        localStorage.setItem('cartItems', JSON.stringify(cart));
        displayCartItems();
    }
}

function changeQuantity(id, size, newQuantity) {
    let cart = JSON.parse(localStorage.getItem('cartItems')) || [];
    const itemIndex = cart.findIndex(item => item.id === id && item.size === size);

    if (itemIndex > -1) {
        cart[itemIndex].quantity = parseInt(newQuantity) || 1;
        if (cart[itemIndex].quantity < 1) cart[itemIndex].quantity = 1;
        
        localStorage.setItem('cartItems', JSON.stringify(cart));
        displayCartItems();
    }
}

function removeItem(id, size) {
    let cart = JSON.parse(localStorage.getItem('cartItems')) || [];
    const itemIndex = cart.findIndex(item => item.id === id && item.size === size);

    if (itemIndex > -1) {
        if (confirm(`Are you sure you want to remove ${cart[itemIndex].name}?`)) {
            cart.splice(itemIndex, 1); // Hapus item dari array
            localStorage.setItem('cartItems', JSON.stringify(cart));
            displayCartItems();
        }
    }
}

function updateOrderSummary() {
    let cart = JSON.parse(localStorage.getItem('cartItems')) || [];
    
    // Ambil biaya kirim dari HTML, fallback ke 25000
    const shippingEl = document.getElementById('summary-shipping');
    const shippingCost = shippingEl ? parseRupiah(shippingEl.textContent) : 25000;

    const subtotal = cart.reduce((total, item) => {
        const price = item.priceRaw || parseRupiah(item.price);
        return total + (price * item.quantity);
    }, 0);
    
    const total = subtotal + shippingCost;

    const subtotalEl = document.getElementById('summary-subtotal');
    const totalEl = document.getElementById('summary-total');

    // Cek jika elemen ada (ini akan mencegah error di halaman non-cart)
    if (subtotalEl) subtotalEl.textContent = formatCurrency(subtotal);
    if (totalEl) totalEl.textContent = formatCurrency(total);
}

function formatCurrency(amount) {
    return new Intl.NumberFormat('id-ID', {
        style: 'currency',
        currency: 'IDR',
        minimumFractionDigits: 0
    }).format(amount).replace(/\s/g, ''); // Hapus spasi agar konsisten
}

// ==========================================
// === PERBAIKAN: FUNGSI YANG HILANG DITAMBAHKAN ===
// ==========================================
/**
 * Mengubah string format Rupiah (mis: "Rp 1.799.000") menjadi angka (mis: 1799000)
 */
function parseRupiah(rupiahString) {
    // Hapus 'Rp', titik, spasi, dan karakter non-numerik lainnya
    const numberString = String(rupiahString).replace(/[^0-9]/g, '');
    // Ubah string angka menjadi tipe data number
    return parseFloat(numberString) || 0;
}

// =================================================================
// PERBAIKAN: Fungsi notifikasi sederhana untuk animasi mengambang
// =================================================================
function showNotification(message) {
    // Hapus notifikasi yang mungkin sudah ada agar tidak menumpuk
    const existingNotif = document.querySelector('.cart-notification');
    if (existingNotif) {
        existingNotif.remove();
    }

    const notif = document.createElement('div');
    notif.classList.add('cart-notification');
    notif.textContent = message;
    document.body.appendChild(notif);

    // Tampilkan notifikasi dengan sedikit delay agar transisi terlihat
    setTimeout(() => {
        notif.classList.add('show');
    }, 10); 

    // Sembunyikan dan hapus setelah beberapa detik
    setTimeout(() => {
        notif.classList.remove('show');
        // Tunggu transisi fade-out selesai sebelum menghapus elemen
        notif.addEventListener('transitionend', () => {
            notif.remove();
        }, { once: true }); // Pastikan event listener hanya dijalankan sekali
    }, 3000); // Notifikasi akan terlihat selama 3 detik
}

// =================================================================
// FUNGSI YANG DUPLIKAT DIHAPUS (sudah dilakukan sebelumnya)
// =================================================================
// Fungsi updateHeaderCartCount() telah dihapus
// karena fungsinya sudah ditangani dengan benar oleh updateCartIcon()
// yang menggunakan key localStorage 'cartItems' yang benar.