document.addEventListener("DOMContentLoaded", function () {
  const modal      = document.getElementById("productModal");
  const modalImg   = document.getElementById("modal-image");
  const modalName  = document.getElementById("modal-name");
  const modalPrice = document.getElementById("modal-price");
  const modalDesc  = document.getElementById("modal-desc");
  const closeBtn   = document.querySelector(".close-btn");

  if (!modal || !modalImg || !modalName || !modalPrice || !modalDesc) {
    // Kalau struktur modal belum ada / id-nya beda, stop saja
    return;
  }

  // Hanya tombol detail di section produk (Coming Soon di home)
  const detailButtons = document.querySelectorAll(".products .btn.btn-tertiary");

  detailButtons.forEach((button) => {
    button.addEventListener("click", function (e) {
      e.preventDefault();

      // ambil data dari atribut data-*
      const nameAttr  = this.getAttribute("data-name")  || "";
      const priceAttr = this.getAttribute("data-price") || "";
      const descAttr  = this.getAttribute("data-desc")  || "";
      const imgAttr   = this.getAttribute("data-img")   || "";

      const name  = nameAttr.trim();
      const price = priceAttr.trim();
      const desc  = descAttr.trim();
      const img   = imgAttr.trim();

      if (!name) {
        // kalau tidak ada nama, tidak usah apa-apa
        return;
      }

      // tampilkan modal + isi data
      modal.style.display = "flex";
      modalImg.src        = img || "";
      modalName.textContent  = name;
      modalPrice.textContent = price || "";
      modalDesc.textContent  = desc || "Belum ada deskripsi untuk produk ini.";
    });
  });

  // tombol X di pojok
  if (closeBtn) {
    closeBtn.addEventListener("click", () => {
      modal.style.display = "none";
    });
  }

  // klik area gelap di luar konten modal
  window.addEventListener("click", function (e) {
    if (e.target === modal) {
      modal.style.display = "none";
    }
  });
});
