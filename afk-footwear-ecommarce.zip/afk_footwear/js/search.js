// Menunggu seluruh halaman HTML selesai dimuat sebelum menjalankan skrip
document.addEventListener('DOMContentLoaded', function() {

    // 1. Memilih elemen HTML yang kita butuhkan
    const searchInput = document.querySelector(".search-container input[type='text']");
    const productCards = document.querySelectorAll('.product-card');

    // 2. Menambahkan 'event listener' pada kolom pencarian
    // Event 'keyup' akan berjalan setiap kali pengguna selesai menekan satu tombol keyboard
    searchInput.addEventListener('keyup', function() {
        
        // 3. Mengambil kata kunci pencarian dan mengubahnya menjadi huruf kecil
        // Ini agar pencarian tidak membedakan huruf besar/kecil (contoh: 'Nike' dan 'nike' sama)
        const searchTerm = searchInput.value.toLowerCase();

        // 4. Melakukan loop untuk setiap kartu produk yang ada
        productCards.forEach(card => {
            // Mengambil nama produk dari dalam kartu dan mengubahnya juga menjadi huruf kecil
            const productName = card.querySelector('.product-name').textContent.toLowerCase();

            // 5. Memeriksa apakah nama produk mengandung kata kunci yang dicari
            if (productName.includes(searchTerm)) {
                // Jika cocok, tampilkan kartu produk
                card.style.display = 'block'; 
            } else {
                // Jika tidak cocok, sembunyikan kartu produk
                card.style.display = 'none';
            }
        });
    });
});