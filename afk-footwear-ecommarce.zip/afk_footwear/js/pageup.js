// ==================== SCROLL TO TOP LOGIC ====================

// Ambil elemen tombol berdasarkan ID-nya
const scrollTopBtn = document.getElementById("scrollTopBtn");

// Tampilkan tombol ketika pengguna scroll ke bawah sejauh 200px
window.onscroll = function() {
    scrollFunction();
};

function scrollFunction() {
    // Kompatibel untuk berbagai browser
    if (document.body.scrollTop > 200 || document.documentElement.scrollTop > 200) {
        scrollTopBtn.classList.add("show");
    } else {
        scrollTopBtn.classList.remove("show");
    }
}

// Ketika tombol diklik, scroll halaman kembali ke atas dengan mulus
scrollTopBtn.addEventListener("click", function(e) {
    e.preventDefault(); // Mencegah perilaku default dari tag <a>
    window.scrollTo({
        top: 0,
        behavior: "smooth"
    });
});