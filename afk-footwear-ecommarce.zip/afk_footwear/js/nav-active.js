// nav-active.js

document.addEventListener("DOMContentLoaded", function() {
    // Ambil nama file halaman aktif (misal: "Mens.html" atau "Tracking.html")
    const currentPage = window.location.pathname.split("/").pop();

    /* =========================
       1️⃣  MENU TENGAH (Mens / Womens / Kids / Discounts)
       ========================= */
    const navLinks = document.querySelectorAll(".center-nav .nav-links a");

    navLinks.forEach(link => {
        const linkPage = link.getAttribute("href");
        if (linkPage === currentPage) {
            link.classList.add("active-link");
        }
    });

    /* =========================
       2️⃣  IKON TRACKING DI HEADER
       ========================= */
    const trackIcon = document.querySelector(".track-icon .bx");
    if (currentPage === "Tracking.html" && trackIcon) {
        trackIcon.style.color = "var(--primary-color)";
    }

    /* =========================
       3️⃣  OPSIONAL: CART ICON & SEARCH
       (tidak perlu aktif, tapi aman di-skip)
       ========================= */
});
