<?php
require_once __DIR__ . '/db.php';
session_start();
$trackingCount = getTrackingCount($conn);

// =====================
// Produk Coming Soon
// =====================
$comingSoonProducts = mysqli_query(
  $conn,
  "SELECT * FROM products WHERE is_coming_soon = 1 ORDER BY created_at DESC LIMIT 8"
);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>A.F.K FOOTWEAR</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />

  <link rel="stylesheet" href="css/style.css" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <link rel="shortcut icon" href="./foto/.jpg" type="image/x-icon" />

  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />

  <link
    href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap"
    rel="stylesheet"
  />

  <link
    href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css"
    rel="stylesheet"
  />
</head>

<body>

  <!-- =========================================
       HEADER — disamakan 100% dengan Mens.php
  ============================================ -->
  <header class="header">
    <div class="container">

      <!-- TOP NAV -->
      <div class="top-nav">
        <nav>
          <ul class="nav-links">
            <li><a href="index.php">Home</a></li>
            <li><a href="About.php">About</a></li>
            <li><a href="Help.php">Help</a></li>
            <?php if (isset($_SESSION['user_id'])): ?>
              <li><a href="logout.php">Logout</a></li>
            <?php else: ?>
              <li><a href="signin.php">Sign In</a></li>
            <?php endif; ?>
          </ul>
        </nav>
      </div>

      <!-- MAIN NAV -->
      <div class="main-nav">

        <!-- Logo -->
        <a href="index.php">
          <img src="IMG/LOGO.jpg" width="50" alt="A.F.K FOOTWEAR Logo">
        </a>

        <!-- Menu Tengah -->
        <nav class="center-nav">
          <ul class="nav-links">
            <li><a href="Mens.php">Mens</a></li>
            <li><a href="Womens.php">Womens</a></li>
            <li><a href="Kids.php">Kids</a></li>
            <li><a href="Discount.php" class="discount">Discounts</a></li>
          </ul>
        </nav>

        <!-- Search + Tracking + Cart -->
        <div class="header-actions">

          <!-- FORM SEARCH -->
          <form class="search-container" id="header-search-form" action="search.php" method="get">
            <i class="bx bx-search search-icon" id="header-search-icon"></i>
            <input
              type="text"
              name="q"
              id="header-search-input"
              placeholder="Search product..."
              autocomplete="off"
            >
          </form>

          <!-- Tracking -->
          <a href="Tracking.php" class="track-icon" title="Track Order">
            <i class="bx bxs-truck"></i>
            <?php if (!empty($trackingCount)): ?>
              <span class="track-count-badge"><?php echo $trackingCount; ?></span>
            <?php endif; ?>
          </a>

          <!-- Cart -->
          <a href="Cart.php" class="cart-icon">
            <i class="bx bx-cart"></i>
            <span class="cart-item-count" id="header-cart-count" style="display:none;">0</span>
          </a>

        </div>

      </div>
    </div>
  </header>

  <!-- =======================================================
      MAIN CONTENT
  ========================================================= -->
  <main>

    <!-- Hero Title -->
    <section class="hero">
      <div class="hero-content">
        <h1>Stop Dreaming, Start Walking!</h1>
        <p>
          Kehebatan ditempa dalam perjuangan. Bukan di garis Finish. 
          Inilah fondasi untuk setiap jejak legasimu yang abadi.
        </p>
      </div>
    </section>

    <!-- Hero Video -->
    <section class="hero-easthetic">
      <video autoplay muted loop playsinline class="hero-video">
        <source src="IMG/Cinematic Running.mp4" type="video/mp4" />
      </video>
      <div class="hero-overlay"></div>

      <div class="hero-content-shop">
        <a href="Discount.php" class="btn btn-primary">Shop Now</a>
      </div>
    </section>

    <!-- About -->
    <section class="about-intro container">
      <h2>About</h2>
      <p>
        Selamat Datang di A.F.K FOOTWEAR Store.<br />
        Hi Pace Setter! Temukan koleksi sepatu pilihan yang dirancang untuk kenyamanan
        dan gaya Kamu. Setiap langkahmu, kami dukung dengan kualitas terbaik dan
        pelayanan sepenuh hati.<br><br>

        Berawal dari kecintaan pada dunia fashion dan olahraga, A.F.K FOOTWEAR didirikan
        di Surabaya oleh tiga orang laki-laki yang memiliki visi yang sama. 
        Kami ingin menghadirkan koleksi sepatu terbaik dari brand-brand global seperti
        Nike, Adidas, dan Puma langsung ke genggamanmu.
      </p>
    </section>

    <!-- Brands -->
    <section class="brands container">
      <h2 class="section-title">Brands</h2>

      <div class="brands-container">

        <div class="brand-card">
          <img src="IMG/LOGO NIKE.png" alt="Nike Logo" class="brand-logo" />
          <h3>Nike</h3>
          <p>The best innovation & design for maximum athletic performance.</p>
        </div>

        <div class="brand-card">
          <img src="IMG/LOGO PUMA.jpg" alt="Puma Logo" class="brand-logo" />
          <h3>Puma</h3>
          <p>Sporty & fashionable design for a confident everyday style.</p>
        </div>

        <div class="brand-card">
          <img src="IMG/adidas-logo.png" alt="Adidas Logo" class="brand-logo" />
          <h3>Adidas</h3>
          <p>Comfort & style in every step with the latest technology.</p>
        </div>

      </div>
    </section>

    <!-- Products: Coming Soon dinamis -->
    <section class="products container">
      <h2 class="section-title">New Collections</h2>
      <h3 class="section-title-second">🔥Coming soon🔥</h3>

      <div class="products-grid">
        <?php if ($comingSoonProducts && mysqli_num_rows($comingSoonProducts) > 0): ?>
          <?php while ($p = mysqli_fetch_assoc($comingSoonProducts)): ?>
            <?php
              // pastikan deskripsi ada dan sudah di-trim
              $desc = trim($p['description'] ?? '');
            ?>
            <div class="product-card">
              <div class="product-image">
                <img
                  src="<?php echo htmlspecialchars($p['image_url']); ?>"
                  alt="<?php echo htmlspecialchars($p['name']); ?>"
                />
              </div>
              <h3 class="product-name">
                <?php echo htmlspecialchars($p['name']); ?>
              </h3>
              <p class="product-price">
                Rp. <?php echo number_format((int)$p['price'], 0, ',', '.'); ?>
              </p>
              <!-- Tombol detail (Coming Soon) buka modal deskripsi -->
              <a href="#"
                 class="btn btn-tertiary"
                 data-name="<?php echo htmlspecialchars($p['name'], ENT_QUOTES); ?>"
                 data-price="Rp. <?php echo number_format((int)$p['price'], 0, ',', '.'); ?>"
                 data-desc="<?php echo htmlspecialchars($desc, ENT_QUOTES); ?>"
                 data-img="<?php echo htmlspecialchars($p['image_url'], ENT_QUOTES); ?>">
                Details
              </a>
            </div>
          <?php endwhile; ?>
        <?php else: ?>
          <p style="grid-column:1/-1;text-align:center;color:#6b7280;font-size:14px;">
            Belum ada produk Coming Soon. Silakan atur dari halaman Admin.
          </p>
        <?php endif; ?>
      </div>
    </section>

  </main>

  <!-- FOOTER -->
  <footer class="footer">
    <div class="footer-container container">
      <div class="footer-about">
        <h3 class="footer-title">About Us</h3>
       <p>Selamat Datang di A.F.K FOOTWEAR Store.<br> 
          Berawal dari kecintaan pada dunia fashion dan olahraga, A.F.K FOOTWEAR hadir untuk memberikan pengalaman belanja sepatu yang berbeda. 
          Kami ingin menghadirkan koleksi sepatu terbaik dari brand terkenal di dunia seperti Nike, Adidas, Puma, langsung ke genggamanmu.</p>
      </div>

      <div class="footer-links">
        <h3 class="footer-title">Products</h3>
        <ul>
          <li><a href="Mens.php">Mens</a></li>
          <li><a href="Womens.php">Womens</a></li>
          <li><a href="Kids.php">Kids</a></li>
          <li><a href="index.php">New Collections</a></li>
        </ul>
      </div>

      <div class="footer-links">
        <h3 class="footer-title">Help</h3>
        <ul>
          <li><a href="Help.php">Get Help</a></li>
          <li><a href="Help.php">Order Status</a></li>
          <li><a href="Help.php">Delivery</a></li>
          <li><a href="Help.php">Returns</a></li>
          <li><a href="Help.php">Payment Options</a></li>
        </ul>
      </div>

      <div class="footer-contact">
        <h3 class="footer-title">Contact Us</h3>
        <ul>
          <p><i class="bx bxs-map"></i> JL. Lidah Wetan, Surabaya</p>
          <p><i class="bx bxs-phone"></i> 0812-3456-7890</p>
          <p><i class="bx bxs-envelope"></i> AFKFootwear@gmail.com</p>
          <p><i class="bx bxs-time"></i> Setiap Hari: 08.00 - 22.00</p>
          <p><i class="bx bxs-website"></i> www.A.F.K FOOTWEAR.com</p>
        </ul>

        <div class="footer-socials">
          <a href="#"><i class="bx bxl-instagram"></i></a>
          <a href="#"><i class="bx bxl-facebook-square"></i></a>
          <a href="#"><i class="bx bxl-twitter"></i></a>
          <a href="#"><i class="bx bxl-whatsapp"></i></a>
          <a href="#"><i class="bx bxl-youtube"></i></a>
        </div>
      </div>
    </div>

    <div class="footer-bottom">
      <p>&copy; 2025 A.F.K FOOTWEAR. All rights reserved | Privacy Policy</p>
    </div>
  </footer>

  <!-- MODAL -->
  <div id="productModal" class="modal">
    <div class="modal-content">
      <span class="close-btn">&times;</span>
      <img id="modal-image" class="modal-img" />
      <h2 id="modal-name"></h2>
      <p id="modal-price"></p>
      <p id="modal-desc"></p>
    </div>
  </div>

  <!-- JS -->
  <script src="js/search.js"></script>
  <script src="js/pageup.js"></script>
  <script src="js/nav-active.js"></script>
  <script src="js/product modal.js"></script>

  <!-- ===== Badge Cart Auto Update ===== -->
  <script>
    function getCart() {
      try { return JSON.parse(localStorage.getItem("cartItems")) || []; }
      catch { return []; }
    }

    function updateCartIcon() {
      const cart = getCart();
      const total = cart.reduce((t, item) => t + (item.quantity || 0), 0);
      const badge = document.getElementById("header-cart-count");

      if (badge) {
        badge.textContent = total;
        badge.style.display = total > 0 ? "block" : "none";
      }
    }

    document.addEventListener("DOMContentLoaded", updateCartIcon);
  </script>


  <script>
  document.addEventListener('DOMContentLoaded', function () {
    var form  = document.getElementById('header-search-form');
    var icon  = document.getElementById('header-search-icon');
    var input = document.getElementById('header-search-input');

    if (form && icon && input) {
      icon.style.cursor = 'pointer';

      icon.addEventListener('click', function () {
        var val = input.value.trim();
        if (val === '') {
          input.focus();
        } else {
          form.submit();
        }
      });
    }
  });
  </script>

</body>
</html>
