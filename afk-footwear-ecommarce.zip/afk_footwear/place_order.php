<?php
// place_order.php - simpan pesanan dari Checkout ke tabel orders dan order_items
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/db.php';
session_start();

function respond($ok, $msg = '', $extra = []) {
  echo json_encode(array_merge(['success' => $ok, 'message' => $msg], $extra), JSON_UNESCAPED_UNICODE);
  exit;
}

// hanya POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
  respond(false, 'Metode harus POST');
}

// baca JSON dari fetch()
$raw = file_get_contents('php://input');
if (!$raw) {
  respond(false, 'Payload kosong');
}
$data = json_decode($raw, true);
if (!is_array($data)) {
  respond(false, 'Payload tidak valid');
}

// =========================================================
// VALIDASI USER (WAJIB DARI SESSION, BUKAN DARI FRONTEND)
// Kenapa: supaya user_id selalu konsisten dengan tabel users
// dan menghindari error FK (orders.user_id -> users.id)
// =========================================================
$userId = (int)($_SESSION['user_id'] ?? 0);
if ($userId <= 0) {
  respond(false, 'User belum login. Silakan Sign In terlebih dahulu.');
}

// Pastikan user benar-benar ada di DB (kalau DB_NAME salah / beda database, ini sering terjadi)
$chk = $conn->prepare("SELECT id FROM users WHERE id = ? LIMIT 1");
if (!$chk) {
  respond(false, 'Gagal validasi user: ' . $conn->error);
}
$chk->bind_param('i', $userId);
$chk->execute();
$chkRes = $chk->get_result();
$exists = $chkRes ? (bool)$chkRes->fetch_assoc() : false;
$chk->close();
if (!$exists) {
  respond(false, 'Akun tidak ditemukan di database. Pastikan aplikasi terhubung ke database yang sama dengan tabel users (cek DB_NAME di db.php).');
}

// ambil item keranjang
$items = $data['items'] ?? [];
if (!is_array($items) || count($items) === 0) {
  respond(false, 'Item keranjang kosong.');
}

// metode pembayaran dari frontend (Transfer Bank / QRIS)
$paymentMethodRaw = trim($data['paymentMethod'] ?? 'Transfer Bank');

// NORMALISASI ke ENUM di DB: ENUM('Transfer','COD','E-Wallet')
if (stripos($paymentMethodRaw, 'qris') !== false || stripos($paymentMethodRaw, 'wallet') !== false) {
  $paymentMethod = 'E-Wallet';
} elseif (stripos($paymentMethodRaw, 'cod') !== false) {
  $paymentMethod = 'COD';
} else {
  // default ke Transfer untuk "Transfer Bank" dsb
  $paymentMethod = 'Transfer';
}

$total       = 0;
$orderItems  = [];

// hitung total dan siapkan data order_items
foreach ($items as $it) {
  $pid   = (int)($it['id'] ?? 0);
  $qty   = (int)($it['quantity'] ?? 1);
  $size  = trim($it['size'] ?? '');
  $price = (int)($it['priceRaw'] ?? 0);

  if ($price <= 0 && isset($it['price'])) {
    $price = (int)preg_replace('/[^0-9]/', '', $it['price']);
  }

  if ($pid <= 0 || $qty <= 0 || $price <= 0) {
    continue;
  }

  $subtotal   = $qty * $price;
  $total     += $subtotal;

  $orderItems[] = [
    'product_id' => $pid,
    'size_label' => $size,
    'quantity'   => $qty,
    'price'      => $price,
    'subtotal'   => $subtotal
  ];
}

if (count($orderItems) === 0) {
  respond(false, 'Tidak ada item valid di keranjang.');
}

// mulai transaksi
$conn->begin_transaction();

try {
  // simpan ke tabel orders
  $stmt = $conn->prepare("INSERT INTO orders (user_id,total_amount,payment_method,status) VALUES (?,?,?, 'Baru')");
  if (!$stmt) {
    throw new Exception('Gagal menyiapkan query orders: ' . $conn->error);
  }
  $stmt->bind_param('iis', $userId, $total, $paymentMethod);
  if (!$stmt->execute()) {
    $msg = 'Gagal menyimpan order: ' . $stmt->error;
    $stmt->close();
    throw new Exception($msg);
  }
  $orderId = $stmt->insert_id;
  $stmt->close();

  // simpan ke order_items (termasuk size_label per item)
  $stmtItem = $conn->prepare("INSERT INTO order_items (order_id,product_id,size_label,quantity,price,subtotal) VALUES (?,?,?,?,?,?)");
  if (!$stmtItem) {
    throw new Exception('Gagal menyiapkan query order_items: ' . $conn->error);
  }
  foreach ($orderItems as $row) {
    $pid      = (int)$row['product_id'];
    $size     = $row['size_label'] ?? '';
    $qty      = (int)$row['quantity'];
    $price    = (int)$row['price'];
    $subtotal = (int)$row['subtotal'];
    $stmtItem->bind_param('iisiii', $orderId, $pid, $size, $qty, $price, $subtotal);
    if (!$stmtItem->execute()) {
      $msg = 'Gagal menyimpan detail order: ' . $stmtItem->error;
      $stmtItem->close();
      throw new Exception($msg);
    }
  }
  $stmtItem->close();

  // update stok produk utama (kolom products.stock)
  $stmtUpdate = $conn->prepare("UPDATE products SET stock = GREATEST(stock - ?, 0) WHERE id = ?");
  // update stok per ukuran (tabel product_sizes) jika size_label tersedia
  $stmtUpdateSize = $conn->prepare("UPDATE product_sizes SET stock = GREATEST(stock - ?, 0) WHERE product_id = ? AND size_label = ?");
  if ($stmtUpdate) {
    foreach ($orderItems as $row) {
      $pid  = (int)$row['product_id'];
      $qty  = (int)$row['quantity'];
      $size = $row['size_label'] ?? '';
      // kurangi stok global produk
      $stmtUpdate->bind_param('ii', $qty, $pid);
      $stmtUpdate->execute();
      // kurangi stok per ukuran bila ada
      if ($stmtUpdateSize && $size !== '') {
        $stmtUpdateSize->bind_param('iis', $qty, $pid, $size);
        $stmtUpdateSize->execute();
      }
    }
    $stmtUpdate->close();
    if ($stmtUpdateSize) {
      $stmtUpdateSize->close();
    }
  }

  // commit transaksi
  $conn->commit();

  // buat kode order versi "AFK0001"
  $orderCode = 'AFK' . str_pad($orderId, 4, '0', STR_PAD_LEFT);

  respond(true, 'Order berhasil disimpan.', [
    'order_id'   => $orderId,
    'order_code' => $orderCode,
    'method_db'  => $paymentMethod,     // yang masuk ENUM di DB
    'method_raw' => $paymentMethodRaw   // yang dipilih user di frontend
  ]);

} catch (Exception $e) {
  $conn->rollback();
  respond(false, $e->getMessage());
}
?>
