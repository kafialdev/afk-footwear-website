<?php
require_once __DIR__ . '/db.php';
session_start();

// bantu debug jika insert gagal (tidak mengubah fitur lain)
// catatan: jika server production, boleh dihapus
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

// wajib login
if (empty($_SESSION['user_id'])) {
  header('Location: signin.php');
  exit;
}

$userId  = (int)$_SESSION['user_id'];
$orderId = isset($_POST['order_id']) ? (int)$_POST['order_id'] : 0;
$productId = isset($_POST['product_id']) ? (int)$_POST['product_id'] : 0;
$reason  = trim($_POST['reason'] ?? '');
$note    = trim($_POST['note'] ?? '');
$returnAddress = trim($_POST['return_address'] ?? '');

if ($orderId <= 0 || $productId <= 0 || $reason === '') {
  header('Location: OrderHistory.php');
  exit;
}

// validasi order milik user dan status selesai
$stmt = $conn->prepare("SELECT id, status FROM orders WHERE id = ? AND user_id = ? LIMIT 1");
$stmt->bind_param('ii', $orderId, $userId);
$stmt->execute();
$order = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$order || ($order['status'] ?? '') !== 'Selesai') {
  header('Location: OrderHistory.php');
  exit;
}

// validasi produk memang ada di order tersebut
$stmt = $conn->prepare("SELECT product_id FROM order_items WHERE order_id = ? AND product_id = ? LIMIT 1");
$stmt->bind_param('ii', $orderId, $productId);
$stmt->execute();
$okItem = $stmt->get_result()->fetch_assoc();
$stmt->close();
if (!$okItem) {
  header('Location: ReturnRequest.php?order_id=' . $orderId);
  exit;
}

// buat kode barang (berdasarkan product_id)
$itemCode = sprintf('PRD%04d', $productId);

// cek duplicate (satu return per order)
$stmt = $conn->prepare("SELECT id FROM returns WHERE order_id = ? AND user_id = ? LIMIT 1");
$stmt->bind_param('ii', $orderId, $userId);
@$stmt->execute();
if ($stmt && ($r = $stmt->get_result()) && $r->fetch_assoc()) {
  $stmt->close();
  header('Location: ReturnRequest.php?order_id=' . $orderId);
  exit;
}
if ($stmt) { $stmt->close(); }

// handle upload foto (opsional)
$photoPath = null;
if (!empty($_FILES['photo']) && is_array($_FILES['photo']) && ($_FILES['photo']['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_OK) {
  $tmp  = $_FILES['photo']['tmp_name'];
  $size = (int)($_FILES['photo']['size'] ?? 0);

  // batas 2MB
  if ($size > 2 * 1024 * 1024) {
    header('Location: ReturnRequest.php?order_id=' . $orderId);
    exit;
  }

  $finfo = new finfo(FILEINFO_MIME_TYPE);
  $mime  = $finfo->file($tmp);
  $ext = null;
  if ($mime === 'image/jpeg') $ext = 'jpg';
  elseif ($mime === 'image/png') $ext = 'png';
  elseif ($mime === 'image/webp') $ext = 'webp';

  if ($ext) {
    $dir = __DIR__ . '/uploads/returns';
    if (!is_dir($dir)) {
      @mkdir($dir, 0755, true);
    }
    $name = 'ret_' . $orderId . '_' . $userId . '_' . date('YmdHis') . '.' . $ext;
    $dest = $dir . '/' . $name;
    if (@move_uploaded_file($tmp, $dest)) {
      $photoPath = 'uploads/returns/' . $name;
    }
  }
}

// insert return
$status = 'pending';
$stmt = $conn->prepare("INSERT INTO returns (order_id, user_id, product_id, item_code, reason, note, photo, return_address, status)
                        VALUES (?,?,?,?,?,?,?,?,?)");

// tipe parameter harus sesuai kolom: order_id(i), user_id(i), product_id(i), sisanya string
$stmt->bind_param('iiissssss', $orderId, $userId, $productId, $itemCode, $reason, $note, $photoPath, $returnAddress, $status);

try {
  $stmt->execute();
} catch (Throwable $e) {
  // simpan error singkat untuk ditampilkan setelah redirect
  $_SESSION['return_error'] = 'Gagal mengirim pengajuan return. Pastikan tabel returns sudah terimport. (' . $e->getMessage() . ')';
  $stmt->close();
  header('Location: ReturnRequest.php?order_id=' . $orderId);
  exit;
}

$stmt->close();

header('Location: ReturnMy.php?submitted=1');
exit;
