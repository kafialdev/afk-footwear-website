<?php
require_once __DIR__ . '/db.php';
session_start();
$trackingCount = getTrackingCount($conn);

// wajib login sebagai customer
if (empty($_SESSION['user_id'])) {
  header('Location: signin.php');
  exit;
}

$userId = (int)$_SESSION['user_id'];

// ====== PROSES KONFIRMASI BARANG DITERIMA ======
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['confirm_receive'], $_POST['order_id'])) {
  $orderId = (int)$_POST['order_id'];

  // update status pesanan menjadi Selesai (Delivered) untuk order milik user ini
  if ($orderId > 0) {
    if ($stmtU = $conn->prepare("UPDATE orders SET status = 'Selesai' WHERE id = ? AND user_id = ? LIMIT 1")) {
      $stmtU->bind_param('ii', $orderId, $userId);
      $stmtU->execute();
      $stmtU->close();
    }
  }

  // setelah konfirmasi, reload halaman supaya data di Tracking & Admin ikut ter-update
  header('Location: Tracking.php?success=1');
  exit;
}

// ====== AMBIL ORDER USER (Baru, Diproses, Dikirim) ======
$orders = [];
$stmt = $conn->prepare("SELECT * FROM orders WHERE user_id = ? AND status IN ('Baru','Diproses','Dikirim') ORDER BY created_at DESC");
$stmt->bind_param('i', $userId);
$stmt->execute();
$res = $stmt->get_result();
while ($row = $res->fetch_assoc()) {
  $orders[] = $row;
}
$stmt->close();

// fungsi stepper
function map_step($status) {
  switch ($status) {
    case 'Baru':     return 1;
    case 'Diproses': return 2;
    case 'Dikirim':  return 3;
    case 'Selesai':  return 4;
    default:         return 1;
  }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Tracking - A.F.K FOOTWEAR</title>
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <link rel="stylesheet" href="css/style.css" />
  <link href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet">

  <style>
    body{
      background:#f3f4f6;
      font-family:'Poppins',system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;
    }

    /* ========== HEADER GLOBAL (SAMA DENGAN RIWAYAT) ========== */
    header.header {
      background-color: #020033;
      color: #ffffff;
      padding: 15px 0;
      position: sticky;
      top: 0;
      z-index: 999;
      box-shadow: 0 2px 10px rgba(0, 0, 0, 0.15);
      width: 100%;
    }
    .main-nav-simple {
      display: flex;
      align-items: center;
      justify-content: space-between;
      max-width: 1400px;
      margin: 0 auto;
      padding: 0 2rem;
    }
    .main-nav-simple img { 
      height: 45px; 
      display:block; 
    }
    .center-nav { 
      flex: 1; 
      display: flex; 
      justify-content: center; 
    }
    .center-nav .nav-links {
      display: flex;
      gap: 3rem;
      list-style:none;
    }
    .center-nav .nav-links a {
      color: #ffffff;
      font-weight: 600;
      font-size: 1.05rem;
      padding:6px 4px;
      text-decoration:none;
      transition: color 0.3s ease;
    }
    .center-nav .nav-links a:hover,
    .center-nav .nav-links a.active-link { 
      color: var(--primary-color); 
    }

    .right-nav { 
      display: flex; 
      align-items: center; 
      gap: 2rem; 
    }
    .right-nav-links {
      display: flex;
      align-items: center;
      gap: 2rem;
      list-style:none;
    }
    .right-nav-links a {
      color: #ffffff;
      font-weight: 600;
      font-size: 1.05rem;
      text-decoration:none;
      transition: color 0.3s ease;
    }
    .right-nav-links a:hover { 
      color: var(--primary-color); 
    }

    .icon-link {
      color: #ffffff;
      font-size: 1.6rem;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      position:relative;
      text-decoration:none;
      transition: transform 0.2s ease, color 0.2s ease;
    }
    .icon-link:hover {
      transform: scale(1.1);
      color: var(--primary-color);
    }

    .cart-item-count {
      position: absolute;
      top: -8px;
      right: -10px;
      background: #d00000;
      color: white;
      padding: 2px 7px;
      border-radius: 50%;
      font-size: 0.75rem;
      font-weight: bold;
      display: none;
    }
    .track-count-badge{
      position:absolute;
      top:-8px;
      right:-10px;
      background:#d00000;
      color:#fff;
      padding:2px 7px;
      border-radius:50%;
      font-size:.75rem;
      font-weight:bold;
    }

    /* ========== KONTEN TRACKING ========== */
    .tracking-wrap{ 
      padding:100px 0 48px; 
    }
    .tracking-inner{ 
      max-width:900px; 
      margin:0 auto; 
      padding:0 16px;
    }

    .tracking-header-main{
      display:flex;
      justify-content:space-between;
      align-items:center;
      gap:12px;
      margin-bottom:18px;
      flex-wrap:wrap;
    }
    .tracking-header-main .title-main{
      font-size:1.6rem;
      font-weight:700;
      color:#111827;
    }
    .history-btn{
      display:inline-flex;
      align-items:center;
      gap:8px;
      padding:8px 14px;
      border-radius:999px;
      background:#111827;
      color:#f9fafb;
      font-size:.9rem;
      font-weight:600;
      text-decoration:none;
      border:1px solid transparent;
      transition:background .2s, transform .1s, border-color .2s;
    }
    .history-btn i{ font-size:1.1rem; }
    .history-btn:hover{
      background:#020033;
      border-color:#020033;
      transform:translateY(-1px);
    }

    .track-card{
      background:#ffffff;
      border-radius:14px;
      padding:22px 24px;
      box-shadow:0 8px 24px rgba(0,0,0,.08);
      margin-bottom:20px;
    }
    .section-title{
      text-align:left;
      font-size:1.4rem;
      margin-bottom:1rem;
      font-weight:600;
      color:#222;
    }
    .order-id-badge{
      display:inline-flex;
      align-items:center;
      gap:8px;
      background:#f7f7f7;
      border:1px solid #ececec;
      padding:8px 12px;
      border-radius:999px;
      font-size:.9rem;
      font-weight:600;
      color:#555;
      margin-bottom:10px;
    }
    .order-id-badge i{ color:var(--primary-color); }

    .stepper{
      display:flex;
      justify-content:space-between;
      align-items:center;
      margin:14px 0 4px;
    }
    .step{
      display:flex;
      flex-direction:column;
      align-items:center;
      gap:6px;
      flex:1;
      font-size:.8rem;
    }
    .step span.label{
      color:#555;
      font-weight:500;
    }
    .dot-wrap{
      display:flex;
      align-items:center;
      justify-content:center;
      gap:6px;
      width:100%;
    }
    .dot{
      width:14px;
      height:14px;
      border-radius:50%;
      background:#d1d5db;
    }
    .line{
      flex:1;
      height:3px;
      border-radius:999px;
      background:#e5e7eb;
    }
    .step.done .dot{ background:#22c55e; }
    .step.done .line{ background:#22c55e; }
    .step.active .dot{ background:#3b82f6; }

    .items-table{
      width:100%;
      border-collapse:collapse;
      font-size:.9rem;
    }
    .items-table th,
    .items-table td{
      padding:8px 6px;
      border-bottom:1px solid #f1f1f1;
    }
    .items-table th{
      background:#fafafa;
      text-align:left;
      font-weight:600;
      color:#444;
    }
    .items-table td:nth-child(2),
    .items-table td:nth-child(3),
    .items-table td:nth-child(4){
      text-align:center;
    }
    .items-table tfoot td{
      border-top:1px solid #e5e5e5;
      border-bottom:none;
      font-weight:600;
    }
    .price{
      color:#9d2b2b;
      font-weight:600;
    }

    .meta-line{
      display:flex;
      justify-content:space-between;
      font-size:.9rem;
      margin:5px 0;
      color:#555;
    }
    .meta-line b{ 
      color:#111; 
      font-weight:600; 
    }

    .status-pill{
      background:#eef6ff;
      color:#0b66c3;
      padding:5px 10px;
      border-radius:999px;
      border:1px solid #d8e9ff;
      display:inline-flex;
      align-items:center;
      gap:6px;
      font-size:.85rem;
      font-weight:600;
    }

    .confirm-card button{
      margin-top:12px;
      width:100%;
      padding:12px 16px;
      border:none;
      border-radius:999px;
      background:#b12222;
      color:#fff;
      font-weight:600;
      cursor:pointer;
      display:inline-flex;
      align-items:center;
      justify-content:center;
      gap:6px;
      transition:background .2s, transform .1s;
    }
    .confirm-card button:hover{
      background:#8e1b1b;
      transform:translateY(-1px);
    }

    .alert-success{
      background:#dcfce7;
      border:1px solid #22c55e;
      color:#14532d;
      padding:10px 14px;
      border-radius:999px;
      font-size:.9rem;
      margin-bottom:16px;
      display:flex;
      align-items:center;
      gap:8px;
    }

    /* ========== RESPONSIVE (SAMAKAN HEADER & RAPIKAN) ========== */
    @media (max-width:768px){
      header.header{
        padding:8px 0;
      }

      .main-nav-simple{
        flex-wrap:wrap;
        gap:8px;
        height:auto;
        /* padding kiri-kanan supaya tidak mepet frame */
        padding:0 14px;
      }

      .main-nav-simple img{
        height:38px;
      }

      /* logo + menu kanan di baris atas */
      .right-nav{
        gap:14px;
      }
      .right-nav-links a{
        font-size:.9rem;
      }
      .icon-link{
        font-size:1.3rem;
      }

      /* menu kategori turun ke baris bawah, full width */
      .center-nav{
        order:3;
        width:100%;
        justify-content:center;
      }
      .center-nav .nav-links{
        justify-content:center;
        flex-wrap:wrap;
        gap:16px;
      }
      .center-nav .nav-links a{
        font-size:.9rem;
      }

      .cart-item-count,
      .track-count-badge{
        /* sedikit geser agar tidak nabrak icon di layar kecil */
        transform: translate(25%, -30%);
      }

      .tracking-wrap{
        padding-top:90px;
      }
      .tracking-inner{
        padding:0 14px;
      }
      .track-card{
        padding:16px;
      }
      .meta-line{
        flex-direction:column;
        align-items:flex-start;
        gap:2px;
      }
      .stepper{
        flex-direction:column;
        align-items:flex-start;
        gap:10px;
      }
      .tracking-header-main{
        flex-direction:column;
        align-items:flex-start;
        gap:8px;
      }
      .tracking-header-main .title-main{
        font-size:1.3rem;
      }
      .history-btn{
        align-self:stretch;
        justify-content:center;
        font-size:0.85rem;
        padding:8px 10px;
      }
    }
  </style>
</head>
<body>
<header class="header">
  <div class="main-nav-simple">
    <a href="index.php">
      <img src="IMG/LOGO.jpg" alt="AFK Footwear Logo">
    </a>

    <nav class="center-nav">
      <ul class="nav-links">
        <li><a href="Mens.php">Mens</a></li>
        <li><a href="Womens.php">Womens</a></li>
        <li><a href="Kids.php">Kids</a></li>
        <li><a href="Discount.php">Discounts</a></li>
      </ul>
    </nav>

    <div class="right-nav">
      <ul class="right-nav-links">
        <li><a href="index.php">Home</a></li>
        <li><a href="About.php">About</a></li>
        <li><a href="Help.php">Help</a></li>
      </ul>

      <a href="Tracking.php" class="icon-link track-icon" title="Track Order">
        <i class="bx bxs-truck"></i>
        <?php if (!empty($trackingCount)): ?>
          <span class="track-count-badge"><?php echo $trackingCount; ?></span>
        <?php endif; ?>
      </a>

      <a href="Cart.php" class="icon-link cart-icon" title="Cart">
        <i class='bx bx-cart'></i>
        <span id="header-cart-count" class="cart-item-count">0</span>
      </a>
    </div>
  </div>
</header>

<main class="tracking-wrap">
  <div class="tracking-inner">

    <div class="tracking-header-main">
      <h1 class="title-main">Tracking Order</h1>
      <a href="OrderHistory.php" class="history-btn">
        <i class="bx bx-time-five"></i>
        <span>Riwayat Pemesanan</span>
      </a>
    </div>

    <?php if (!empty($_GET['success'])): ?>
      <div class="alert-success">
        <i class='bx bx-check-circle'></i>
        <span>Terima kasih! Status pesanan sudah diperbarui menjadi <b>Selesai</b> dan dipindahkan ke <b>Riwayat Pembelian</b>.</span>
      </div>
    <?php endif; ?>

    <?php if (empty($orders)): ?>
      <div class="track-card">
        <h2 class="section-title">Tidak ada pesanan yang sedang berjalan</h2>
        <p style="margin:8px 0 4px;">
          Saat ini tidak ada pesanan aktif yang sedang diproses. Jika kamu baru saja mengkonfirmasi pesanan, statusnya sudah dipindahkan ke <b>Riwayat Pembelian</b>.
        </p>
        <p style="margin:0;">
          Kamu bisa melihat daftar lengkap pesanan yang sudah selesai di halaman 
          <a href="OrderHistory.php" style="color:#0b66c3;font-weight:600;">Riwayat Pembelian</a> atau klik tombol di atas.
        </p>
      </div>
    <?php else: ?>

      <?php foreach ($orders as $order):
        $orderId   = (int)$order['id'];
        $stepIndex = map_step($order['status']);

        // ambil item per order
        $items = [];
        $stmtI = $conn->prepare(
          "SELECT oi.*, p.name 
           FROM order_items oi 
           JOIN products p ON p.id = oi.product_id 
           WHERE oi.order_id = ?"
        );
        $stmtI->bind_param('i', $orderId);
        $stmtI->execute();
        $resI = $stmtI->get_result();
        while ($rowI = $resI->fetch_assoc()) {
          $items[] = $rowI;
        }
        $stmtI->close();

        // hitung subtotal dan shipping
        $subtotal = 0;
        foreach ($items as $it) {
          $subtotal += (int)$it['subtotal'];
        }

        // total yang tersimpan di DB
        $totalDb = (int)$order['total_amount'];

        // Jika total di DB sudah termasuk ongkir → shipping = totalDb - subtotal
        if ($totalDb > $subtotal) {
          $shipping = max($totalDb - $subtotal, 0);
          $total    = $totalDb;
        } else {
          // fallback ongkir flat Rp 25.000
          $shipping = 25000;
          $total    = $subtotal + $shipping;
        }
      ?>

      <!-- CARD 1: ID + STEPPER + TGL -->
      <div class="track-card">
        <div style="display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap;">
          <div class="order-id-badge">
            <i class="bx bx-hash"></i>
            <span>#AFK<?php echo str_pad($orderId, 4, '0', STR_PAD_LEFT); ?></span>
          </div>
        </div>

        <div class="stepper">
          <?php
            $labels = ['Processed','Shipped','Out for Delivery','Delivered'];
            for ($i=1; $i<=4; $i++):
              $cls = 'step';
              if ($stepIndex > $i)  $cls .= ' done';
              if ($stepIndex === $i) $cls .= ' active';
          ?>
          <div class="<?php echo $cls; ?>">
            <div class="dot-wrap">
              <span class="dot"></span><span class="line"></span>
            </div>
            <span class="label"><?php echo $labels[$i-1]; ?></span>
          </div>
          <?php endfor; ?>
        </div>

        <div class="meta-line">
          <span>Order Date</span>
          <span><?php echo date('d M Y H:i', strtotime($order['created_at'])); ?></span>
        </div>
      </div>

      <!-- CARD 2: ITEMS -->
      <div class="track-card">
        <h2 class="section-title">Order Items</h2>
        <table class="items-table">
          <thead>
            <tr>
              <th>Produk</th>
              <th>Qty</th>
              <th>Harga</th>
              <th>Subtotal</th>
            </tr>
          </thead>
          <tbody>
          <?php foreach ($items as $it): ?>
            <tr>
              <td style="text-align:left;"><?php echo htmlspecialchars($it['name']); ?></td>
              <td><?php echo (int)$it['quantity']; ?></td>
              <td class="price">Rp <?php echo number_format($it['price'],0,',','.'); ?></td>
              <td class="price">Rp <?php echo number_format($it['subtotal'],0,',','.'); ?></td>
            </tr>
          <?php endforeach; ?>
          </tbody>
          <tfoot>
            <tr>
              <td colspan="3" style="text-align:right;">Subtotal</td>
              <td class="price">Rp <?php echo number_format($subtotal,0,',','.'); ?></td>
            </tr>
            <tr>
              <td colspan="3" style="text-align:right;">Shipping</td>
              <td class="price">Rp <?php echo number_format($shipping,0,',','.'); ?></td>
            </tr>
            <tr>
              <td colspan="3" style="text-align:right;">Total</td>
              <td class="price">Rp <?php echo number_format($total,0,',','.'); ?></td>
            </tr>
          </tfoot>
        </table>
      </div>

      <!-- CARD 3: INFO PENGIRIMAN + METODE PEMBAYARAN -->
      <div class="track-card">
        <h2 class="section-title">Info Pengiriman</h2>

        <div class="meta-line">
          <span>Status</span>
          <?php
            $cls = 'status-pill status-new';
            if ($order['status']==='Diproses')   $cls='status-pill status-process';
            if ($order['status']==='Dikirim')    $cls='status-pill status-otw';
            if ($order['status']==='Selesai')    $cls='status-pill status-done';
            if ($order['status']==='Dibatalkan') $cls='status-pill status-cancel';
          ?>
          <span class="<?php echo $cls; ?>">
            <i class='bx bx-package'></i> <?php echo htmlspecialchars($order['status']); ?>
          </span>
        </div>

        <!-- Metode Pembayaran -->
        <div class="meta-line">
          <span>Metode Pembayaran</span>
          <span>
            <?php
              // Normalisasi: enum di DB = 'Transfer', 'COD', 'E-Wallet'
              // Tampilkan label ramah: "Bank Transfer" atau "QRIS"
              $rawMethod = strtolower(trim($order['payment_method'] ?? ''));

              if ($rawMethod === 'e-wallet' || strpos($rawMethod, 'wallet') !== false) {
                $methodLabel = 'QRIS';
              } else {
                // selain E-Wallet anggap saja Transfer Bank
                $methodLabel = 'Transfer Bank';
              }
              echo $methodLabel;
            ?>
          </span>
        </div>

        <div class="meta-line">
          <span>Metode Pengiriman</span>
          <span>Standard Shipping</span>
        </div>
        <div class="meta-line">
          <span>Estimasi Tiba</span>
          <span>2-5 hari kerja</span>
        </div>
      </div>

      <!-- CARD 4: KONFIRMASI -->
      <?php if ($order['status'] !== 'Selesai' && $order['status'] !== 'Dibatalkan'): ?>
      <div class="track-card confirm-card">
        <div class="meta-line" style="align-items:center;">
          <span>Sudah menerima barang?</span>
        </div>
        <form method="post" action="Tracking.php">
          <input type="hidden" name="order_id" value="<?php echo $orderId; ?>">
          <button type="submit" name="confirm_receive" value="1">
            <i class="bx bx-check-shield"></i>
            Konfirmasi Barang Sudah Diterima
          </button>
        </form>
      </div>
      <?php endif; ?>

      <?php endforeach; ?>
    <?php endif; ?>
  </div>
</main>

<script>
  function getCart(){
    try {
      const raw = localStorage.getItem('cartItems');
      if (!raw) return [];
      const data = JSON.parse(raw);
      return Array.isArray(data) ? data : [];
    } catch(e) { 
      return []; 
    }
  }
  function updateCartIcon(){
    const cart = getCart();
    const totalItems = cart.reduce((s,it)=> s + (it.quantity || 0), 0);
    var el = document.getElementById('header-cart-count');
    if (!el) return;
    if (totalItems > 0) {
      el.textContent = totalItems;
      el.style.display = 'block';
    } else {
      el.style.display = 'none';
    }
  }
  document.addEventListener('DOMContentLoaded', updateCartIcon);
</script>
</body>
</html>
