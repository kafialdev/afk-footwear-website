<?php
require_once __DIR__ . '/db.php';
session_start();
$trackingCount = getTrackingCount($conn);
$categoryPage = 'Kids';
$products = mysqli_query($conn, "SELECT * FROM products WHERE category='$categoryPage' ORDER BY created_at DESC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Kids - A.F.K FOOTWEAR</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />

  <link rel="stylesheet" href="css/style.css" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <link rel="shortcut icon" href="./foto/.jpg" type="image/x-icon" />
  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet" />
  <link href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet" />
</head>

<body>
  <!-- ===== HEADER ===== -->
  <header class="header">
    <div class="container">
      <div class="top-nav">
        <nav>
          <ul class="nav-links">
            <li><a href="index.php">Home</a></li>
            <li><a href="About.php">About</a></li>
            <li><a href="Help.php">Help</a></li>
            <?php if (isset($_SESSION['user_id'])): ?>
            <li><a href="logout.php">Logout</a></li>
            <?php else: ?>
            <li><a href="signin.php">Sign In</a></li>
            <?php endif; ?>
          </ul>
        </nav>
      </div>

      <div class="main-nav">
        <a href="index.php" aria-label="AFK Footwear Home">
          <img src="IMG/LOGO.jpg" width="50" alt="A.F.K FOOTWEAR Logo" />
        </a>

        <nav class="center-nav">
          <ul class="nav-links">
            <li><a href="Mens.php">Mens</a></li>
            <li><a href="Womens.php">Womens</a></li>
            <li><a href="Kids.php" class="active-link">Kids</a></li>
            <li><a href="Discount.php" class="discount">Discounts</a></li>
          </ul>
        </nav>

        <div class="header-actions">

          <!-- FORM SEARCH -->
          <form class="search-container" id="header-search-form" action="search.php" method="get">
            <i class="bx bx-search search-icon" id="header-search-icon"></i>
            <input
              type="text"
              name="q"
              id="header-search-input"
              placeholder="Search product..."
              autocomplete="off"
            >
          </form>

          <!-- IKON TRACKING -->
          <a href="Tracking.php" class="track-icon" title="Track Order" aria-label="Track Order">
            <i class="bx bxs-truck"></i>
            <?php if (!empty($trackingCount)): ?>
              <span class="track-count-badge"><?php echo $trackingCount; ?></span>
            <?php endif; ?>
          </a>

          <!-- IKON KERANJANG -->
          <a href="Cart.php" class="cart-icon" aria-label="Cart">
            <i class="bx bx-cart"></i>
            <span class="cart-item-count" id="header-cart-count">0</span>
          </a>

        </div>
      </div>
    </div>
  </header>
  <!-- ===== /HEADER ===== -->

  <!-- Hero Title -->
  <section class="hero">
    <div class="hero-content">
      <h1>Stop Dreaming, Start Walking!</h1>
      <p>Kehebatan ditempa dalam perjuangan. Bukan di garis Finish. Inilah fondasi untuk setiap jejak legasimu yang abadi.</p>
    </div>
  </section>

  <!-- Hero Images -->
  <section class="hero">
    <img src="IMG/Kids.jpg" width="525" alt="Kids 1" />
    <img src="IMG/Kids2.jpg" width="500" alt="Kids 2" />
    <img src="IMG/Kids3.jpg" width="500" alt="Kids 3" />
  </section>

  <!-- Products -->
    <section class="products-section">
    <h2 class="section-title">Featured Kids' Shoes</h2>
    <div class="products-grid">
      <?php if($products && mysqli_num_rows($products) > 0): ?>
        <?php while($p = mysqli_fetch_assoc($products)): ?>
          <?php
            $pid = (int)$p['id'];
            $sizesRes = mysqli_query($conn, "SELECT size_label, stock FROM product_sizes WHERE product_id=$pid AND stock > 0 ORDER BY size_label");
            $sizes = [];
            if ($sizesRes) {
              while ($row = mysqli_fetch_assoc($sizesRes)) {
                $sizes[] = $row; // size_label & stock
              }
            }
?>
          <div class="product-card"
               data-id="<?php echo $p['id']; ?>"
               data-name="<?php echo htmlspecialchars($p['name']); ?>"
               data-price="<?php echo (int)$p['price']; ?>"
               data-image="<?php echo htmlspecialchars($p['image_url']); ?>">
            <div class="product-image">
              <img src="<?php echo htmlspecialchars($p['image_url']); ?>"
                   alt="<?php echo htmlspecialchars($p['name']); ?>">
              <span><?php echo htmlspecialchars($p['brand']); ?></span>
            </div>
            <div class="product-info">
              <h3 class="product-name"><?php echo htmlspecialchars($p['name']); ?></h3>
              <p class="product-price">
                Rp <?php echo number_format((int)$p['price'], 0, ',', '.'); ?>
              </p>
              <p class="product-description">
                <?php echo htmlspecialchars($p['description']); ?>
              </p>
              <div class="size-selector">
                <label>Select Size:</label>
                <select class="product-size">
                  <option value="">Choose size</option>
                  <?php if (!empty($sizes)): ?>
                    <?php foreach($sizes as $sz): ?>
                      <option value="<?php echo htmlspecialchars($sz['size_label']); ?>">
                        EU <?php echo htmlspecialchars($sz['size_label']); ?> (Stok: <?php echo (int)$sz['stock']; ?>)
                      </option>
                    <?php endforeach; ?>
                  <?php else: ?>
                    <?php for($i=27;$i<=45;$i++): ?>
                      <option value="<?php echo $i; ?>">EU <?php echo $i; ?></option>
                    <?php endfor; ?>
                  <?php endif; ?>
                </select>
              </div>
              <button class="add-to-cart">Add to Cart</button>
            </div>
          </div>
        <?php endwhile; ?>
      <?php else: ?>
        <p style="grid-column:1 / -1; text-align:center; padding:16px 0;">
          Belum ada produk pada kategori ini.
        </p>
      <?php endif; ?>
    </div>
  </section>


  <!-- Footer -->
  <footer class="footer">
    <div class="footer-container container">
      <div class="footer-about">
        <h3 class="footer-title">About Us</h3>
        <p>Selamat Datang di A.F.K FOOTWEAR Store.<br> 
          Berawal dari kecintaan pada dunia fashion dan olahraga, A.F.K FOOTWEAR hadir untuk memberikan pengalaman belanja sepatu yang berbeda. 
          Kami ingin menghadirkan koleksi sepatu terbaik dari brand terkenal di dunia seperti Nike, Adidas, Puma, langsung ke genggamanmu.</p>
      </div>
      <div class="footer-links">
        <h3 class="footer-title">Products</h3>
        <ul>
          <li><a href="Mens.php">Mens</a></li>
          <li><a href="Womens.php">Womens</a></li>
          <li><a href="Kids.php">Kids</a></li>
          <li><a href="index.php">New Collections</a></li>
        </ul>
      </div>
      <div class="footer-links">
        <h3 class="footer-title">Help</h3>
        <ul>
          <li><a href="Help.php">Get Help</a></li>
          <li><a href="Help.php">Order Status</a></li>
          <li><a href="Help.php">Delivery</a></li>
          <li><a href="Help.php">Returns</a></li>
          <li><a href="Help.php">Payment Options</a></li>
        </ul>
      </div>
<div class="footer-contact">
        <h3 class="footer-title">Contact Us</h3>
        <ul>
          <p><i class='bx bxs-map'></i> JL. Lidah Wetan, Surabaya</p>
          <p><i class='bx bxs-phone'></i> 0812-3456-7890</p>
          <p><i class='bx bxs-envelope'></i> AFKFootwear@gmail.com</p>
          <p><i class='bx bxs-time'></i> Setiap Hari: 08.00 - 22.00</p>
          <p><i class='bx bxs-web'></i> www.AFKFOOTWEAR.com</p>
        </ul>

        <div class="footer-socials">
          <a href="#"><i class='bx bxl-instagram'></i></a>
          <a href="#"><i class='bx bxl-facebook-square'></i></a>
          <a href="#"><i class='bx bxl-twitter'></i></a>
          <a href="#"><i class='bx bxl-whatsapp'></i></a>
          <a href="#"><i class='bx bxl-youtube'></i></a>
        </div>
      </div>
    </div>

    <div class="footer-bottom">
      <p>&copy; 2025 A.F.K FOOTWEAR. All rights reserved | Privacy Policy</p>
    </div>
  </footer>

  <!-- Scroll Top -->
  <a href="#" id="scrollTopBtn" class="scroll-top-btn">
    <i class="bx bx-up-arrow-alt"></i>
  </a>

  <!-- Scripts umum -->
  <script src="js/search.js"></script>
  <script src="js/pageup.js"></script>
  <script src="js/nav-active.js"></script>

  <!-- JS CART UNTUK PAGE KIDS -->
  <script>
    function formatCurrency(amount) {
      return new Intl.NumberFormat('id-ID', {
        style: 'currency',
        currency: 'IDR',
        minimumFractionDigits: 0
      }).format(amount).replace(/\s/g, '');
    }

    // Helper aman ambil cart dari localStorage
    function getCartFromStorage() {
      const raw = localStorage.getItem('cartItems');
      if (!raw) return [];
      try {
        const parsed = JSON.parse(raw);
        return Array.isArray(parsed) ? parsed : [];
      } catch (e) {
        console.error('Gagal parse cartItems:', e);
        return [];
      }
    }

    function showNotification(message) {
      const notif = document.createElement('div');
      notif.classList.add('cart-notification', 'success');
      notif.textContent = message;
      document.body.appendChild(notif);

      setTimeout(() => {
        notif.classList.add('show');
      }, 10);

      setTimeout(() => {
        notif.classList.remove('show');
        setTimeout(() => {
          document.body.removeChild(notif);
        }, 500);
      }, 3000);
    }

    function updateCartIcon() {
      const cart = getCartFromStorage();
      const totalItems = cart.reduce((sum, item) => sum + (item.quantity || 0), 0);

      const cartIconCounts = document.querySelectorAll('.cart-item-count, #header-cart-count');
      cartIconCounts.forEach(icon => {
        icon.textContent = totalItems;
        if (totalItems > 0) {
          icon.style.display = 'block';
        } else {
          icon.style.display = 'none';
        }
      });
    }

    function addItemToCart(newItem) {
      let cart = getCartFromStorage();

      const existingItem = cart.find(
        item => item.id === newItem.id && item.size === newItem.size
      );

      if (existingItem) {
        existingItem.quantity += 1;
      } else {
        cart.push(newItem);
      }

      localStorage.setItem('cartItems', JSON.stringify(cart));
      updateCartIcon();
      showNotification(`${newItem.name} (Size: ${newItem.size}) added to cart.`);
    }

    document.addEventListener('DOMContentLoaded', () => {
      const addToCartButtons = document.querySelectorAll('.add-to-cart');

      addToCartButtons.forEach(button => {
        button.addEventListener('click', (event) => {
          const card = event.target.closest('.product-card');
          if (!card) return;

          const sizeSelector = card.querySelector('.product-size');
          const selectedSize = sizeSelector ? sizeSelector.value : '';

          if (!selectedSize) {
            alert('Please select a size first!');
            return;
          }

          const priceRaw = parseFloat(card.dataset.price) || 0;

          const product = {
            id: card.dataset.id,
            name: card.dataset.name,
            priceRaw: priceRaw,
            price: formatCurrency(priceRaw),
            image: card.dataset.image,
            size: selectedSize,
            quantity: 1
          };

          addItemToCart(product);
        });
      });

      // Update ikon keranjang saat halaman dibuka
      updateCartIcon();
    });
  </script>

  <script>
  document.addEventListener('DOMContentLoaded', function () {
    var form  = document.getElementById('header-search-form');
    var icon  = document.getElementById('header-search-icon');
    var input = document.getElementById('header-search-input');

    if (form && icon && input) {
      icon.style.cursor = 'pointer';

      icon.addEventListener('click', function () {
        var val = input.value.trim();
        if (val === '') {
          input.focus();
        } else {
          form.submit();
        }
      });
    }
  });
  </script>

</body>
</html>