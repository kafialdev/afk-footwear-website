<?php
// Sign In AFK FOOTWEAR - terhubung ke database
require_once __DIR__ . '/db.php';
session_start();

$err = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $email    = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    // validasi server-side (minimal mirip JS)
    if ($username === '' || strpos($username, '@') === false) {
        $err = 'Username harus mengandung @';
    } elseif ($email === '' || !str_ends_with($email, '@gmail.com')) {
        $err = 'Email harus @gmail.com';
    } elseif (!preg_match('/^(?=.*[a-z])(?=.*[A-Z])(?=.*[\d\W]).{8,}$/', $password)) {
        $err = 'Password tidak memenuhi kriteria.';
    } else {
        // MODE LOGIN SAJA - tidak auto-register
        $stmt = $conn->prepare("SELECT * FROM users WHERE email = ? LIMIT 1");
        if ($stmt) {
            $stmt->bind_param('s', $email);
            $stmt->execute();
            $res  = $stmt->get_result();
            $user = $res ? $res->fetch_assoc() : null;
            $stmt->close();

            if ($user && isset($user['password_hash']) && password_verify($password, $user['password_hash'])) {
                $_SESSION['user_id']    = $user['id'];
                $_SESSION['user_name']  = $user['name'];
                $_SESSION['user_email'] = $user['email'];

                header('Location: index.php');
                exit;
            } else {
                $err = 'Email atau password salah, atau akun belum terdaftar. Silakan Sign Up terlebih dahulu.';
            }
        } else {
            $err = 'Terjadi kesalahan pada server.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Sign In - A.F.K FOOTWEAR</title>
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <link href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet"/>

  <style>
    *, *::before, *::after { box-sizing: border-box; }
    html, body { height: 100%; }
    body{
      background-image:url(https://i.pinimg.com/1200x/34/0b/64/340b64f7ed20b916eb5e12260e42899c.jpg);
      background-size:cover;
      background-position:center;
      background-repeat:no-repeat;
      min-height:100vh;
      display:flex;
      justify-content:center;
      align-items:center;
      font-family:system-ui,-apple-system,Segoe UI,Roboto,"Helvetica Neue",Arial,"Noto Sans","Liberation Sans",sans-serif;
      margin:0;
      padding:12px;
    }
    .login-container{ width:400px; max-width:92vw; }
    .login-form{
      width:100%;
      max-width:420px;
      padding:2rem;
      background:#fff;
      border-radius:16px;
      box-shadow:0 10px 30px rgba(0,0,0,.15);
      position:relative;
      overflow:hidden;
    }
    .icon-top{
      text-align:center;
      margin-bottom:1.1rem;
    }
    .icon-top i{
      font-size:28px;
      color:#9d2b2b;
      margin-bottom:6px;
      display:inline-block;
    }
    .icon-top h2{
      margin:0;
      letter-spacing:.5px;
    }
    .input-group{
      position:relative;
      margin-bottom:1.9rem;
      width:100%;
    }
    .input-group input{
      display:block;
      width:100%;
      max-width:100%;
      height:46px;
      line-height:46px;
      padding:0 46px 0 12px; /* ruang kanan cukup utk ikon */
      border-radius:10px;
      border:1px solid #ccc;
      outline:none;
      background:#fff;
      transition:box-shadow .2s, border-color .2s;
    }
    .input-group input:focus{
      border-color:#000;
      box-shadow:0 0 0 4px rgba(0,0,0,.08);
    }
    /* ikon biasa (user, email) */
    .input-group .icon-right{
      position:absolute;
      right:12px;
      top:50%;
      transform:translateY(-50%);
      color:#777;
      font-size:18px;
      pointer-events:none;
    }
    /* tombol mata */
    .toggle-password{
      position:absolute;
      right:8px;
      top:50%;
      transform:translateY(-50%);
      width:32px;
      height:32px;
      border:none;
      background:transparent;
      padding:0;
      cursor:pointer;
      display:flex;
      align-items:center;
      justify-content:center;
    }
    .toggle-password i{
      font-size:18px;
      color:#777;
    }

    .error{
      position:absolute;
      left:6px;
      bottom:-18px;
      color:#d93025;
      font-size:12px;
      line-height:1;
      display:none;
      max-width:calc(100% - 12px);
      white-space:nowrap;
      overflow:hidden;
      text-overflow:ellipsis;
    }
    .is-invalid{
      border-color:#d93025 !important;
      box-shadow:0 0 0 4px rgba(217,48,37,.12) !important;
    }

    .forgot{
      display:block;
      text-align:right;
      font-size:13px;
      margin:5px 0 15px;
      color:#007bff;
      text-decoration:none;
    }

    .other-links{
      display:flex;
      justify-content:space-between;
      align-items:center;
      gap:10px;
      font-size:13px;
      margin:5px 0 15px;
    }
    .signup-text{
      margin:0;
      font-size:13px;
      color:#555;
    }
    .signup-text a{
      color:#007bff;
      text-decoration:none;
      font-weight:500;
    }
    .login-btn{
      width:100%;
      padding:12px;
      background:#4CAF50;
      color:#fff;
      border:none;
      border-radius:10px;
      cursor:pointer;
      font-size:16px;
      margin-bottom:1rem;
      font-weight:600;
      letter-spacing:0.5px;
    }

    .validation-info{
      font-size:12px;
      text-align:left;
      color:#555;
      margin:1rem 0 0.2rem;
    }
    .validation-info h4{
      margin:0 0 .5rem;
    }
    .validation-info ul{
      margin:0;
      padding-left:18px;
    }

    .top-nav{
      position:fixed;
      top:12px;
      left:12px;
      z-index:10;
    }
    .home-icon{
      display:inline-flex;
      width:42px;
      height:42px;
      align-items:center;
      justify-content:center;
      border-radius:12px;
      background:rgba(0,0,0,.35);
      backdrop-filter:blur(4px);
    }
    .home-icon i{
      font-size:22px;
      color:#fff;
    }
  </style>
</head>
<body>

  <!-- Tombol kembali ke Home -->
  <div class="top-nav">
    <a href="index.php" class="home-icon" title="Back to Home" aria-label="Back to Home">
      <i class='bx bx-home'></i>
    </a>
  </div>

  <?php if($err): ?>
    <script>alert("<?= htmlspecialchars($err, ENT_QUOTES) ?>");</script>
  <?php endif; ?>

  <!-- CARD SIGN IN -->
  <div class="login-container">
    <form class="login-form" id="signInForm" method="POST" novalidate>
      <div class="icon-top">
        <i class="fas fa-sign-in-alt"></i>
        <h2>SIGN IN</h2>
      </div>

      <div class="input-group">
        <input type="text" id="username" name="username" placeholder="Username" required>
        <i class="fas fa-user icon-right"></i>
        <div id="usernameError" class="error">Username harus mengandung '@'</div>
      </div>

      <div class="input-group">
        <input type="email" id="email" name="email" placeholder="Email" required>
        <i class="fas fa-envelope icon-right"></i>
        <div id="emailError" class="error">Email harus menggunakan domain @gmail.com</div>
      </div>

      <div class="input-group">
        <input type="password" id="password" name="password" placeholder="Password" required>
        <button type="button" class="toggle-password" data-target="password">
          <i class="fa-solid fa-eye"></i>
        </button>
        <div id="passwordError" class="error">
          Password minimal 8 karakter, berisi huruf besar, kecil, dan angka/simbol
        </div>
      </div>

      <button type="submit" class="login-btn">LOG IN</button>

      <div class="other-links">
        <a href="forgot_password.php" class="forgot">Lupa password?</a>
        <p class="signup-text">Belum punya akun? <a href="signup.php">Sign Up</a></p>
      </div>

      <div class="validation-info">
        <h4>Requirements:</h4>
        <ul>
          <li>Username harus mengandung simbol "@".</li>
          <li>Email harus @gmail.com.</li>
          <li>Password minimal 8 karakter, mengandung huruf besar, kecil, dan angka/simbol.</li>
        </ul>
      </div>

    </form>
  </div>

  <!-- JS VALIDASI + TOGGLE PASSWORD -->
  <script>
    document.addEventListener("DOMContentLoaded", () => {
      const mainForm      = document.getElementById("signInForm");
      const usernameInput = document.getElementById("username");
      const emailInput    = document.getElementById("email");
      const passwordInput = document.getElementById("password");
      const usernameError = document.getElementById("usernameError");
      const emailError    = document.getElementById("emailError");
      const passwordError = document.getElementById("passwordError");

      const passwordPattern = /^(?=.*[a-z])(?=.*[A-Z])(?=.*[\d\W]).{8,}$/;

      const show = el => el && (el.style.display = "block");
      const hide = el => el && (el.style.display = "none");

      function markInvalid(inputEl, errorEl, invalid){
        inputEl.classList.toggle("is-invalid", invalid);
        inputEl.setAttribute("aria-invalid", invalid ? "true" : "false");
        invalid ? show(errorEl) : hide(errorEl);
      }

      function validateMainForm(){
        const uBad = !usernameInput.value.trim().includes("@");
        const eBad = !emailInput.value.trim().endsWith("@gmail.com");
        const pBad = !passwordPattern.test(passwordInput.value);

        markInvalid(usernameInput, usernameError, uBad);
        markInvalid(emailInput,    emailError,    eBad);
        markInvalid(passwordInput, passwordError, pBad);

        return !uBad && !eBad && !pBad;
      }

      // === FUNGSI SHOW / HIDE PASSWORD (LOGO MATA) ===
      const toggleIcons = document.querySelectorAll(".toggle-password");
      toggleIcons.forEach(btn => {
        btn.addEventListener("click", () => {
          const targetId = btn.getAttribute("data-target");
          const input = document.getElementById(targetId);
          const icon  = btn.querySelector("i");
          if (!input || !icon) return;

          if (input.type === "password") {
            input.type = "text";
            icon.classList.remove("fa-eye");
            icon.classList.add("fa-eye-slash");
          } else {
            input.type = "password";
            icon.classList.remove("fa-eye-slash");
            icon.classList.add("fa-eye");
          }
        });
      });

      // === VALIDASI FORM ===
      if(mainForm){
        mainForm.addEventListener("submit", (ev)=>{
          if (!validateMainForm()){
            ev.preventDefault();
          }
        });

        usernameInput.addEventListener("input", ()=> 
          markInvalid(usernameInput, usernameError, !usernameInput.value.includes("@")));
        emailInput.addEventListener("input", ()=> 
          markInvalid(emailInput,    emailError,    !emailInput.value.trim().endsWith("@gmail.com")));
        passwordInput.addEventListener("input", ()=> 
          markInvalid(passwordInput, passwordError,!passwordPattern.test(passwordInput.value)));
      }
    });
  </script>

</body>
</html>
