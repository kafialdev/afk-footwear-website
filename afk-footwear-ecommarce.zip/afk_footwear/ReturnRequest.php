<?php
require_once __DIR__ . '/db.php';
session_start();

$trackingCount = getTrackingCount($conn);
// wajib login
if (empty($_SESSION['user_id'])) {
  header('Location: signin.php');
  exit;
}

$userId  = (int)$_SESSION['user_id'];
$orderId = isset($_GET['order_id']) ? (int)$_GET['order_id'] : 0;

if ($orderId <= 0) {
  header('Location: OrderHistory.php');
  exit;
}

// validasi order milik user dan status selesai
$order = null;
$stmt = $conn->prepare("SELECT id, status, created_at, total_amount FROM orders WHERE id = ? AND user_id = ? LIMIT 1");
$stmt->bind_param('ii', $orderId, $userId);
$stmt->execute();
$order = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$order || ($order['status'] ?? '') !== 'Selesai') {
  header('Location: OrderHistory.php');
  exit;
}

// ambil item pesanan untuk dipilih saat retur
$items = [];
$stmt = $conn->prepare("SELECT oi.product_id, p.name, oi.size_label, oi.quantity
  FROM order_items oi
  JOIN products p ON p.id = oi.product_id
  WHERE oi.order_id = ?
  ORDER BY oi.id ASC");
$stmt->bind_param('i', $orderId);
$stmt->execute();
if ($res = $stmt->get_result()) {
  $items = $res->fetch_all(MYSQLI_ASSOC);
}
$stmt->close();

// cek apakah sudah pernah ajukan return
$existing = null;
$stmt = $conn->prepare("SELECT id, status FROM returns WHERE order_id = ? AND user_id = ? LIMIT 1");
$stmt->bind_param('ii', $orderId, $userId);
@$stmt->execute();
if ($stmt && ($r = $stmt->get_result())) {
  $existing = $r->fetch_assoc();
}
if ($stmt) { $stmt->close(); }

$code = sprintf('#AFK%04d', $orderId);
$date = date('d M Y, H:i', strtotime($order['created_at']));
$total = (int)$order['total_amount'];

// alamat pengembalian (ditampilkan ke customer)
$returnAddress = "A.F.K FOOTWEAR Return Center\nJl. Lidah Wetan, Surabaya\nTelp: 0812-3456-7890\nJam: 08.00 - 22.00";

// tampilkan error jika submit gagal
$flashErr = $_SESSION['return_error'] ?? '';
unset($_SESSION['return_error']);
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Ajukan Return - A.F.K FOOTWEAR</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/style.css" />
  <link href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet">
  <style>
    body{
      background:#f3f4f6;
      font-family:'Poppins',system-ui,-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;
    }

    /* ========== HEADER GLOBAL (SAMA DENGAN RIWAYAT) ========== */
    header.header {
      background-color: #020033;
      color: #ffffff;
      padding: 15px 0;
      position: sticky;
      top: 0;
      z-index: 999;
      box-shadow: 0 2px 10px rgba(0, 0, 0, 0.15);
      width: 100%;
    }
    .main-nav-simple {
      display: flex;
      align-items: center;
      justify-content: space-between;
      max-width: 1400px;
      margin: 0 auto;
      padding: 0 2rem;
    }
    .main-nav-simple img { 
      height: 45px; 
      display:block; 
    }
    .center-nav { 
      flex: 1; 
      display: flex; 
      justify-content: center; 
    }
    .center-nav .nav-links {
      display: flex;
      gap: 3rem;
      list-style:none;
    }
    .center-nav .nav-links a {
      color: #ffffff;
      font-weight: 600;
      font-size: 1.05rem;
      padding:6px 4px;
      text-decoration:none;
      transition: color 0.3s ease;
    }
    .center-nav .nav-links a:hover,
    .center-nav .nav-links a.active-link { 
      color: var(--primary-color); 
    }

    .right-nav { 
      display: flex; 
      align-items: center; 
      gap: 2rem; 
    }
    .right-nav-links {
      display: flex;
      align-items: center;
      gap: 2rem;
      list-style:none;
    }
    .right-nav-links a {
      color: #ffffff;
      font-weight: 600;
      font-size: 1.05rem;
      text-decoration:none;
      transition: color 0.3s ease;
    }
    .right-nav-links a:hover { 
      color: var(--primary-color); 
    }

    .icon-link {
      color: #ffffff;
      font-size: 1.6rem;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      position:relative;
      text-decoration:none;
      transition: transform 0.2s ease, color 0.2s ease;
    }
    .icon-link:hover {
      transform: scale(1.1);
      color: var(--primary-color);
    }

    .cart-item-count {
      position: absolute;
      top: -8px;
      right: -10px;
      background: #d00000;
      color: white;
      padding: 2px 7px;
      border-radius: 50%;
      font-size: 0.75rem;
      font-weight: bold;
      display: none;
    }
    .track-count-badge{
      position:absolute;
      top:-8px;
      right:-10px;
      background:#d00000;
      color:#fff;
      padding:2px 7px;
      border-radius:50%;
      font-size:.75rem;
      font-weight:bold;
    }

    main{ max-width:1100px; margin:20px auto 32px; padding:0 16px 32px; }
    .card{ background:#fff; border:1px solid #e5e7eb; border-radius:16px; box-shadow:0 10px 30px rgba(15,23,42,.12); padding:16px; }
    .row{ display:flex; gap:14px; flex-wrap:wrap; }
    .pill{ display:inline-flex; align-items:center; gap:8px; padding:8px 12px; border-radius:999px; border:1px solid #e5e7eb; background:#fff; font-weight:700; }
    .form{ margin-top:14px; display:grid; gap:12px; }
    label{ font-weight:700; color:#111827; font-size:.95rem; }
    select, textarea, input[type=file]{ width:100%; padding:12px; border-radius:12px; border:1px solid #e5e7eb; outline:none; background:#fff; }
    textarea{ min-height:110px; resize:vertical; }
    .actions{ display:flex; gap:10px; flex-wrap:wrap; margin-top:10px; }
    .btn{ display:inline-flex; align-items:center; gap:8px; padding:10px 14px; border-radius:12px; font-weight:800; text-decoration:none; border:1px solid transparent; cursor:pointer; }
    .btn-primary{ background:#111827; color:#fff; }
    .btn-ghost{ background:#fff; color:#111827; border-color:#e5e7eb; }
    .notice{ background:#eef2ff; border:1px solid #c7d2fe; color:#1e3a8a; border-radius:14px; padding:12px 14px; margin-bottom:12px; }
    .warn{ background:#fff7ed; border:1px solid #fed7aa; color:#9a3412; }
    /* ========== RESPONSIVE (SAMAKAN HEADER & RAPIKAN) ========== */
    @media (max-width:768px){
          header.header{
            padding:8px 0;
          }
    
          .main-nav-simple{
            flex-wrap:wrap;
            gap:8px;
            height:auto;
            /* padding kiri-kanan supaya tidak mepet frame */
            padding:0 14px;
          }
    
          .main-nav-simple img{
            height:38px;
          }
    
          /* logo + menu kanan di baris atas */
          .right-nav{
            gap:14px;
          }
          .right-nav-links a{
            font-size:.9rem;
          }
          .icon-link{
            font-size:1.3rem;
          }
    
          /* menu kategori turun ke baris bawah, full width */
          .center-nav{
            order:3;
            width:100%;
            justify-content:center;
          }
          .center-nav .nav-links{
            justify-content:center;
            flex-wrap:wrap;
            gap:16px;
          }
          .center-nav .nav-links a{
            font-size:.9rem;
          }
    
          .cart-item-count,
          .track-count-badge{
            /* sedikit geser agar tidak nabrak icon di layar kecil */
            transform: translate(25%, -30%);
          }

  </style>
</head>
<body>

<header class="header">
  <div class="main-nav-simple">
    <a href="index.php">
      <img src="IMG/LOGO.jpg" alt="AFK Footwear Logo">
    </a>

    <nav class="center-nav">
      <ul class="nav-links">
        <li><a href="Mens.php">Mens</a></li>
        <li><a href="Womens.php">Womens</a></li>
        <li><a href="Kids.php">Kids</a></li>
        <li><a href="Discount.php">Discounts</a></li>
      </ul>
    </nav>

    <div class="right-nav">
      <ul class="right-nav-links">
        <li><a href="index.php">Home</a></li>
        <li><a href="About.php">About</a></li>
        <li><a href="Help.php">Help</a></li>
      </ul>

      <a href="Tracking.php" class="icon-link track-icon" title="Track Order">
        <i class="bx bxs-truck"></i>
        <?php if (!empty($trackingCount)): ?>
          <span class="track-count-badge"><?php echo $trackingCount; ?></span>
        <?php endif; ?>
      </a>

      <a href="Cart.php" class="icon-link cart-icon" title="Cart">
        <i class='bx bx-cart'></i>
        <span id="header-cart-count" class="cart-item-count">0</span>
      </a>
    </div>
  </div>
</header>

<main>
  <div class="card">
    <div class="row" style="justify-content:space-between; align-items:center;">
      <div>
        <h2 style="margin:0; color:#111827;">Ajukan Return</h2>
        <div style="margin-top:6px; color:#6b7280; font-weight:600; font-size:.95rem;">Untuk pesanan <b><?php echo htmlspecialchars($code); ?></b> • <?php echo htmlspecialchars($date); ?></div>
      </div>
      <div class="pill"><i class='bx bx-receipt'></i> Rp <?php echo number_format($total,0,',','.'); ?></div>
    </div>

    <?php if (!empty($flashErr)): ?>
      <div class="notice warn" style="margin-top:14px;">
        <?php echo htmlspecialchars($flashErr); ?>
      </div>
    <?php endif; ?>

    <?php if ($existing): ?>
      <div class="notice warn" style="margin-top:14px;">
        Kamu sudah pernah mengajukan return untuk pesanan ini. Status saat ini: <b><?php echo htmlspecialchars($existing['status']); ?></b>.
        <div style="margin-top:6px;"><a class="btn btn-ghost" href="ReturnMy.php"><i class='bx bx-time-five'></i> Lihat Status Return</a></div>
      </div>
    <?php else: ?>
      <div class="notice" style="margin-top:14px;">
        Pastikan barang masih lengkap dan sesuai syarat retur. Admin akan memverifikasi pengajuanmu.
      </div>

      <form class="form" action="ReturnSubmit.php" method="post" enctype="multipart/form-data">
        <input type="hidden" name="order_id" value="<?php echo (int)$orderId; ?>">
        <input type="hidden" name="return_address" value="<?php echo htmlspecialchars($returnAddress); ?>">

        <div>
          <label for="product_id">Barang yang Direturn</label>
          <select id="product_id" name="product_id" required>
            <option value="" disabled selected>Pilih barang</option>
            <?php foreach ($items as $it): ?>
              <?php
                $pid = (int)$it['product_id'];
                $icode = sprintf('PRD%04d', $pid);
                $sz = !empty($it['size_label']) ? (' • Size ' . $it['size_label']) : '';
                $qty = ' • Qty ' . (int)$it['quantity'];
                $label = ($it['name'] ?? 'Produk') . " • $icode" . $sz . $qty;
              ?>
              <option value="<?php echo $pid; ?>"><?php echo htmlspecialchars($label); ?></option>
            <?php endforeach; ?>
          </select>
          <div style="margin-top:6px; color:#6b7280; font-size:.85rem;">Kode barang otomatis diambil dari ID produk (contoh: PRD0001).</div>
        </div>

        <div>
          <label for="return_address_view">Lokasi Pengiriman Pengembalian</label>
          <textarea id="return_address_view" readonly><?php echo htmlspecialchars($returnAddress); ?></textarea>
          <div style="margin-top:6px; color:#6b7280; font-size:.85rem;">Kirim barang return ke alamat di atas. Simpan resi pengiriman untuk bukti.</div>
        </div>

        <div>
          <label for="reason">Alasan Return</label>
          <select id="reason" name="reason" required>
            <option value="" disabled selected>Pilih alasan</option>
            <option value="Salah ukuran">Salah ukuran</option>
            <option value="Cacat">Cacat</option>
            <option value="Salah barang">Salah barang</option>
            <option value="Tidak sesuai deskripsi">Tidak sesuai deskripsi</option>
            <option value="Lainnya">Lainnya</option>
          </select>
        </div>

        <div>
          <label for="note">Catatan (opsional)</label>
          <textarea id="note" name="note" placeholder="Tulis detail masalah (ukuran, bagian yang cacat, dll)"></textarea>
        </div>

        <div>
          <label for="photo">Foto Bukti (opsional)</label>
          <input id="photo" type="file" name="photo" accept="image/*">
          <div style="margin-top:6px; color:#6b7280; font-size:.85rem;">Format disarankan: JPG/PNG. Maks 2MB.</div>
        </div>

        <div class="actions">
          <button type="submit" class="btn btn-primary"><i class='bx bx-send'></i> Kirim Pengajuan</button>
          <a href="OrderHistory.php" class="btn btn-ghost"><i class='bx bx-left-arrow-alt'></i> Kembali</a>
        </div>
      </form>
    <?php endif; ?>
  </div>
</main>

</body>
</html>
