<?php
// Reset Password AFK FOOTWEAR
require_once __DIR__ . '/db.php';
session_start();

$err  = '';
$info = '';

$token = trim($_GET['token'] ?? ($_POST['token'] ?? ''));

$resetRow = null;
if ($token !== '') {
    $stmt = $conn->prepare(
        "SELECT pr.id, pr.user_id, pr.expires_at, u.email, u.name
         FROM password_resets pr
         JOIN users u ON pr.user_id = u.id
         WHERE pr.token = ?
         LIMIT 1"
    );
    if ($stmt) {
        $stmt->bind_param('s', $token);
        $stmt->execute();
        $res = $stmt->get_result();
        $resetRow = $res ? $res->fetch_assoc() : null;
        $stmt->close();

        if ($resetRow) {
            if (strtotime($resetRow['expires_at']) < time()) {
                $err = 'Token reset password sudah kadaluarsa. Silakan minta ulang.';
                $resetRow = null;
            }
        } else {
            $err = 'Token reset password tidak ditemukan atau sudah digunakan.';
        }
    } else {
        $err = 'Terjadi kesalahan pada server.';
    }
} else {
    $err = 'Token tidak valid.';
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $resetRow) {
    $password = $_POST['password'] ?? '';
    $confirm  = $_POST['confirm_password'] ?? '';

    if (!preg_match('/^(?=.*[a-z])(?=.*[A-Z])(?=.*[\d\W]).{8,}$/', $password)) {
        $err = 'Password tidak memenuhi kriteria.';
    } elseif ($password !== $confirm) {
        $err = 'Konfirmasi password tidak sama.';
    } else {
        $hash = password_hash($password, PASSWORD_BCRYPT);

        if ($up = $conn->prepare("UPDATE users SET password_hash = ? WHERE id = ?")) {
            $up->bind_param('si', $hash, $resetRow['user_id']);
            if ($up->execute()) {
                $up->close();

                if ($del = $conn->prepare("DELETE FROM password_resets WHERE user_id = ?")) {
                    $del->bind_param('i', $resetRow['user_id']);
                    $del->execute();
                    $del->close();
                }

                $info = 'Password berhasil direset. Silakan login dengan password baru Anda.';
            } else {
                $err = 'Gagal mengubah password: ' . $up->error;
                $up->close();
            }
        } else {
            $err = 'Terjadi kesalahan pada server.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Reset Password - A.F.K FOOTWEAR</title>
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <link href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet"/>
  <style>
    *, *::before, *::after { box-sizing: border-box; }
    html, body { height: 100%; }
    body{
      background-image:url(https://i.pinimg.com/1200x/34/0b/64/340b64f7ed20b916eb5e12260e42899c.jpg);
      background-size:cover;
      background-position:center;
      background-repeat:no-repeat;
      min-height:100vh;
      display:flex;
      justify-content:center;
      align-items:center;
      font-family:system-ui,-apple-system,Segoe UI,Roboto,"Helvetica Neue",Arial,"Noto Sans","Liberation Sans",sans-serif;
      margin:0;
      padding:12px;
    }
    .login-container{ width:400px; max-width:92vw; }
    .login-form{
      width:100%;
      max-width:420px;
      padding:2rem;
      background:#fff;
      border-radius:16px;
      box-shadow:0 10px 30px rgba(0,0,0,.15);
      position:relative;
      overflow:hidden;
    }
    .icon-top{
      text-align:center;
      margin-bottom:1.1rem;
    }
    .icon-top i{
      font-size:28px;
      color:#9d2b2b;
      margin-bottom:6px;
      display:inline-block;
    }
    .icon-top h2{
      margin:0;
      letter-spacing:.5px;
    }
    .input-group{
      position:relative;
      margin-bottom:1.9rem;
      width:100%;
    }
    .input-group input{
      display:block;
      width:100%;
      max-width:100%;
      height:46px;
      line-height:46px;
      padding:0 42px 0 12px;
      border-radius:10px;
      border:1px solid #ccc;
      outline:none;
      background:#fff;
      transition:box-shadow .2s, border-color .2s;
    }
    .input-group input:focus{
      border-color:#000;
      box-shadow:0 0 0 4px rgba(0,0,0,.08);
    }
    .input-group i{
      position:absolute;
      right:12px;
      top:50%;
      transform:translateY(-50%);
      color:#777;
      pointer-events:none;
      font-size:18px;
    }
    .error{
      position:absolute;
      left:6px;
      bottom:-18px;
      color:#d93025;
      font-size:12px;
      line-height:1;
      display:none;
      max-width:calc(100% - 12px);
      white-space:nowrap;
      overflow:hidden;
      text-overflow:ellipsis;
    }
    .is-invalid{
      border-color:#d93025 !important;
      box-shadow:0 0 0 4px rgba(217,48,37,.12) !important;
    }

    .forgot{
      display:block;
      text-align:right;
      font-size:13px;
      margin:5px 0 15px;
      color:#007bff;
      text-decoration:none;
    }

    
    .other-links{
      display:flex;
      justify-content:space-between;
      align-items:center;
      gap:10px;
      font-size:13px;
      margin:5px 0 15px;
    }
    .signup-text{
      margin:0;
      font-size:13px;
      color:#555;
    }
    .signup-text a{
      color:#007bff;
      text-decoration:none;
      font-weight:500;
    }
.login-btn{
      width:100%;
      padding:12px;
      background:#4CAF50;
      color:#fff;
      border:none;
      border-radius:10px;
      cursor:pointer;
      font-size:16px;
      margin-bottom:1rem;
      font-weight:600;
      letter-spacing:0.5px;
    }

    .validation-info{
      font-size:12px;
      text-align:left;
      color:#555;
      margin:1rem 0 0.2rem;
    }
    .validation-info h4{
      margin:0 0 .5rem;
    }
    .validation-info ul{
      margin:0;
      padding-left:18px;
    }

    .top-nav{
      position:fixed;
      top:12px;
      left:12px;
      z-index:10;
    }
    .home-icon{
      display:inline-flex;
      width:42px;
      height:42px;
      align-items:center;
      justify-content:center;
      border-radius:12px;
      background:rgba(0,0,0,.35);
      backdrop-filter:blur(4px);
    }
    .home-icon i{
      font-size:22px;
      color:#fff;
    }
  </style>
</head>
<body>

  <div class="top-nav">
    <a href="index.php" class="home-icon" title="Back to Home" aria-label="Back to Home">
      <i class='bx bx-home'></i>
    </a>
  </div>

  <?php if($err): ?>
    <script>alert("<?= htmlspecialchars($err, ENT_QUOTES) ?>");</script>
  <?php endif; ?>

  <div class="login-container">
    <form class="login-form" method="POST" novalidate>
      <div class="icon-top">
        <i class="fas fa-key"></i>
        <h2>RESET PASSWORD</h2>
      </div>

      <?php if(!$resetRow): ?>
        <p style="font-size:14px; color:#444;">
          Token reset password tidak valid atau sudah kadaluarsa. Silakan lakukan permintaan lupa password lagi.
        </p>
      <?php else: ?>
        <p style="font-size:14px; margin-bottom:1rem; color:#444;">
          Reset password untuk akun: <strong><?= htmlspecialchars($resetRow['email'], ENT_QUOTES) ?></strong>
        </p>

        <input type="hidden" name="token" value="<?= htmlspecialchars($token, ENT_QUOTES) ?>"/>

        <div class="input-group">
          <input type="password" id="password" name="password" placeholder="Password baru" required>
          <i class="fas fa-key"></i>
        </div>

        <div class="input-group">
          <input type="password" id="confirm_password" name="confirm_password" placeholder="Konfirmasi password baru" required>
          <i class="fas fa-key"></i>
        </div>

        <div class="validation-info">
          <h4>Requirements:</h4>
          <ul>
            <li>Password minimal 8 karakter.</li>
            <li>Harus mengandung huruf besar, huruf kecil, dan angka/simbol.</li>
          </ul>
        </div>

        <button type="submit" class="login-btn">SIMPAN PASSWORD BARU</button>
      <?php endif; ?>

      <?php if($info): ?>
        <div style="margin-top:1rem; font-size:13px; color:#155724; background:#d4edda; border-radius:6px; padding:.75rem;">
          <?= htmlspecialchars($info, ENT_QUOTES) ?>
        </div>
        <div style="margin-top:.75rem; font-size:13px;">
          <a href="signin.php" style="color:#007bff; text-decoration:none;">Kembali ke halaman Sign In</a>
        </div>
      <?php endif; ?>

    </form>
  </div>

</body>
</html>
